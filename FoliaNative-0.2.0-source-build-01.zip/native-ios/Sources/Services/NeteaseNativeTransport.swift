import Foundation

// native-ios/Sources/Services/NeteaseNativeTransport.swift
// Only official upstream hosts; private headers/cookies remain isolated from QQ and the UI.
actor NeteaseNativeTransport {
    enum Encryption: Sendable { case weapi, eapi, xeapi }
    private let http: any NativeHTTPTransport
    private let vault: any NativeSessionVault
    private var cookies: [String: String]?
    private var deviceID: String?
    private var generation = 0
    private var xeapiKey: NeteaseXEAPIKey?
    private var keyTask: Task<NeteaseXEAPIKey, Error>?
    private static let cookieNames: Set<String> = ["MUSIC_U", "MUSIC_A", "__csrf", "NMTID", "uid", "userId"]

    init(http: any NativeHTTPTransport, vault: any NativeSessionVault) { self.http = http; self.vault = vault }

    func hasAccount() throws -> Bool { !(try readCookies())["MUSIC_U", default: ""].isEmpty }

    func clearSession() throws {
        generation += 1
        cookies = [:]
        try vault.write(nil, account: "netease.cookies")
    }

    private func readCookies() throws -> [String: String] {
        if let cookies { return cookies }
        let stored = try vault.read("netease.cookies")
        let value = stored.flatMap { try? JSONDecoder().decode([String: String].self, from: $0) } ?? [:]
        cookies = value.filter { Self.cookieNames.contains($0.key) && !$0.value.contains(where: { $0 == "\r" || $0 == "\n" || $0 == ";" }) }
        return cookies ?? [:]
    }

    private func readDeviceID() throws -> String {
        if let deviceID { return deviceID }
        if let data = try vault.read("netease.device"), let text = String(data: data, encoding: .utf8),
           text.count == 52, text.allSatisfy(\.isHexDigit) { deviceID = text; return text }
        let generated = try NeteaseCrypto.random(26).hex.uppercased()
        try vault.write(Data(generated.utf8), account: "netease.device")
        deviceID = generated
        return generated
    }

    func request(_ uri: String, data: [String: NativeJSON] = [:], encryption: Encryption = .eapi) async throws -> NativeJSON {
        let started = generation
        let id = try readDeviceID(), values = try readCookies()
        let now = String(Int64(Date().timeIntervalSince1970 * 1000))
        let isXEAPI = encryption == .xeapi
        var header: [String: NativeJSON] = [
            "osver": .string(isXEAPI ? "16" : "Microsoft-Windows-10-Professional-build-19045-64bit"), "deviceId": .string(id),
            "os": .string(isXEAPI ? "android" : "pc"), "appver": .string(isXEAPI ? "9.1.65" : "3.1.17.204416"),
            "versioncode": .string("140"), "mobilename": .string(""), "buildver": .string(String(now.prefix(10))),
            "resolution": .string("1920x1080"), "__csrf": .string(values["__csrf"] ?? ""), "channel": .string("netease"),
            "requestId": .string("\(now)_\(Int.random(in: 0...9999))")
        ]
        for name in ["MUSIC_U", "MUSIC_A"] { if let value = values[name] { header[name] = .string(value) } }
        if encryption == .eapi, let value = values["NMTID"] { header["NMTID"] = .string(value) }
        var payload = data; payload["e_r"] = .bool(false)
        let form: [String: String], url: URL
        var headers: [String: String] = [:]
        switch encryption {
        case .weapi:
            payload["csrf_token"] = .string(values["__csrf"] ?? "")
            form = try NeteaseCrypto.weapi(.object(payload))
            url = URL(string: "https://music.163.com/weapi/" + String(uri.dropFirst(5)))!
            header["__remember_me"] = .string("true"); header["WEVNSM"] = .string("1.0.0")
            headers = ["Referer": "https://music.163.com", "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36"]
        case .eapi:
            payload["header"] = .object(header)
            form = try NeteaseCrypto.eapi(uri: uri, data: .object(payload))
            url = URL(string: "https://interfacepc.music.163.com/eapi/" + String(uri.dropFirst(5)))!
            headers["User-Agent"] = "NeteaseMusic 9.0.90/5038 (iPhone; iOS 16.2; zh_CN)"
        case .xeapi:
            let key = try await playbackKey(deviceID: id)
            try check(started)
            form = try NeteaseXEAPI.encrypt(payload, key: key)
            url = URL(string: "https://interface3.music.163.com/xeapi/" + String(uri.dropFirst(5)))!
            headers = ["User-Agent": NeteaseXEAPI.userAgent, "X-Client-Enc-State": "ENCRYPTED", "x-aeapi": "true", "x-deviceid": id,
                       "x-os": "android", "x-osver": "16", "x-appver": "9.1.65", "x-sdeviceid": id, "x-buildver": String(now.prefix(10))]
            if let token = values["MUSIC_U"] { headers["x-music-u"] = token }
        }
        headers["Cookie"] = header.keys.sorted().map { "\($0)=\(header[$0]!.text)" }.joined(separator: "; ")
        headers["Content-Type"] = "application/x-www-form-urlencoded"
        var request = URLRequest(url: url); request.httpMethod = "POST"; request.httpBody = NativeURLRules.form(form)
        for (key, value) in headers { request.setValue(value, forHTTPHeaderField: key) }
        let (bytes, response) = try await http.data(for: request)
        try check(started)
        guard (200..<300).contains(response.statusCode) else { throw NativeMusicError.message("网易云连接失败（HTTP \(response.statusCode)）") }
        let body = try isXEAPI ? NeteaseXEAPI.decodeResponse(bytes) : NativeJSON.decoded(bytes)
        guard !body.object.isEmpty else { throw NativeMusicError.message("网易云返回了未识别的数据") }
        let acceptsLogin = uri == "/api/w/login/cellphone" && body["code"].int == 200
        try mergeCookies(response, url: url, acceptsLogin: acceptsLogin)
        return body
    }

    private func check(_ started: Int) throws {
        try Task.checkCancellation()
        if started != generation { throw CancellationError() }
    }

    private func mergeCookies(_ response: HTTPURLResponse, url: URL, acceptsLogin: Bool) throws {
        let fields = response.allHeaderFields.reduce(into: [String: String]()) { $0[String(describing: $1.key)] = String(describing: $1.value) }
        var values = try readCookies()
        for cookie in HTTPCookie.cookies(withResponseHeaderFields: fields, for: url) where Self.cookieNames.contains(cookie.name) {
            if cookie.name == "MUSIC_U", !acceptsLogin, values["MUSIC_U"] == nil { continue }
            if cookie.value.isEmpty || (cookie.expiresDate.map { $0 < Date() } ?? false) { values.removeValue(forKey: cookie.name) }
            else if !cookie.value.contains(where: { $0 == "\r" || $0 == "\n" || $0 == ";" }) { values[cookie.name] = cookie.value }
        }
        if values != cookies {
            try vault.write(try JSONEncoder().encode(values), account: "netease.cookies")
            cookies = values
        }
    }

    private func playbackKey(deviceID: String) async throws -> NeteaseXEAPIKey {
        if let xeapiKey { return xeapiKey }
        if let keyTask { return try await keyTask.value }
        let http = self.http
        let task = Task { try await Self.registerKey(deviceID: deviceID, http: http) }
        keyTask = task
        do { let key = try await task.value; keyTask = nil; xeapiKey = key; return key }
        catch { keyTask = nil; throw error }
    }

    private static func registerKey(deviceID: String, http: any NativeHTTPTransport) async throws -> NeteaseXEAPIKey {
        let nonce = try NeteaseCrypto.random(16).map { String($0 % 10) }.joined()
        let timestamp = String(Int64(Date().timeIntervalSince1970 * 1000))
        let fields = ["appVersion": "9.5.61", "currentKeyVersion": "", "deviceId": deviceID, "nonce": nonce, "os": "android", "requestType": "active",
                      "signature": NeteaseXEAPI.sign(timestamp: timestamp, nonce: nonce), "t1": "", "t2": "", "timestamp": timestamp, "uid": ""]
        var request = URLRequest(url: URL(string: "https://interface.music.163.com/api/bsr/sk/get")!)
        request.httpMethod = "POST"; request.httpBody = NativeURLRules.form(fields)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.setValue(NeteaseXEAPI.userAgent, forHTTPHeaderField: "User-Agent")
        request.setValue("deviceId=\(deviceID)", forHTTPHeaderField: "Cookie")
        let (bytes, response) = try await http.data(for: request)
        let body = try NativeJSON.decoded(bytes), data = body["data"]
        guard response.statusCode == 200, body["code"].int == 200,
              data["signature"].text == NeteaseXEAPI.sign(timestamp: data["timestamp"].text, nonce: nonce) else { throw NativeMusicError.message("网易云播放公钥注册验证失败，请稍后重试") }
        return try NeteaseXEAPI.parseKey(data["encryptedData"].text)
    }
}
