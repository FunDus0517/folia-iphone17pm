import AVFoundation
import XCTest
@testable import FoliaNative

// native-ios/Tests/NativePlaybackTests.swift
// 生成真实 PCM WAV，由系统 AVPlayer 解码；不使用网页、模拟播放器或墙钟假进度。
final class NativePlaybackTests: XCTestCase {
    @MainActor
    func testGeneratedWAVActuallyAdvancesPausesAndSeeks() async throws {
        let url = try makeWAV(seconds: 6)
        let playback = NativePlayback(registerSystemControls: false)
        defer { playback.shutdown(); try? FileManager.default.removeItem(at: url) }
        let lines = [LyricLine(id: 0, time: 0, text: "第一句"),
                     LyricLine(id: 1, time: 1, text: "第二句"),
                     LyricLine(id: 2, time: 3, text: "第三句")]
        playback.play(track(id: "real-audio", duration: 6), url: url, lyrics: lines)
        try await waitUntil("系统播放器应解码并推进真实媒体时间") {
            playback.currentTime > 0.45 && playback.clock.position > 0.2
        }
        XCTAssertNil(playback.error)
        XCTAssertTrue(playback.isPlaying)
        XCTAssertEqual(playback.clock.duration, 6, accuracy: 0.1)
        playback.pause()
        try await Task.sleep(nanoseconds: 120_000_000)
        let pausedTime = playback.currentTime
        try await Task.sleep(nanoseconds: 350_000_000)
        XCTAssertFalse(playback.isPlaying)
        XCTAssertEqual(playback.currentTime, pausedTime, accuracy: 0.12)

        playback.seek(to: 3.25)
        try await waitUntil("暂停时 seek 应由 AVPlayer 真正完成") {
            abs(playback.currentTime - 3.25) < 0.12 && playback.activeLyricID == 2
        }
        XCTAssertFalse(playback.isPlaying)
        XCTAssertEqual(playback.clock.position, 3.25, accuracy: 0.2)
        playback.resume()
        try await waitUntil("恢复后真实媒体时间应继续增长") { playback.currentTime > 3.65 }
        playback.stop()
        XCTAssertNil(playback.track)
        XCTAssertNil(playback.activeLyricID)
        XCTAssertEqual(playback.clock.position, 0)
        XCTAssertEqual(playback.clock.duration, 0)
    }

    @MainActor
    func testTrackReplacementRejectsStaleLyricsAndSurvivesRepeatedNavigationEquivalent() async throws {
        let url = try makeWAV(seconds: 6)
        let playback = NativePlayback(registerSystemControls: false)
        defer { playback.shutdown(); try? FileManager.default.removeItem(at: url) }
        playback.play(track(id: "old", duration: 6), url: url, lyrics: [LyricLine(id: 0, time: 0, text: "旧歌词")])
        // 页面切换不重新初始化播放器。快速曲目替换会产生旧 KVO/seek 的迟到回调。
        for index in 0..<10 {
            playback.play(track(id: "new-\(index)", duration: 6), url: url,
                          lyrics: [LyricLine(id: 10, time: 0, text: "新歌词")])
        }
        playback.replaceLyrics([LyricLine(id: 99, time: 0, text: "迟到旧歌词")], trackID: "old")
        try await waitUntil("快速切歌后唯一播放器应继续播放") { playback.currentTime > 0.4 }
        XCTAssertEqual(playback.track?.id, "new-9")
        XCTAssertEqual(playback.lyrics.first?.text, "新歌词")
        XCTAssertEqual(playback.activeLyricID, 10)
        XCTAssertNil(playback.error)
        playback.pause()
        playback.replaceLyrics([LyricLine(id: 20, time: 0, text: "当前歌词")], trackID: "new-9")
        XCTAssertEqual(playback.activeLyricID, 20)
        playback.shutdown()
        playback.shutdown()
        playback.resume()
        XCTAssertNil(playback.track)
        XCTAssertFalse(playback.isPlaying)
    }

    @MainActor
    func testRealEndOfItemInvokesQueueOnce() async throws {
        let url = try makeWAV(seconds: 1.1)
        let playback = NativePlayback(registerSystemControls: false)
        defer { playback.shutdown(); try? FileManager.default.removeItem(at: url) }
        var nextCalls = 0
        playback.onNext = { nextCalls += 1 }
        playback.play(track(id: "end", duration: 1.1), url: url, lyrics: [])
        try await waitUntil("真实播放结束通知应进入原生队列") { nextCalls == 1 }
        try await Task.sleep(nanoseconds: 300_000_000)
        XCTAssertEqual(nextCalls, 1)
        XCTAssertFalse(playback.isPlaying)
    }

    @MainActor
    func testInterruptionAndHeadphoneDisconnectPreserveUserPause() async throws {
        let url = try makeWAV(seconds: 6)
        let playback = NativePlayback(registerSystemControls: false)
        defer { playback.shutdown(); try? FileManager.default.removeItem(at: url) }
        playback.play(track(id: "session", duration: 6), url: url, lyrics: [])
        try await waitUntil("中断前应实际播放") { playback.currentTime > 0.3 }
        NotificationCenter.default.post(name: AVAudioSession.interruptionNotification, object: nil,
                                        userInfo: [AVAudioSessionInterruptionTypeKey: AVAudioSession.InterruptionType.began.rawValue])
        try await waitUntil("来电中断应暂停") { !playback.isPlaying }
        playback.pause()
        NotificationCenter.default.post(name: AVAudioSession.interruptionNotification, object: nil,
                                        userInfo: [AVAudioSessionInterruptionTypeKey: AVAudioSession.InterruptionType.ended.rawValue,
                                                   AVAudioSessionInterruptionOptionKey: AVAudioSession.InterruptionOptions.shouldResume.rawValue])
        try await Task.sleep(nanoseconds: 250_000_000)
        XCTAssertFalse(playback.isPlaying, "中断期间用户暂停后不擅自恢复")
        playback.resume()
        try await waitUntil("用户可手动恢复") { playback.isPlaying }
        NotificationCenter.default.post(name: AVAudioSession.routeChangeNotification, object: nil,
                                        userInfo: [AVAudioSessionRouteChangeReasonKey: AVAudioSession.RouteChangeReason.oldDeviceUnavailable.rawValue])
        try await waitUntil("耳机断开应暂停") { !playback.isPlaying }
    }

    @MainActor
    func testInvalidAudioSurfacesRecoverableChineseError() async throws {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("folia-invalid-\(UUID().uuidString).wav")
        try Data("这不是音频".utf8).write(to: url)
        let playback = NativePlayback(registerSystemControls: false)
        defer { playback.shutdown(); try? FileManager.default.removeItem(at: url) }
        playback.play(track(id: "invalid", duration: 0), url: url, lyrics: [])
        try await waitUntil("不支持的音频应显示错误而不是界面冻结") { playback.error != nil }
        XCTAssertFalse(playback.isPlaying)
        XCTAssertTrue(playback.error?.hasPrefix("歌曲加载失败") == true || playback.error?.hasPrefix("歌曲播放中断") == true)
        playback.seek(to: .nan)
        XCTAssertEqual(playback.clock.position, 0)
        let validURL = try makeWAV(seconds: 2)
        defer { try? FileManager.default.removeItem(at: validURL) }
        playback.play(track(id: "recover", duration: 2), url: validURL, lyrics: [])
        try await waitUntil("加载失败后选择有效音频仍可继续") { playback.currentTime > 0.25 }
        XCTAssertNil(playback.error)
    }

    @MainActor
    private func waitUntil(_ message: String, timeout: Double = 12,
                           condition: @escaping @MainActor () -> Bool) async throws {
        let deadline = Date().addingTimeInterval(timeout)
        while !condition(), Date() < deadline { try await Task.sleep(nanoseconds: 40_000_000) }
        XCTAssertTrue(condition(), message)
    }

    private func track(id: String, duration: Double) -> FoliaNative.MusicTrack {
        FoliaNative.MusicTrack(id: id, title: "原生音频测试", artist: "测试音", duration: duration, source: .local)
    }

    private func makeWAV(seconds: Double) throws -> URL {
        let rate = 44_100
        let count = Int(Double(rate) * seconds)
        let bytes = UInt32(count * 2)
        var data = Data()
        data.append(contentsOf: "RIFF".utf8)
        appendLittleEndian(UInt32(36) + bytes, to: &data)
        data.append(contentsOf: "WAVEfmt ".utf8)
        appendLittleEndian(UInt32(16), to: &data)
        appendLittleEndian(UInt16(1), to: &data) // PCM
        appendLittleEndian(UInt16(1), to: &data) // 单声道
        appendLittleEndian(UInt32(rate), to: &data)
        appendLittleEndian(UInt32(rate * 2), to: &data)
        appendLittleEndian(UInt16(2), to: &data)
        appendLittleEndian(UInt16(16), to: &data)
        data.append(contentsOf: "data".utf8)
        appendLittleEndian(bytes, to: &data)
        for index in 0..<count {
            let sample = Int16(sin(2 * .pi * 440 * Double(index) / Double(rate)) * 1200)
            appendLittleEndian(sample, to: &data)
        }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("folia-native-\(UUID().uuidString).wav")
        try data.write(to: url, options: .atomic)
        return url
    }

    private func appendLittleEndian<T: FixedWidthInteger>(_ value: T, to data: inout Data) {
        var number = value.littleEndian
        withUnsafeBytes(of: &number) { data.append(contentsOf: $0) }
    }
}
