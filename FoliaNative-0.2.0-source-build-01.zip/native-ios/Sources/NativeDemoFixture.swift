import Foundation

// native-ios/Sources/NativeDemoFixture.swift
#if DEBUG
enum NativeDemoFixture {
    /// UI 测试播放真正的 PCM 文件，不用模拟进度或内嵌网络歌曲。
    static func make() throws -> [URL] {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("native-ui-demo", isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        var result: [URL] = []
        for ordinal in 0..<4 {
        let name = ordinal == 0 ? "原生播放验证" : ["", "封面墙验证", "原生队列验证", "返回播放验证"][ordinal]
        let audio = folder.appendingPathComponent(name + ".wav")
        let lyric = folder.appendingPathComponent(name + ".lrc")
        let rate = 8000, samples = rate * 30
        var data = Data()
        func ascii(_ value: String) { data.append(contentsOf: value.utf8) }
        func word(_ value: UInt16) { data.append(UInt8(value & 255)); data.append(UInt8(value >> 8)) }
        func integer(_ value: UInt32) { word(UInt16(value & 65535)); word(UInt16(value >> 16)) }
        ascii("RIFF"); integer(UInt32(36 + samples * 2)); ascii("WAVEfmt "); integer(16)
        word(1); word(1); integer(UInt32(rate)); integer(UInt32(rate * 2)); word(2); word(16)
        ascii("data"); integer(UInt32(samples * 2))
        for index in 0..<samples {
            let sample = Int16(sin(Double(index) * 2 * .pi * Double(220 + ordinal * 55) / Double(rate)) * 250)
            word(UInt16(bitPattern: sample))
        }
        try data.write(to: audio, options: .atomic)
        try "[00:00.00]原生歌词第一行\n[00:02.00]原生歌词第二行\n[00:04.00]原生歌词第三行\n[00:20.00]原生歌词第四行".write(to: lyric, atomically: true, encoding: .utf8)
        result += [audio, lyric]
        }
        return result
    }
}
#endif
