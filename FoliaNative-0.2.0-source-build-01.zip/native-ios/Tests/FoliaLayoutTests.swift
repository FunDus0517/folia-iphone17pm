import Foundation
import ImageIO
import XCTest
@testable import FoliaNative

// native-ios/Tests/FoliaLayoutTests.swift
// 验证生产布局规则和实际打包图片，不在测试中复制另一套曲墙实现。
final class FoliaLayoutTests: XCTestCase {
    func testWallColumnsAdaptAtProductionBreakpoints() {
        for width in [0.0, 320, 393, 440, 599.99] { XCTAssertEqual(FoliaLayout.columns(for: width), 2) }
        for width in [600.0, 768, 832, 899.99] { XCTAssertEqual(FoliaLayout.columns(for: width), 3) }
        for width in [900.0, 956, 1024] { XCTAssertEqual(FoliaLayout.columns(for: width), 4) }
    }

    func testPortraitTilesHaveCoverAspectAndNeverCollapseIntoListRows() {
        XCTAssertEqual(FoliaLayout.tileHeight(for: 200, index: 0), 256, accuracy: 0.001)
        XCTAssertEqual(FoliaLayout.tileHeight(for: 200, index: 1), 224, accuracy: 0.001)
        XCTAssertEqual(FoliaLayout.tileHeight(for: 200, index: 3), 256, accuracy: 0.001)
        for width in [0.0, 44, 100, 150, 200, 300] {
            for index in 0..<12 {
                let height = FoliaLayout.tileHeight(for: width, index: index)
                XCTAssertTrue(height.isFinite)
                XCTAssertGreaterThanOrEqual(height, 150)
            }
        }
    }

    func testInvalidAndHugeWidthsStayFiniteAndBounded() {
        for width in [Double.nan, .infinity, -.infinity, -1, 0] {
            for index in [0, 1, 3] { XCTAssertEqual(FoliaLayout.tileHeight(for: width, index: index), 150) }
        }
        XCTAssertEqual(FoliaLayout.tileHeight(for: 1200, index: 0), 1536, accuracy: 0.001)
        XCTAssertEqual(FoliaLayout.tileHeight(for: Double.greatestFiniteMagnitude, index: 0), 1536, accuracy: 0.001)
        XCTAssertEqual(FoliaLayout.tileHeight(for: Double.greatestFiniteMagnitude, index: 1), 1344, accuracy: 0.001)
    }

    func testTouchTargetsStayAtLeastFortyFourPoints() {
        XCTAssertGreaterThanOrEqual(FoliaLayout.minimumTouchSize, 44)
    }

    func testVersionFieldsAreExplicitAndNativeApplicationIdentityIsStable() {
        XCTAssertEqual(Bundle.main.bundleIdentifier, "io.github.fundus0517.folia.native")
        XCTAssertEqual(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String, "0.2.0")
        XCTAssertEqual(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String, "2")
    }

    func testBundledDefaultArtworkExistsAndDecodesWithoutNetwork() throws {
        let url = try XCTUnwrap(FoliaLayout.defaultArtwork, "默认封面应实际进入应用资源，而不是空 URL")
        XCTAssertTrue(url.isFileURL)
        let bytes = try Data(contentsOf: url)
        XCTAssertGreaterThan(bytes.count, 1024)
        let source = try XCTUnwrap(CGImageSourceCreateWithData(bytes as CFData, nil))
        XCTAssertEqual(CGImageSourceGetCount(source), 1)
        let image = try XCTUnwrap(CGImageSourceCreateImageAtIndex(source, 0, nil))
        XCTAssertGreaterThanOrEqual(image.width, 300)
        XCTAssertGreaterThanOrEqual(image.height, 300)
    }
}
