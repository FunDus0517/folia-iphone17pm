import XCTest

// native-ios/UITests/NativeNavigationTests.swift
@MainActor
final class NativeNavigationTests: XCTestCase {
    private var app: XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure = false
        XCUIDevice.shared.orientation = .portrait
        app = XCUIApplication()
        app.launchArguments = ["--ui-test-demo"]
        app.launch()
    }

    override func tearDownWithError() throws {
        XCUIDevice.shared.orientation = .portrait
        app.terminate()
    }

    func testRealAudioAdvancesAndLyricsAgreeOutsideAndInside() throws {
        let row = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH 'track-'")).firstMatch
        XCTAssertTrue(row.waitForExistence(timeout: 15))
        row.tap()
        let open = app.buttons["openPlayer"]
        XCTAssertTrue(open.waitForExistence(timeout: 15))
        open.tap()
        let seconds = app.staticTexts["playbackSeconds"]
        XCTAssertTrue(seconds.waitForExistence(timeout: 10))
        let advances = NSPredicate { _, _ in (Double(seconds.value as? String ?? "") ?? 0) > 1.2 }
        expectation(for: advances, evaluatedWith: nil)
        waitForExpectations(timeout: 15)
        app.buttons["fullToggle"].tap()
        XCTAssertEqual(app.buttons["fullToggle"].label, "播放")
        let before = Double(seconds.value as? String ?? "") ?? -1
        // 真实时钟暂停后两秒不得继续走，不用注入假时间。
        let paused = expectation(description: "真实播放暂停稳定")
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { paused.fulfill() }
        wait(for: [paused], timeout: 4)
        XCTAssertEqual(Double(seconds.value as? String ?? "") ?? -100, before, accuracy: 0.3)
        let slider = app.sliders["playbackProgress"]
        slider.adjust(toNormalizedSliderPosition: 0.75)
        let seeks = NSPredicate { _, _ in (Double(seconds.value as? String ?? "") ?? 0) > 20 }
        expectation(for: seeks, evaluatedWith: nil)
        waitForExpectations(timeout: 8)
        let line = app.buttons["lyric-row-3"]
        XCTAssertTrue(line.waitForExistence(timeout: 5))
        XCTAssertEqual(line.value as? String, "当前歌词")
        app.buttons["closePlayer"].tap()
        XCTAssertTrue(open.waitForExistence(timeout: 5))
        XCTAssertEqual(open.value as? String, "原生歌词第四行")
        open.tap()
        XCTAssertEqual(app.buttons["lyric-row-3"].value as? String, "当前歌词")
        attachScreenshot("原生竖屏歌词与实际播放进度")
    }

    func testRepeatedPlayerNavigationRotationAndNativeTabsRemainResponsive() throws {
        let row = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH 'track-'")).firstMatch
        XCTAssertTrue(row.waitForExistence(timeout: 15)); row.tap()
        let open = app.buttons["openPlayer"]
        XCTAssertTrue(open.waitForExistence(timeout: 15))
        app.buttons["miniToggle"].tap()
        for index in 0..<10 {
            open.tap()
            let close = app.buttons["closePlayer"]
            XCTAssertTrue(close.waitForExistence(timeout: 5))
            XCUIDevice.shared.orientation = index.isMultiple(of: 2) ? .landscapeLeft : .portrait
            XCTAssertTrue(app.sliders["playbackProgress"].waitForExistence(timeout: 5))
            XCTAssertTrue(close.isHittable)
            XCTAssertTrue(app.buttons["fullToggle"].isHittable)
            let screen = app.frame
            let controls = app.buttons["fullToggle"].frame
            XCTAssertGreaterThanOrEqual(controls.minY, screen.minY)
            XCTAssertLessThanOrEqual(controls.maxY, screen.maxY)
            if index == 0 { attachScreenshot("原生横屏布局") }
            close.tap()
            XCTAssertTrue(open.waitForExistence(timeout: 5))
        }
        XCUIDevice.shared.orientation = .portrait
        app.tabBars.buttons["设置"].tap()
        XCTAssertTrue(app.textFields["HTTPS 服务地址"].waitForExistence(timeout: 5))
        app.tabBars.buttons["QQ音乐"].tap()
        XCTAssertTrue(app.buttons["登录QQ音乐"].waitForExistence(timeout: 5))
        app.tabBars.buttons["网易云"].tap()
        app.buttons["登录网易云"].tap()
        XCTAssertTrue(app.textFields["中国大陆手机号"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["获取验证码"].exists)
        // 不点击发送按钮；测试绝不发送真实短信，也不登录真实账号。
        app.buttons["取消"].tap()
        app.tabBars.buttons["曲库"].tap()
        XCTAssertTrue(app.buttons["importMusic"].waitForExistence(timeout: 5))
        attachScreenshot("原生曲库与文件导入入口")
    }

    private func attachScreenshot(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways
        add(attachment)
    }
}
