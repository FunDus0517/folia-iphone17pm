import SwiftUI

// native-ios/Sources/FoliaPlayerControls.swift
struct FoliaPlayerControls: View {
    let track: MusicTrack
    @ObservedObject var playback: NativePlayback
    let compact: Bool
    let previous: () -> Void
    let next: () -> Void
    let queue: () -> Void

    var body: some View {
        Group {
            if compact {
                HStack(spacing: 18) {
                    transportButton(systemName: "backward.end.fill", label: "上一首", action: previous)
                    toggleButton(size: 52)
                    transportButton(systemName: "forward.end.fill", label: "下一首", action: next)
                    VStack(alignment: .leading, spacing: 6) {
                        titleRow
                        NativePlaybackProgress(clock: playback.clock, seek: { playback.seek(to: $0) })
                    }
                }.padding(.horizontal, 20).padding(.vertical, 12)
            } else {
                VStack(spacing: 13) {
                    titleRow
                    HStack(spacing: 37) {
                        transportButton(systemName: "backward.end.fill", label: "上一首", action: previous)
                        toggleButton(size: 64)
                        transportButton(systemName: "forward.end.fill", label: "下一首", action: next)
                    }
                    NativePlaybackProgress(clock: playback.clock, seek: { playback.seek(to: $0) })
                }.padding(.horizontal, 24).padding(.vertical, 20)
            }
        }
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: compact ? 30 : 36))
        .overlay { RoundedRectangle(cornerRadius: compact ? 30 : 36).stroke(.white.opacity(0.10), lineWidth: 0.8) }
        .shadow(color: .black.opacity(0.18), radius: 20, y: 9)
    }

    private var titleRow: some View {
        HStack(spacing: 12) {
            if !compact {
                TrackArtwork(url: track.artworkURL).frame(width: 40, height: 40)
                    .clipShape(RoundedRectangle(cornerRadius: 11))
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(track.title).font(.subheadline.weight(.semibold)).lineLimit(1)
                if !compact { Text(track.artist).font(.caption).foregroundStyle(.white.opacity(0.48)).lineLimit(1) }
            }
            Spacer(minLength: 0)
            Button(action: queue) {
                Image(systemName: "list.bullet").font(.system(size: 19, weight: .medium))
                    .frame(width: 44, height: 44).contentShape(Rectangle())
            }.buttonStyle(.plain).accessibilityLabel("播放队列").accessibilityIdentifier("openQueue")
        }
    }

    private func toggleButton(size: CGFloat) -> some View {
        Button { playback.toggle() } label: {
            Image(systemName: playback.isPlaying ? "pause.fill" : "play.fill")
                .font(.system(size: size * 0.34, weight: .semibold))
                .foregroundStyle(Color(red: 0.16, green: 0.14, blue: 0.12))
                .frame(width: size, height: size)
                .background(Color(red: 0.98, green: 0.96, blue: 0.90), in: Circle())
        }.buttonStyle(.plain).accessibilityLabel(playback.isPlaying ? "暂停" : "播放")
            .accessibilityIdentifier("fullToggle")
    }

    private func transportButton(systemName: String, label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: systemName).font(.system(size: 20, weight: .medium))
                .frame(width: 44, height: 44).contentShape(Rectangle())
        }.buttonStyle(.plain).accessibilityLabel(label)
            .accessibilityIdentifier(systemName == "backward.end.fill" ? "previousTrack" : "nextTrack")
    }
}

/// 只有本视图订阅连续播放进度，不让歌词舞台和封面随时间重绘。
struct NativePlaybackProgress: View {
    @ObservedObject var clock: PlaybackClock
    let seek: (Double) -> Void
    @State private var editing = false
    @State private var draft: Double = 0

    private var duration: Double { clock.duration.isFinite ? max(clock.duration, 1) : 1 }
    private var position: Double { min(max(clock.position.isFinite ? clock.position : 0, 0), duration) }

    var body: some View {
        VStack(spacing: 0) {
            Slider(value: Binding(get: { editing ? min(max(draft, 0), duration) : position }, set: { draft = $0 }),
                   in: 0...duration, onEditingChanged: { value in
                if value { draft = position; editing = true }
                else { editing = false; seek(draft) }
            })
            .tint(Color(red: 0.94, green: 0.91, blue: 0.80))
            .disabled(clock.duration <= 0)
            .accessibilityLabel("播放进度").accessibilityIdentifier("playbackProgress")
            HStack {
                NativeElapsedLabel(clock: clock, identifier: "playbackSeconds")
                Spacer()
                Text(Self.time(clock.duration))
            }.font(.system(size: 10, design: .monospaced)).foregroundStyle(.white.opacity(0.42))
        }
    }

    static func time(_ seconds: Double) -> String {
        let value = seconds.isFinite ? max(0, Int(seconds)) : 0
        return String(format: "%02d:%02d", value / 60, value % 60)
    }
}

struct NativeElapsedLabel: View {
    @ObservedObject var clock: PlaybackClock
    let identifier: String
    var body: some View {
        Text(NativePlaybackProgress.time(clock.position))
            .accessibilityIdentifier(identifier).accessibilityLabel("已播放时间")
            .accessibilityValue(String(format: "%.2f", clock.position))
    }
}

struct FoliaMiniProgress: View {
    @ObservedObject var clock: PlaybackClock
    private var fraction: Double {
        guard clock.duration.isFinite, clock.duration > 0, clock.position.isFinite else { return 0 }
        return min(max(clock.position / clock.duration, 0), 1)
    }
    var body: some View {
        GeometryReader { geometry in
            Capsule().fill(.white.opacity(0.12))
                .overlay(alignment: .leading) {
                    Capsule().fill(.white.opacity(0.55)).frame(width: geometry.size.width * CGFloat(fraction))
                }
        }.accessibilityHidden(true)
    }
}

struct FoliaQueueView: View {
    @ObservedObject var model: AppModel
    @ObservedObject var playback: NativePlayback
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            FoliaBackdrop(url: playback.track?.artworkURL, strength: 0.7)
            VStack(spacing: 12) {
                HStack {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("播放队列").font(.title2.weight(.semibold))
                        Text("\(model.queuedTracks.count) 首歌曲").font(.caption).foregroundStyle(.white.opacity(0.45))
                    }
                    Spacer()
                    Button { dismiss() } label: {
                        Image(systemName: "xmark").frame(width: 44, height: 44)
                            .background(.white.opacity(0.08), in: Circle())
                    }.buttonStyle(.plain).accessibilityLabel("关闭播放队列").accessibilityIdentifier("closeQueue")
                }.padding(.horizontal, 24).padding(.top, 24)
                ScrollView {
                    LazyVStack(spacing: 4) {
                        ForEach(model.queuedTracks) { track in
                            Button {
                                model.play(track, among: model.queuedTracks)
                                dismiss()
                            } label: {
                                queueRow(track)
                            }.buttonStyle(.plain).accessibilityIdentifier("queue-track-\(track.id)")
                                .accessibilityValue(track.id == playback.track?.id ? "正在播放" : "")
                        }
                    }.padding(.horizontal, 16).padding(.bottom, 24)
                }.scrollIndicators(.hidden).accessibilityIdentifier("playQueueScroll")
            }
        }.foregroundStyle(.white).preferredColorScheme(.dark)
    }

    private func queueRow(_ track: MusicTrack) -> some View {
        HStack(spacing: 13) {
            TrackArtwork(url: track.artworkURL).frame(width: 48, height: 48)
                .clipShape(RoundedRectangle(cornerRadius: 13))
            VStack(alignment: .leading, spacing: 5) {
                Text(track.title).font(.subheadline.weight(.medium)).lineLimit(1)
                Text(track.artist).font(.caption).foregroundStyle(.white.opacity(0.45)).lineLimit(1)
            }
            Spacer(minLength: 6)
            if track.id == playback.track?.id {
                Image(systemName: playback.isPlaying ? "speaker.wave.2.fill" : "pause.fill")
                    .font(.caption).foregroundStyle(Color(red: 0.94, green: 0.87, blue: 0.63))
            }
        }
        .padding(12)
        .background(.white.opacity(track.id == playback.track?.id ? 0.09 : 0), in: RoundedRectangle(cornerRadius: 22))
        .contentShape(Rectangle())
    }
}
