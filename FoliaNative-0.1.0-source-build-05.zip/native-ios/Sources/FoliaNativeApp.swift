import SwiftUI

// native-ios/Sources/FoliaNativeApp.swift
@main
struct FoliaNativeApp: App {
    @StateObject private var model = AppModel()
    var body: some Scene {
        WindowGroup {
            NativeRootView(model: model)
                .preferredColorScheme(.dark)
                .environment(\.locale, Locale(identifier: "zh_Hans_CN"))
                .task { await model.start() }
        }
    }
}
