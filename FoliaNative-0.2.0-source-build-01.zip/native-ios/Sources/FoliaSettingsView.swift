import SwiftUI

// native-ios/Sources/FoliaSettingsView.swift
// 设置继续使用真实原生连接与持久化值，只改变界面而不伪装服务已配置。
struct FoliaSettingsView: View {
    @ObservedObject var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var endpointText = ""
    @AppStorage("foliaNativeReducedEffects") private var reducedEffects = false
    var body: some View {
        NavigationStack {
            ZStack {
                FoliaBackdrop(url: nil, strength: 0.4)
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("让音乐回到画面中心").font(.system(size: 29, weight: .light, design: .serif))
                            Text("保留 Folia 的曲墙与歌词舞台，使用原生音频播放。").font(.subheadline).foregroundStyle(.white.opacity(0.5))
                        }.padding(.vertical, 16)
                        section("显示与动画") {
                            Toggle("轻量视觉效果", isOn: $reducedEffects)
                            Text("关闭背景封面模糊与纹理；歌词仍跟随真实播放进度。系统“减少动态效果”同时生效。").font(.caption).foregroundStyle(.white.opacity(0.5))
                        }
                        section("QQ 音乐连接") {
                            TextField("HTTPS 服务地址", text: $endpointText).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                                .padding(12).background(.black.opacity(0.25), in: RoundedRectangle(cornerRadius: 12)).accessibilityIdentifier("qqEndpointField")
                            Button("保存连接设置") { model.qqEndpoint = endpointText; Task { await model.saveQQEndpoint(); endpointText = model.qqEndpoint } }.frame(minHeight: 44)
                            Text("搜索可直连。QQ 登录、歌单和播放需要兼容服务；未配置时仍可搜索歌曲，登录与播放需先连接服务。").font(.caption).foregroundStyle(.white.opacity(0.5))
                        }
                        section("使用与数据") {
                            Text("网易云：手机号与短信验证码登录。验证码只在你自己的手机内填写。")
                            Text("本地音乐：从“文件”选择音频和同名 LRC，副本保存在应用内。旧网页曲库需要重新导入原文件。")
                            Text("锁屏、后台及耳机控制使用苹果系统播放器。真实账号与长时间播放仍以手机实测为准。")
                        }.font(.subheadline).foregroundStyle(.white.opacity(0.72))
                        NavigationLink("查看开源许可证") { FoliaLicenseView() }.padding(18).modifier(FoliaGlass())
                        Text("原生界面体验版 · 0.2.0").font(.caption).foregroundStyle(.white.opacity(0.35)).frame(maxWidth: .infinity).padding(.bottom, 30)
                    }.padding(.horizontal, 20)
                }.scrollDismissesKeyboard(.interactively)
            }
            .navigationTitle("设置").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("完成") { dismiss() }.accessibilityIdentifier("closeSettings") } }
            .onAppear { endpointText = model.qqEndpoint }
        }.preferredColorScheme(.dark)
    }
    private func section<Content: View>(_ title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(title).font(.headline)
            content()
        }.frame(maxWidth: .infinity, alignment: .leading).padding(18).modifier(FoliaGlass())
    }
}

private struct FoliaLicenseView: View {
    private var content: String {
        ["AGPL-3.0", "api-enhanced-MIT"].map { name in
            guard let url = Bundle.main.url(forResource: name, withExtension: "txt"), let value = try? String(contentsOf: url, encoding: .utf8) else { return "\(name)：请参阅随发行版提供的对应源码。" }
            return "\(name)\n\n\(value)"
        }.joined(separator: "\n\n————\n\n")
    }
    var body: some View { ScrollView { Text(content).font(.caption).textSelection(.enabled).padding() }.navigationTitle("开源许可证") }
}
