# 原生适配与开源来源

本目录是 Folia 原生 iOS 工程。界面以 SwiftUI 重建，音频由 AVFoundation 播放，不包含浏览器、Capacitor 或网页渲染壳。0.2.0 的界面重建以原 Folia 的封面曲墙、沉浸式歌词和播放胶囊为体验参照，并不因此宣称桌面端所有渲染模式、歌词格式、模组及 AI 功能已经迁移。

Folia 其余代码与本原生适配继续遵循仓库根许可证 AGPL-3.0；许可全文位于本目录的 `Resources/AGPL-3.0.txt`，作为原生应用资源打包。发行版须同时提供对应的完整源代码与本说明。

网易云协议算法、加密常量与接口字段参考已锁定依赖 `@neteasecloudmusicapienhanced/api` 4.41.1 的 `util/crypto.js`、`module/*.js`，在 `Sources/Services/` 中用 Swift 适配。上游项目为 <https://github.com/NeteaseCloudMusicApiEnhanced/api-enhanced>，其 MIT 版权与许可全文位于 `Resources/api-enhanced-MIT.txt`，随源码和原生资源提供；不将上游 JavaScript 打入应用。

本实现不携带歌曲、付费权限或用户账号。协议离线对照测试及模拟器 UI 测试不等于真实账号、在线服务、iPhone 后台或长时间流畅度的验收。QQ 登录、个人歌单与播放仍依赖兼容的用户 HTTPS 服务；没有真实联调证据时不得标为已验收。
