import XCTest

// native-ios/UITests/NativeNavigationTests.swift
@MainActor
final class NativeNavigationTests: XCTestCase {
    private var app: XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure = false
        XCUIDevice.shared.orientation = .portrait
        app = XCUIApplication()
        app.launchArguments = ["--ui-test-demo"]
        app.launch()
    }

    override func tearDownWithError() throws {
        attachScreenshot("最终界面与失败现场")
        let hierarchy = XCTAttachment(string: app.debugDescription)
        hierarchy.name = "实际原生无障碍层级"; hierarchy.lifetime = .keepAlways
        add(hierarchy)
        XCUIDevice.shared.orientation = .portrait
        app.terminate()
    }

    func testRealAudioAdvancesAndLyricsAgreeOutsideAndInside() throws {
        let row = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH 'track-'")).firstMatch
        XCTAssertTrue(row.waitForExistence(timeout: 15))
        row.tap()
        let open = app.buttons["openPlayer"]
        XCTAssertTrue(open.waitForExistence(timeout: 15))
        open.tap()
        let seconds = app.staticTexts["playbackSeconds"]
        XCTAssertTrue(seconds.waitForExistence(timeout: 10))
        let advances = NSPredicate { _, _ in (Double(seconds.value as? String ?? "") ?? 0) > 1.2 }
        expectation(for: advances, evaluatedWith: nil)
        waitForExpectations(timeout: 15)
        app.buttons["fullToggle"].tap()
        XCTAssertEqual(app.buttons["fullToggle"].label, "播放")
        let before = Double(seconds.value as? String ?? "") ?? -1
        // 真实时钟暂停后两秒不得继续走，不用注入假时间。
        let paused = expectation(description: "真实播放暂停稳定")
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { paused.fulfill() }
        wait(for: [paused], timeout: 4)
        XCTAssertEqual(Double(seconds.value as? String ?? "") ?? -100, before, accuracy: 0.3)
        let slider = app.sliders["playbackProgress"]
        slider.adjust(toNormalizedSliderPosition: 0.75)
        let seeks = NSPredicate { _, _ in (Double(seconds.value as? String ?? "") ?? 0) > 20 }
        expectation(for: seeks, evaluatedWith: nil)
        waitForExpectations(timeout: 8)
        let line = app.buttons["lyric-row-3"]
        XCTAssertTrue(line.waitForExistence(timeout: 5))
        XCTAssertEqual(line.value as? String, "当前歌词")
        app.buttons["closePlayer"].tap()
        XCTAssertTrue(app.buttons["closePlayer"].waitForNonExistence(timeout: 8), "完整播放页必须真正关闭")
        XCTAssertTrue(open.waitForExistence(timeout: 5))
        XCTAssertEqual(open.value as? String, "原生歌词第四行")
        open.tap()
        XCTAssertEqual(app.buttons["lyric-row-3"].value as? String, "当前歌词")
        attachScreenshot("原生竖屏歌词与实际播放进度")
    }

    func testRepeatedPlayerNavigationRotationAndNativeTabsRemainResponsive() throws {
        let row = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH 'track-'")).firstMatch
        XCTAssertTrue(row.waitForExistence(timeout: 15)); row.tap()
        let open = app.buttons["openPlayer"]
        XCTAssertTrue(open.waitForExistence(timeout: 15))
        app.buttons["miniToggle"].tap()
        for index in 0..<10 {
            XCTAssertTrue(open.isHittable)
            open.tap()
            let close = app.buttons["closePlayer"]
            XCTAssertTrue(close.waitForExistence(timeout: 5))
            XCUIDevice.shared.orientation = index.isMultiple(of: 2) ? .landscapeLeft : .portrait
            let landscape = index.isMultiple(of: 2)
            let rotated = NSPredicate { _, _ in
                let frame = self.app.frame
                return landscape ? frame.width > frame.height : frame.height > frame.width
            }
            expectation(for: rotated, evaluatedWith: nil)
            waitForExpectations(timeout: 8)
            XCTAssertTrue(app.sliders["playbackProgress"].waitForExistence(timeout: 5))
            XCTAssertTrue(close.isHittable)
            XCTAssertTrue(app.buttons["fullToggle"].isHittable)
            let screen = app.frame
            let controls = app.buttons["fullToggle"].frame
            XCTAssertGreaterThanOrEqual(controls.minY, screen.minY)
            XCTAssertLessThanOrEqual(controls.maxY, screen.maxY)
            if index == 0 { attachScreenshot("原生横屏布局") }
            close.tap()
            XCTAssertTrue(close.waitForNonExistence(timeout: 8), "第\(index + 1)轮播放页仍未退出")
            XCTAssertTrue(open.waitForExistence(timeout: 5))
            XCTAssertTrue(open.isHittable)
        }
        XCUIDevice.shared.orientation = .portrait
        assertPlaybackDoesNotCoverTabs()
        let settings = app.tabBars.buttons["设置"]
        XCTAssertTrue(settings.isHittable)
        settings.tap()
        expectation(for: NSPredicate(format: "selected == true"), evaluatedWith: settings)
        waitForExpectations(timeout: 5)
        XCTAssertTrue(app.navigationBars["设置"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.textFields["qqEndpointField"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.textFields["qqEndpointField"].isHittable)
        app.tabBars.buttons["QQ音乐"].tap()
        XCTAssertTrue(app.buttons["登录QQ音乐"].waitForExistence(timeout: 5))
        app.tabBars.buttons["网易云"].tap()
        app.buttons["登录网易云"].tap()
        XCTAssertTrue(app.textFields["中国大陆手机号"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["获取验证码"].exists)
        // 不点击发送按钮；测试绝不发送真实短信，也不登录真实账号。
        app.buttons["取消"].tap()
        app.tabBars.buttons["曲库"].tap()
        XCTAssertTrue(app.buttons["importMusic"].waitForExistence(timeout: 5))
        attachScreenshot("原生曲库与文件导入入口")
    }

    func testFreshSettingsCanBeSelectedAndAddressCanBeEdited() throws {
        let row = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH 'track-'")).firstMatch
        XCTAssertTrue(row.waitForExistence(timeout: 15))
        app.tabBars.buttons["设置"].tap()
        let field = app.textFields["qqEndpointField"]
        XCTAssertTrue(field.waitForExistence(timeout: 5))
        XCTAssertTrue(app.tabBars.buttons["设置"].isSelected)
        XCTAssertTrue(field.isHittable)
        field.tap()
        // URL 键盘切换符号页时逐键等待原生输入响应，最终仍严格核对全部字符。
        for character in "https://example.org" { field.typeText(String(character)) }
        XCTAssertEqual(field.value as? String, "https://example.org")
        // 不保存示例地址，不发送网络请求或创建会话。
        attachScreenshot("原生设置可编辑且无标签栏遮挡")
    }

    private func assertPlaybackDoesNotCoverTabs() {
        let tabBar = app.tabBars.firstMatch
        XCTAssertTrue(tabBar.exists)
        let bar = tabBar.frame
        for id in ["openPlayer", "miniToggle"] {
            let button = app.buttons[id]
            XCTAssertTrue(button.exists)
            XCTAssertLessThanOrEqual(button.frame.maxY, bar.minY + 1, "\(id) 不得覆盖标签栏；播放条=\(button.frame)，标签栏=\(bar)")
        }
        attachScreenshot("底部播放条与标签栏实际位置")
    }

    private func attachScreenshot(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways
        add(attachment)
    }
}
