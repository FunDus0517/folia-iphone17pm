import Foundation
import CommonCrypto
import CryptoKit
import Security

// native-ios/Sources/Services/NeteaseCrypto.swift
// Native port of src/services/nativeNetease/crypto.ts; api-enhanced 4.41.1 protocol (MIT).
enum NeteaseCrypto {
    static let eapiKey = Data("e82ckenh8dichen8".utf8)
    static let staticXeapiKey = Data(hex: "ab1d5a430f6bb04a3f01e81ddd72bd916d5ce591248ac128714806d7f8fb1b84")!
    private static let modulus = Data(hex: "e0b509f6259df8642dbc35662901477df22677ec152b5ff68ace615bb7b725152b3ab17a876aea8a5aa76d2e417629ec4ee341f56135fccf695280104e0312ecbda92557c93870114af6c9d05c4f7f0c3685b7a46bee255932575cce10b424d813cfe4875d3e82047b97ddef52741d546b8e289dc6935b3ece0462db0a22b8e7")!

    static func random(_ count: Int) throws -> Data {
        var bytes = [UInt8](repeating: 0, count: count)
        guard SecRandomCopyBytes(kSecRandomDefault, count, &bytes) == errSecSuccess else { throw NativeMusicError.message("系统安全随机数生成失败，请重试") }
        return Data(bytes)
    }

    static func aes(_ input: Data, key: Data, decrypt: Bool = false, iv: Data? = nil) throws -> Data {
        guard [16, 24, 32].contains(key.count), !input.isEmpty || !decrypt else { throw NativeMusicError.message("网易云加密数据格式异常") }
        guard iv == nil || iv?.count == kCCBlockSizeAES128 else { throw NativeMusicError.message("网易云加密向量格式异常") }
        if decrypt && input.count % kCCBlockSizeAES128 != 0 { throw NativeMusicError.message("网易云加密响应被截断") }
        var output = Data(count: input.count + kCCBlockSizeAES128)
        var length = 0
        let capacity = output.count
        let operation = CCOperation(decrypt ? kCCDecrypt : kCCEncrypt)
        // CommonCrypto's ECB success status is not a strict PKCS#7 validity guarantee.
        // Decrypt whole blocks, then verify every padding byte ourselves, matching the TS transport.
        let options = CCOptions((decrypt ? 0 : kCCOptionPKCS7Padding) | (iv == nil ? kCCOptionECBMode : 0))
        let status = output.withUnsafeMutableBytes { destination in
            input.withUnsafeBytes { source in
                key.withUnsafeBytes { secret in
                    if let iv {
                        return iv.withUnsafeBytes { vector in
                            CCCrypt(operation, CCAlgorithm(kCCAlgorithmAES), options, secret.baseAddress, key.count,
                                    vector.baseAddress, source.baseAddress, input.count, destination.baseAddress, capacity, &length)
                        }
                    }
                    return CCCrypt(operation, CCAlgorithm(kCCAlgorithmAES), options, secret.baseAddress, key.count,
                                   nil, source.baseAddress, input.count, destination.baseAddress, capacity, &length)
                }
            }
        }
        guard status == kCCSuccess else { throw NativeMusicError.message("网易云加密响应校验失败（\(status)）") }
        output.count = length
        if decrypt {
            guard let padding = output.last, (1...kCCBlockSizeAES128).contains(Int(padding)),
                  output.count >= Int(padding), output.suffix(Int(padding)).allSatisfy({ $0 == padding }) else {
                throw NativeMusicError.message("网易云加密响应填充校验失败")
            }
            output.removeLast(Int(padding))
        }
        return output
    }

    static func weapi(_ data: NativeJSON, secret: String? = nil) throws -> [String: String] {
        let alphabet = Array("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
        let key = try secret ?? String(random(16).map { alphabet[Int($0) % alphabet.count] })
        guard key.utf8.count == 16, key.allSatisfy({ $0.isASCII && $0.isLetter || $0.isASCII && $0.isNumber }) else { throw NativeMusicError.message("网易云请求密钥格式异常") }
        let iv = Data("0102030405060708".utf8)
        let first = try aes(data.encoded(), key: Data("0CoJUm6Qyw8W8jud".utf8), iv: iv).base64EncodedString()
        let params = try aes(Data(first.utf8), key: Data(key.utf8), iv: iv).base64EncodedString()
        return ["params": params, "encSecKey": try rsaRaw(key)]
    }

    static func eapi(uri: String, data: NativeJSON) throws -> [String: String] {
        guard let text = String(data: try data.encoded(), encoding: .utf8) else { throw NativeMusicError.message("网易云请求编码失败") }
        let digest = Insecure.MD5.hash(data: Data("nobody\(uri)use\(text)md5forencrypt".utf8)).map { String(format: "%02x", $0) }.joined()
        let plain = Data("\(uri)-36cd479b6b5-\(text)-36cd479b6b5-\(digest)".utf8)
        return ["params": try aes(plain, key: eapiKey).hex.uppercased()]
    }

    // SecKey performs raw RSA modular exponentiation on a modulus-sized, left-zero-padded block.
    private static func rsaRaw(_ secret: String) throws -> String {
        let integer = Data([0x02, 0x81, 0x81, 0]) + modulus
        let exponent = Data([0x02, 0x03, 0x01, 0, 0x01])
        let der = Data([0x30, 0x81, 0x89]) + integer + exponent
        let attributes: [String: Any] = [kSecAttrKeyType as String: kSecAttrKeyTypeRSA, kSecAttrKeyClass as String: kSecAttrKeyClassPublic, kSecAttrKeySizeInBits as String: 1024]
        var error: Unmanaged<CFError>?
        guard let key = SecKeyCreateWithData(der as CFData, attributes as CFDictionary, &error) else { throw NativeMusicError.message("网易云 RSA 公钥初始化失败") }
        let reversed = Data(secret.utf8.reversed())
        let padded = Data(repeating: 0, count: 128 - reversed.count) + reversed
        guard let output = SecKeyCreateEncryptedData(key, .rsaEncryptionRaw, padded as CFData, &error) as Data? else { throw NativeMusicError.message("网易云 RSA 请求编码失败") }
        return output.hex
    }

    static func hmac(_ data: Data, key: Data) -> Data { Data(HMAC<SHA256>.authenticationCode(for: data, using: SymmetricKey(data: key))) }
}

extension Data {
    init?(hex: String) {
        guard hex.count % 2 == 0 else { return nil }
        var bytes = [UInt8](); bytes.reserveCapacity(hex.count / 2)
        var index = hex.startIndex
        while index < hex.endIndex {
            let end = hex.index(index, offsetBy: 2)
            guard let byte = UInt8(hex[index..<end], radix: 16) else { return nil }
            bytes.append(byte); index = end
        }
        self.init(bytes)
    }
    var hex: String { map { String(format: "%02x", $0) }.joined() }
}
