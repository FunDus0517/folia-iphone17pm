import Foundation

// native-ios/Sources/Services/NativeHTTPClient.swift
protocol NativeHTTPTransport: Sendable {
    func data(for request: URLRequest) async throws -> (Data, HTTPURLResponse)
}

private final class NativeRedirectPolicy: NSObject, URLSessionTaskDelegate {
    // Do not forward a provider Cookie or QQ session to a redirect on a different host.
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        let original = task.originalRequest?.url
        completionHandler(request.url?.scheme == "https" && request.url?.host == original?.host ? request : nil)
    }
}

struct URLSessionNativeTransport: NativeHTTPTransport {
    private let session: URLSession
    init() {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.urlCache = nil
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        configuration.waitsForConnectivity = false
        session = URLSession(configuration: configuration, delegate: NativeRedirectPolicy(), delegateQueue: nil)
    }

    func data(for request: URLRequest) async throws -> (Data, HTTPURLResponse) {
        do {
            let (data, response) = try await session.data(for: request)
            try Task.checkCancellation()
            guard let response = response as? HTTPURLResponse else { throw NativeMusicError.message("音乐服务没有返回有效的网络响应") }
            guard data.count <= 8 * 1024 * 1024 else { throw NativeMusicError.message("音乐服务响应过大，请缩小查询范围") }
            return (data, response)
        } catch let error as URLError {
            if error.code == .cancelled { throw CancellationError() }
            switch error.code {
            case .timedOut: throw NativeMusicError.message("音乐服务连接超时，请检查网络后重试")
            case .notConnectedToInternet, .networkConnectionLost: throw NativeMusicError.message("网络连接已断开，请恢复网络后重试")
            case .secureConnectionFailed, .serverCertificateUntrusted: throw NativeMusicError.message("音乐服务的 HTTPS 连接验证失败")
            default: throw NativeMusicError.message("连接音乐服务失败，请稍后重试（\(error.code.rawValue)）")
            }
        }
    }
}
