import Foundation

// native-ios/Sources/Services/QQNativeProvider.swift
// Search follows qqLyricProvider.ts; login/play/library require the user's qq-music-api service.
struct QQLoginQRCode: Sendable {
    let id: String
    let imageURL: URL?
    let imageData: Data?
    let expiresAt: Date
}
enum QQLoginPollResult: Sendable { case waiting, scanned, expired, authorized(MusicAccount) }

actor QQNativeProvider {
    private let http: any NativeHTTPTransport
    private let transport: QQNativeTransport
    private var collectionMetadata: [String: NativeJSON] = [:]
    private var activeQRCode: String?
    private var generation = 0
    init(http: any NativeHTTPTransport, vault: any NativeSessionVault) {
        self.http = http; transport = QQNativeTransport(http: http, vault: vault)
    }

    func setEndpoint(_ url: URL?) async {
        generation += 1; activeQRCode = nil; collectionMetadata = [:]
        await transport.setEndpoint(url)
    }

    func search(_ query: String) async throws -> [MusicTrack] {
        let parameters: [String: NativeJSON] = ["search_id": .string(String(Int64(Date().timeIntervalSince1970 * 1000))), "remoteplace": .string("search.android.keyboard"),
            "query": .string(String(query.prefix(60))), "search_type": .number(0), "num_per_page": .number(50), "page_num": .number(1),
            "highlight": .number(0), "nqc_flag": .number(0), "page_id": .number(1), "grp": .number(1)]
        let comm: [String: NativeJSON] = ["ct": .number(11), "cv": .string("1003006"), "v": .string("1003006"), "os_ver": .string("15"), "phonetype": .string("24122RKC7C"),
            "rom": .string("Redmi/miro/miro:15/AE3A.240806.005/OS2.0.102.0.VOMCNXM:user/release-keys"), "tmeAppID": .string("qqmusiclight"),
            "nettype": .string("NETWORK_WIFI"), "udid": .string("0"), "uid": .string("0")]
        let payload: NativeJSON = .object(["comm": .object(comm), "request": .object(["method": .string("DoSearchForQQMusicLite"), "module": .string("music.search.SearchCgiService"), "param": .object(parameters)])])
        var request = URLRequest(url: URL(string: "https://u.y.qq.com/cgi-bin/musicu.fcg")!)
        request.httpMethod = "POST"; request.httpBody = try payload.encoded()
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("tmeLoginType=-1;", forHTTPHeaderField: "Cookie"); request.setValue("okhttp/3.14.9", forHTTPHeaderField: "User-Agent")
        let (data, response) = try await http.data(for: request)
        guard (200..<300).contains(response.statusCode) else { throw NativeMusicError.message("QQ音乐搜索连接失败（HTTP \(response.statusCode)）") }
        let body = try NativeJSON.decoded(data)
        guard body["code"].int == 0, body["request"]["code"].int == 0, !body["request"]["data"].isNull else { throw NativeMusicError.message("QQ音乐暂未完成搜索，请稍后重试") }
        return body["request"]["data"]["body"]["item_song"].array.compactMap(QQNativeNormalization.track)
    }

    func account() async throws -> MusicAccount? {
        guard try await transport.hasSession() else { return nil }
        let body = try await transport.request("/login/status")
        return QQNativeNormalization.account(body["data"]["profile"])
    }

    func collections() async throws -> [MusicCollection] {
        let started = generation
        let body = try await transport.request("/user/playlist")
        guard started == generation else { throw CancellationError() }
        guard !body["playlist"].isNull else { throw NativeMusicError.message("QQ音乐未返回歌单，请先登录并确认服务端登录状态") }
        let raw = body["playlist"].array
        collectionMetadata = raw.reduce(into: [:]) { if let item = QQNativeNormalization.collection($1) { $0[item.id] = $1 } }
        return raw.compactMap(QQNativeNormalization.collection)
    }

    func resolve(_ track: MusicTrack) async throws -> ResolvedTrack {
        let started = generation
        let url = try await playbackURL(track)
        guard started == generation else { throw CancellationError() }
        let lyric: String
        do { lyric = try await lyrics(for: track) }
        catch is CancellationError { throw CancellationError() }
        catch { lyric = "" } // Missing lyrics do not invalidate audio; service changes and cancellation do.
        try Task.checkCancellation()
        guard started == generation else { throw CancellationError() }
        return ResolvedTrack(url: url, lyricText: lyric)
    }

    func playbackURL(_ track: MusicTrack) async throws -> URL {
        let started = generation
        try Self.validateID(track.id)
        let body = try await transport.request("/getMusicPlay/\(track.id)", query: ["quality": "128"])
        try Task.checkCancellation()
        guard started == generation else { throw CancellationError() }
        let playURL = body["data"]["playUrl"]
        let entry = playURL[track.id].isNull ? (playURL.object.values.first ?? .null) : playURL[track.id]
        guard let url = NativeURLRules.https(entry["url"].text) else { throw NativeMusicError.message("QQ音乐没有提供这首歌的可播放地址。请检查登录、会员权限或所在地区；可在官方应用确认") }
        return url
    }

    func lyrics(for track: MusicTrack) async throws -> String {
        let started = generation
        try Self.validateID(track.id)
        let body = try await transport.request("/getLyric/\(track.id)", query: ["isFormat": "false", "songmid": track.id])
        try Task.checkCancellation()
        guard started == generation else { throw CancellationError() }
        guard body["response"]["code"].int == 0 else { throw NativeMusicError.message("QQ音乐暂未提供这首歌的歌词，请稍后重试") }
        return body["response"]["lyric"].text
    }

    func tracks(in collection: MusicCollection) async throws -> [MusicTrack] {
        try Self.validateID(collection.id)
        let metadata = collectionMetadata[collection.id] ?? .null
        let dirID = metadata["dirId"].isNull ? metadata["dirid"].int : metadata["dirId"].int
        if !metadata["dirName"].isNull {
            let path = dirID == 201 ? "/user/liked-songs" : "/user/playlist-detail"
            var result: [MusicTrack] = [], offset = 0
            repeat {
                let body = try await transport.request(path, query: ["tid": collection.id, "dirid": String(dirID), "limit": "100", "offset": String(offset)])
                guard !body["songs"].isNull else { throw NativeMusicError.message("QQ音乐没有返回歌单曲目，请更新兼容服务并重新登录") }
                let page = body["songs"].array; result += page.compactMap(QQNativeNormalization.track); offset += page.count
                if page.isEmpty || (!body["more"].flag && (body["total"].isNull || offset >= body["total"].int)) { return result }
            } while offset < 10000
            throw NativeMusicError.message("歌单曲目过多，请在 QQ音乐官方应用分批整理")
        }
        let body = try await transport.request("/getSongListDetail/\(collection.id)", query: ["disstid": collection.id])
        let detail = body["response"]["cdlist"].array.first ?? .null
        guard body["response"]["code"].int == 0, !detail["dissname"].text.isEmpty else { throw NativeMusicError.message("QQ音乐未开放这个歌单的读取权限；私密歌单需本人登录及新版兼容服务") }
        return detail["songlist"].array.compactMap(QQNativeNormalization.track)
    }

    func logout() async throws {
        generation += 1; activeQRCode = nil; collectionMetadata = [:]
        try await transport.clearSession()
    }
    static func validateID(_ id: String) throws {
        guard !id.isEmpty, id.utf8.count <= 128, id.utf8.allSatisfy({ (48...57).contains($0) || (65...90).contains($0) || (97...122).contains($0) || $0 == 95 || $0 == 45 }) else { throw NativeMusicError.message("QQ音乐歌曲或歌单编号无效") }
    }
}

extension QQNativeProvider {
    func createQRCode() async throws -> QQLoginQRCode {
        let started = generation
        let keyBody = try await transport.request("/login/qr/key", query: ["channel": "qq"])
        let key = keyBody["data"]["unikey"].text
        guard !key.isEmpty else { throw NativeMusicError.message("QQ音乐服务未生成二维码编号，请稍后重试") }
        let imageBody = try await transport.request("/login/qr/create", query: ["key": key])
        guard started == generation else { throw CancellationError() }
        let image = imageBody["data"]["qrimg"].text
        var imageData: Data?, imageURL: URL?
        if image.hasPrefix("data:image/"), let separator = image.firstIndex(of: ","), image[..<separator].hasSuffix(";base64") {
            imageData = Data(base64Encoded: String(image[image.index(after: separator)...]))
            if let data = imageData, data.count > 2 * 1024 * 1024 { imageData = nil }
        } else { imageURL = NativeURLRules.https(image) }
        guard imageData != nil || imageURL != nil else { throw NativeMusicError.message("QQ音乐服务返回的二维码图片无效，请刷新二维码") }
        await transport.activateQRCode(key)
        guard started == generation else { throw CancellationError() }
        activeQRCode = key
        return QQLoginQRCode(id: key, imageURL: imageURL, imageData: imageData, expiresAt: Date().addingTimeInterval(175))
    }

    func pollQRCode(_ id: String) async throws -> QQLoginPollResult {
        guard activeQRCode == id else { throw CancellationError() }
        let body = try await transport.request("/login/qr/check", query: ["key": id])
        guard activeQRCode == id else { throw CancellationError() }
        switch body["code"].int {
        case 801: return .waiting
        case 802: return .scanned
        case 803:
            try await transport.storeSession(cookie: body["cookie"].text, qrID: id)
            guard activeQRCode == id else { throw CancellationError() }
            guard let user = try await account() else { throw NativeMusicError.message("QQ音乐扫码已确认，但读取账号失败，请重试账号刷新") }
            guard activeQRCode == id else { throw CancellationError() }
            activeQRCode = nil
            await transport.finishQRCode(id)
            return .authorized(user)
        case 800:
            activeQRCode = nil
            if body["failureReason"].text == "qr-timeout" || ["failureStage", "failureReason", "upstreamCode", "retryAfterMs"].allSatisfy({ body[$0].isNull }) { return .expired }
            if body["failureReason"].text == "user-canceled" { throw NativeMusicError.message("你已在手机上取消 QQ音乐登录") }
            if body["upstreamCode"].int == 20279 { throw NativeMusicError.message("QQ音乐登录设备已达上限，请在官方应用移除旧设备后重试") }
            throw NativeMusicError.message("QQ音乐登录没有完成，请稍后刷新二维码或检查你的音乐服务")
        default: throw NativeMusicError.message("QQ音乐服务返回了未识别的扫码状态，请重新生成二维码")
        }
    }

    func cancelQRCode(_ id: String) async {
        guard activeQRCode == id else { return }
        activeQRCode = nil
        try? await transport.cancelAuthentication(id)
        _ = try? await transport.request("/login/qr/cancel", query: ["key": id])
    }
}
