import SwiftUI

// native-ios/Sources/OnlineLibraryCards.swift
// Full-bleed artwork, static scrims and thin frames echo Folia without a blur layer per card.
struct OnlineCollectionCard: View {
    let collection: MusicCollection
    var body: some View {
        Color.clear.aspectRatio(0.84, contentMode: .fit)
            .overlay {
                GeometryReader { geometry in
                    TrackArtwork(url: collection.artworkURL).frame(width: geometry.size.width, height: geometry.size.height)
                }
            }
            .overlay {
                LinearGradient(stops: [.init(color: .clear, location: 0.25), .init(color: .black.opacity(0.18), location: 0.45), .init(color: .black.opacity(0.88), location: 1)], startPoint: .top, endPoint: .bottom)
            }
            .overlay(alignment: .topLeading) {
                Text("歌单 · \(collection.trackCount) 首").font(.system(size: 9, weight: .medium, design: .monospaced))
                    .padding(.horizontal, 7).padding(.vertical, 5).background(.black.opacity(0.35), in: Capsule()).padding(10)
            }
            .overlay(alignment: .bottomLeading) {
                VStack(alignment: .leading, spacing: 7) {
                    Text(collection.title).font(.system(size: 15, weight: .semibold)).lineLimit(3).multilineTextAlignment(.leading)
                    HStack {
                        Text(collection.source.title).font(.system(size: 9)).foregroundStyle(.white.opacity(0.55))
                        Spacer()
                        Image(systemName: "arrow.up.right").font(.system(size: 10, weight: .medium)).foregroundStyle(.white.opacity(0.65))
                    }
                }.padding(13)
            }
            .foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.15), lineWidth: 1))
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("\(collection.title)，\(collection.trackCount) 首，打开歌单")
    }
}

struct OnlineMessageCard: View {
    let text: String
    var symbol: String
    var body: some View {
        HStack(alignment: .top, spacing: 11) {
            Image(systemName: symbol).font(.system(size: 17)).frame(width: 22).padding(.top, 1)
            Text(text).font(.system(size: 12)).lineSpacing(5).fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
        .foregroundStyle(.white.opacity(0.52)).padding(18).frame(maxWidth: .infinity, alignment: .leading)
        .background(.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 17))
        .overlay(RoundedRectangle(cornerRadius: 17).stroke(.white.opacity(0.065), lineWidth: 1))
    }
}
