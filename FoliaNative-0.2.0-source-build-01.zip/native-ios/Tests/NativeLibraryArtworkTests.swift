import AVFoundation
import CoreMedia
import Foundation
import ImageIO
import UniformTypeIdentifiers
import XCTest
@testable import FoliaNative

// native-ios/Tests/NativeLibraryArtworkTests.swift
// Dedicated artwork tests use isolated owned roots and locally generated images/audio, never user files.
final class NativeLibraryArtworkTests: XCTestCase {
    func testThumbnailIsJPEGAndBoundsLargeArtworkTo600Pixels() throws {
        let source = try ArtworkFixture.image(width: 2400, height: 1200)
        let jpeg = try XCTUnwrap(LibraryArtwork.thumbnail(source))
        let image = try XCTUnwrap(CGImageSourceCreateWithData(jpeg as CFData, nil))
        let properties = try XCTUnwrap(CGImageSourceCopyPropertiesAtIndex(image, 0, nil) as? [CFString: Any])
        XCTAssertEqual((properties[kCGImagePropertyPixelWidth] as? NSNumber)?.intValue, 600)
        XCTAssertEqual((properties[kCGImagePropertyPixelHeight] as? NSNumber)?.intValue, 300)
        XCTAssertEqual(CGImageSourceGetType(image) as String?, UTType.jpeg.identifier)
        XCTAssertLessThanOrEqual(jpeg.count, LibraryArtwork.maximumInputBytes)
    }

    func testOversizedEmptyAndBrokenArtworkAreRejected() {
        XCTAssertNil(LibraryArtwork.thumbnail(Data()))
        XCTAssertNil(LibraryArtwork.thumbnail(Data("损坏的图片".utf8)))
        XCTAssertNil(LibraryArtwork.thumbnail(Data(repeating: 0, count: 8 * 1024 * 1024 + 1)))
    }

    func testOwnedCoverPathRejectsTraversalAndNonHashIDs() throws {
        let fixture = try ArtworkFixture(); defer { fixture.cleanup() }
        for id in ["../outside", "../../", "Audio/name", "Covers\\name", "", String(repeating: "g", count: 64), String(repeating: "a", count: 64) + "/../outside"] {
            XCTAssertThrowsError(try LibraryArtwork.ownedCoverURL(id: id, root: fixture.root, createDirectory: true))
        }
        XCTAssertFalse(FileManager.default.fileExists(atPath: fixture.root.appendingPathComponent("Covers").path))
    }

    func testManifestRebasesFileCoverAfterContainerDirectoryChanges() async throws {
        let fixture = try ArtworkFixture(); defer { fixture.cleanup() }
        let library = LibraryStore(root: fixture.root)
        let result = try await library.importFiles([fixture.wav()])
        var track = try XCTUnwrap(result.imported.first)
        let cover = try XCTUnwrap(LibraryArtwork.save(try ArtworkFixture.image(width: 40, height: 30), id: track.id, root: fixture.root))
        track.artworkURL = cover
        try fixture.writeManifest(track)
        let moved = fixture.base.appendingPathComponent("NewContainerLibrary", isDirectory: true)
        try FileManager.default.copyItem(at: fixture.root, to: moved)
        try FileManager.default.removeItem(at: fixture.root)
        let rows = try await LibraryStore(root: moved).load()
        let restored = try XCTUnwrap(rows.first)
        XCTAssertEqual(restored.artworkURL?.standardizedFileURL, moved.appendingPathComponent("Covers/\(track.id).jpg").standardizedFileURL.resolvingSymlinksInPath())
        let newCover = try XCTUnwrap(restored.artworkURL)
        XCTAssertTrue(FileManager.default.fileExists(atPath: newCover.path))
        XCTAssertFalse(FileManager.default.fileExists(atPath: cover.path))
    }

    func testManifestExternalFileURLIsNeverAdoptedAndAudioStillLoads() async throws {
        let fixture = try ArtworkFixture(); defer { fixture.cleanup() }
        let audio = try fixture.wav(), original = try Data(contentsOf: audio)
        let library = LibraryStore(root: fixture.root)
        let result = try await library.importFiles([audio])
        var track = try XCTUnwrap(result.imported.first)
        let outside = fixture.base.appendingPathComponent("outside-private.jpg")
        let sentinel = Data("这不是曲库拥有的封面".utf8); try sentinel.write(to: outside)
        track.artworkURL = outside
        try fixture.writeManifest(track)
        let rows = try await library.load()
        XCTAssertEqual(rows.count, 1); XCTAssertNil(rows.first?.artworkURL)
        XCTAssertEqual(try Data(contentsOf: outside), sentinel)
        XCTAssertEqual(try Data(contentsOf: audio), original)
    }

    func testCoverDirectoryAndLeafSymlinksNeverReadWriteOrRemoveOutsideFile() async throws {
        for directoryLink in [true, false] {
            let fixture = try ArtworkFixture(); defer { fixture.cleanup() }
            let library = LibraryStore(root: fixture.root)
            let result = try await library.importFiles([fixture.wav()])
            var track = try XCTUnwrap(result.imported.first)
            let outside = fixture.base.appendingPathComponent("OutsideCovers", isDirectory: true)
            try FileManager.default.createDirectory(at: outside, withIntermediateDirectories: true)
            let externalCover = outside.appendingPathComponent(track.id + ".jpg")
            let bytes = try ArtworkFixture.image(width: 30, height: 20); try bytes.write(to: externalCover)
            let covers = fixture.root.appendingPathComponent("Covers", isDirectory: true)
            if directoryLink { try FileManager.default.createSymbolicLink(at: covers, withDestinationURL: outside) }
            else {
                try FileManager.default.createDirectory(at: covers, withIntermediateDirectories: true)
                try FileManager.default.createSymbolicLink(at: covers.appendingPathComponent(track.id + ".jpg"), withDestinationURL: externalCover)
            }
            track.artworkURL = externalCover; try fixture.writeManifest(track)
            let rows = try await library.load()
            XCTAssertEqual(rows.count, 1); XCTAssertNil(rows.first?.artworkURL)
            XCTAssertNil(LibraryArtwork.save(bytes, id: track.id, root: fixture.root))
            LibraryArtwork.remove(id: track.id, root: fixture.root)
            XCTAssertEqual(try Data(contentsOf: externalCover), bytes)
        }
    }

    func testRealM4AEmbeddedArtworkIsImportedWithoutChangingOriginalAndRemovedWithOwnedCopy() async throws {
        let fixture = try ArtworkFixture(); defer { fixture.cleanup() }
        let originalArtwork = try ArtworkFixture.image(width: 1000, height: 800)
        let source = try await fixture.m4a(artwork: originalArtwork)
        let originalAudio = try Data(contentsOf: source)
        let metadata = try await AVURLAsset(url: source).load(.commonMetadata)
        XCTAssertTrue(metadata.contains { $0.commonKey == .commonKeyArtwork }, "真实导出文件必须含可读封面元数据")
        let library = LibraryStore(root: fixture.root)
        let result = try await library.importFiles([source])
        XCTAssertTrue(result.failures.isEmpty, result.failures.joined(separator: "\n"))
        let track = try XCTUnwrap(result.imported.first), cover = try XCTUnwrap(track.artworkURL)
        XCTAssertTrue(cover.path.contains("/Covers/\(track.id).jpg"))
        let image = try XCTUnwrap(CGImageSourceCreateWithURL(cover as CFURL, nil))
        let info = try XCTUnwrap(CGImageSourceCopyPropertiesAtIndex(image, 0, nil) as? [CFString: Any])
        XCTAssertLessThanOrEqual((info[kCGImagePropertyPixelWidth] as? NSNumber)?.intValue ?? 601, 600)
        XCTAssertEqual(try Data(contentsOf: source), originalAudio)
        try await library.remove(track)
        XCTAssertFalse(FileManager.default.fileExists(atPath: cover.path))
        XCTAssertEqual(try Data(contentsOf: source), originalAudio)
    }

    func testBadEmbeddedArtworkDoesNotAbortRealAudioImport() async throws {
        let fixture = try ArtworkFixture(); defer { fixture.cleanup() }
        let source = try await fixture.m4a(artwork: Data("broken-image-data".utf8))
        let original = try Data(contentsOf: source)
        let result = try await LibraryStore(root: fixture.root).importFiles([source])
        XCTAssertTrue(result.failures.isEmpty, result.failures.joined(separator: "\n"))
        XCTAssertEqual(result.imported.count, 1); XCTAssertNil(result.imported.first?.artworkURL)
        XCTAssertEqual(try Data(contentsOf: source), original)
    }
}

private struct ArtworkFixture {
    let base: URL
    var root: URL { base.appendingPathComponent("Library", isDirectory: true) }
    init() throws {
        base = FileManager.default.temporaryDirectory.appendingPathComponent("folia-artwork-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
    }
    func cleanup() { try? FileManager.default.removeItem(at: base) }
    func writeManifest(_ track: FoliaNative.MusicTrack) throws {
        struct Manifest: Encodable { let version = 1; let tracks: [FoliaNative.MusicTrack] }
        try JSONEncoder().encode(Manifest(tracks: [track])).write(to: root.appendingPathComponent("library.json"), options: .atomic)
    }
    static func image(width: Int, height: Int) throws -> Data {
        let context = try XCTUnwrap(CGContext(data: nil, width: width, height: height, bitsPerComponent: 8, bytesPerRow: width * 4,
            space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue))
        context.setFillColor(CGColor(red: 0.7, green: 0.3, blue: 0.1, alpha: 1)); context.fill(CGRect(x: 0, y: 0, width: width, height: height))
        let output = NSMutableData(), image = try XCTUnwrap(context.makeImage())
        let destination = try XCTUnwrap(CGImageDestinationCreateWithData(output, UTType.jpeg.identifier as CFString, 1, nil))
        CGImageDestinationAddImage(destination, image, nil); XCTAssertTrue(CGImageDestinationFinalize(destination))
        return output as Data
    }
    func wav() throws -> URL {
        var data = Data()
        func append<T: FixedWidthInteger>(_ number: T) { var value = number.littleEndian; withUnsafeBytes(of: &value) { data.append(contentsOf: $0) } }
        let count = 8820, bytes = UInt32(count * 2)
        data.append(contentsOf: "RIFF".utf8); append(UInt32(36) + bytes); data.append(contentsOf: "WAVEfmt ".utf8)
        append(UInt32(16)); append(UInt16(1)); append(UInt16(1)); append(UInt32(44100)); append(UInt32(88200)); append(UInt16(2)); append(UInt16(16))
        data.append(contentsOf: "data".utf8); append(bytes)
        for index in 0..<count { append(Int16(sin(2 * .pi * 330 * Double(index) / 44100) * 700)) }
        let url = base.appendingPathComponent("Original.wav"); try data.write(to: url); return url
    }
    func m4a(artwork: Data) async throws -> URL {
        let source = try wav(), destination = base.appendingPathComponent("Embedded.m4a")
        let export = try XCTUnwrap(AVAssetExportSession(asset: AVURLAsset(url: source), presetName: AVAssetExportPresetAppleM4A))
        let item = AVMutableMetadataItem(); item.identifier = .iTunesMetadataCoverArt
        item.dataType = kCMMetadataBaseDataType_JPEG as String; item.value = artwork as NSData
        export.metadata = [item]; export.outputURL = destination; export.outputFileType = .m4a
        await withCheckedContinuation { continuation in export.exportAsynchronously { continuation.resume() } }
        guard export.status == .completed else { throw export.error ?? NativeMusicError.message("本地测试 M4A 生成失败") }
        return destination
    }
}
