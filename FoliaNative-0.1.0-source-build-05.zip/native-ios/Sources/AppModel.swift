import Combine
import Foundation

// native-ios/Sources/AppModel.swift
@MainActor
final class AppModel: ObservableObject {
    @Published private(set) var localTracks: [MusicTrack] = []
    @Published private(set) var importing = false
    @Published private(set) var loadingTrackID: String?
    @Published var notice: String?
    @Published var showPlayer = false
    @Published var qqEndpoint: String
    @Published private(set) var qqConnectionRevision = 0
    let playback = NativePlayback()
    let service = NativeMusicService()
    private let library: LibraryStore
    private var queue: [MusicTrack] = []
    private var playTask: Task<Void, Never>?
    private var playGeneration = 0
    private var started = false

    init(library: LibraryStore = LibraryStore()) {
        self.library = library
        qqEndpoint = UserDefaults.standard.string(forKey: "qqHTTPSService") ?? ""
        playback.onNext = { [weak self] in self?.next() }
        playback.onPrevious = { [weak self] in self?.previous() }
    }

    func start() async {
        guard !started else { return }
        started = true
        do {
            localTracks = try await library.load()
            await service.setQQEndpoint(validQQURL())
            #if DEBUG
            if ProcessInfo.processInfo.arguments.contains("--ui-test-demo") {
                let files = try NativeDemoFixture.make()
                _ = try await library.importFiles(files)
                localTracks = try await library.load()
            }
            #endif
        } catch { notice = error.localizedDescription }
    }

    func importFiles(_ files: [URL]) async {
        guard !importing else { return }
        importing = true
        defer { importing = false }
        do {
            let result = try await library.importFiles(files)
            localTracks = try await library.load()
            if let current = playback.track, let updated = localTracks.first(where: { $0.id == current.id }) {
                let lines = try await LRCParser.parseAsync(updated.lyricText ?? "")
                playback.replaceLyrics(lines, trackID: current.id)
            }
            notice = "已导入 \(result.imported.count) 首，重复 \(result.duplicates) 首" + (result.failures.isEmpty ? "" : "\n" + result.failures.joined(separator: "\n"))
        } catch { notice = error.localizedDescription }
    }

    func remove(_ track: MusicTrack) async {
        guard !importing else { notice = "音乐正在导入，请完成后再删除"; return }
        do {
            if loadingTrackID == track.id {
                playTask?.cancel(); playGeneration += 1; loadingTrackID = nil
            }
            if playback.track?.id == track.id { playback.stop() }
            try await library.remove(track)
            localTracks = try await library.load()
            queue.removeAll { $0.id == track.id }
        } catch { notice = error.localizedDescription }
    }

    /// 快速连点换曲只允许最后一次请求接管播放器，旧请求完成后不会覆盖新歌。
    func play(_ track: MusicTrack, among tracks: [MusicTrack]) {
        queue = tracks
        playTask?.cancel()
        playGeneration += 1
        let generation = playGeneration
        loadingTrackID = track.id
        playTask = Task { [weak self] in
            guard let self else { return }
            do {
                let url: URL
                if track.source == .local { url = try await library.url(for: track) }
                else { url = try await service.playbackURL(track) }
                try Task.checkCancellation()
                guard generation == playGeneration else { return }
                // 音源取得后立即开播；歌词请求和解析不再阻塞首声。
                playback.play(track, url: url, lyrics: [])
                loadingTrackID = nil
                do {
                    let text: String
                    if track.source == .local { text = track.lyricText ?? "" }
                    else { text = try await service.lyrics(for: track) }
                    let lines = try await LRCParser.parseAsync(text)
                    try Task.checkCancellation()
                    guard generation == playGeneration else { return }
                    playback.replaceLyrics(lines, trackID: track.id)
                } catch {
                    guard generation == playGeneration, !Task.isCancelled else { return }
                    notice = "音乐已开始播放，歌词加载失败：\(error.localizedDescription)"
                }
            } catch {
                guard generation == playGeneration, !Task.isCancelled else { return }
                loadingTrackID = nil
                notice = "歌曲加载失败：\(error.localizedDescription)"
            }
        }
    }

    func next() {
        guard let id = playback.track?.id, let index = queue.firstIndex(where: { $0.id == id }), index + 1 < queue.count else { return }
        play(queue[index + 1], among: queue)
    }

    func previous() {
        guard let id = playback.track?.id, let index = queue.firstIndex(where: { $0.id == id }) else { return }
        if playback.clock.position > 3 { playback.seek(to: 0) }
        else if index > 0 { play(queue[index - 1], among: queue) }
    }

    func saveQQEndpoint() async {
        let trimmed = qqEndpoint.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmed.isEmpty, validQQURL() == nil {
            notice = "请输入不含账号、密码、查询参数的 HTTPS 服务地址"
            return
        }
        qqEndpoint = trimmed
        await service.setQQEndpoint(validQQURL())
        qqConnectionRevision += 1
        UserDefaults.standard.set(trimmed, forKey: "qqHTTPSService")
        notice = trimmed.isEmpty ? "已清除 QQ 服务配置" : "已保存 QQ 服务地址，请在 QQ 音乐页连接测试"
    }

    private func validQQURL() -> URL? {
        guard let components = URLComponents(string: qqEndpoint.trimmingCharacters(in: .whitespacesAndNewlines)),
              components.scheme?.lowercased() == "https", let host = components.host, !host.isEmpty,
              components.user == nil, components.password == nil, components.query == nil,
              components.fragment == nil else { return nil }
        return components.url
    }
}
