import SwiftUI

// native-ios/Sources/FoliaLyricsStage.swift
enum FoliaLyricStyle: String {
    case immersive
    case lines
    var title: String { self == .immersive ? "沉浸" : "逐行" }
}

/// 舞台只消费真实 LRC 的离散当前行，不订阅音频时钟，不合成逐字时间。
struct FoliaLyricsStage: View {
    let lines: [LyricLine]
    let activeID: Int?
    let style: FoliaLyricStyle
    let compact: Bool
    let seek: (Double) -> Void
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private var activeIndex: Int? { lines.firstIndex(where: { $0.id == activeID }) }

    var body: some View {
        GeometryReader { geometry in
            if lines.isEmpty {
                emptyStage
            } else if style == .immersive {
                immersiveStage(size: geometry.size)
            } else {
                flowingStage(size: geometry.size)
            }
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var emptyStage: some View {
        VStack(spacing: 18) {
            Image(systemName: "text.quote").font(.system(size: 32, weight: .ultraLight)).opacity(0.35)
            Text("让音乐填满这一刻").font(.title3.weight(.light))
            Text("暂无歌词\n本地歌曲可导入同名 LRC 文件")
                .font(.caption).multilineTextAlignment(.center).lineSpacing(6).opacity(0.45)
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
            .accessibilityIdentifier("emptyLyricsStage")
    }

    private func immersiveStage(size: CGSize) -> some View {
        // 只绘制当前行附近最多五行；长歌词不会在后台持续排版全部文本。
        let center = activeIndex ?? 0
        let radius = compact ? 1 : 2
        let offsets = Array(-radius...radius)
        let mainSize = compact ? min(32, max(22, size.height * 0.18)) : min(46, max(30, size.width * 0.095))
        return VStack(spacing: compact ? 10 : 28) {
            Spacer(minLength: 0)
            ForEach(offsets, id: \.self) { offset in
                let lineIndex = center + offset
                if lines.indices.contains(lineIndex) {
                let line = lines[lineIndex]
                let isActive = line.id == activeID
                Button { seek(line.time) } label: {
                    VStack(spacing: 9) {
                        Text(line.text)
                            .font(.system(size: isActive ? mainSize : (compact ? 13 : 20),
                                          weight: isActive ? .semibold : .regular, design: .serif))
                            .multilineTextAlignment(.center).lineLimit(isActive ? (compact ? 2 : 3) : 1)
                            .minimumScaleFactor(0.65)
                            .contentTransition(.opacity)
                        if isActive, let translation = line.translation, !translation.isEmpty {
                            Text(translation).font(.subheadline).multilineTextAlignment(.center)
                                .lineLimit(compact ? 1 : 2).opacity(0.65)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .opacity(isActive ? 1 : (abs(offset) > 1 ? 0.16 : 0.37))
                    .padding(.vertical, isActive ? (compact ? 4 : 10) : 3)
                    .frame(minHeight: 44)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain).accessibilityIdentifier("lyric-row-\(line.id)")
                .accessibilityValue(isActive ? "当前歌词" : "")
                } else {
                    Color.clear.frame(height: 44).accessibilityHidden(true)
                }
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, compact ? 56 : 30)
        .frame(width: size.width, height: size.height)
        .clipped()
        .animation(reduceMotion ? nil : .easeOut(duration: 0.32), value: activeID)
        .accessibilityIdentifier("lyricsScroll")
    }

    private func flowingStage(size: CGSize) -> some View {
        let center = activeIndex ?? 0
        return ScrollViewReader { reader in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: compact ? 24 : 34) {
                    ForEach(Array(lines.enumerated()), id: \.element.id) { index, line in
                        let isActive = line.id == activeID
                        let distance = abs(index - center)
                        Button { seek(line.time) } label: {
                            VStack(alignment: .leading, spacing: 10) {
                                Text(line.text)
                                    .font(.system(size: compact ? 28 : 34, weight: .semibold, design: .serif))
                                    .fixedSize(horizontal: false, vertical: true)
                                if let translation = line.translation, !translation.isEmpty {
                                    Text(translation).font(.subheadline).opacity(0.65)
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .opacity(isActive ? 1 : (distance > 2 ? 0.17 : 0.36))
                            .padding(.vertical, 5).frame(minHeight: 44).contentShape(Rectangle())
                        }
                        .buttonStyle(.plain).id(line.id)
                        .accessibilityIdentifier("lyric-row-\(line.id)")
                        .accessibilityValue(isActive ? "当前歌词" : "")
                    }
                }
                .padding(.horizontal, compact ? 70 : 32)
                .padding(.vertical, max(28, size.height * 0.4))
            }
            .scrollIndicators(.hidden)
            .mask {
                LinearGradient(stops: [.init(color: .clear, location: 0), .init(color: .white, location: 0.12),
                                       .init(color: .white, location: 0.86), .init(color: .clear, location: 1)],
                               startPoint: .top, endPoint: .bottom)
            }
            .accessibilityIdentifier("lyricsScroll")
            .onAppear { recenter(reader, id: activeID, animated: false) }
            // 行变化才触发一次滚动；5 Hz 进度仅在控制条的小子视图更新。
            .onChange(of: activeID) { _, id in
                recenter(reader, id: id, animated: true)
            }
            // 旋转只按舞台尺寸变化重新居中，不订阅连续播放时间。
            .onChange(of: size) { _, _ in recenter(reader, id: activeID, animated: false) }
        }
    }

    private func recenter(_ reader: ScrollViewProxy, id: Int?, animated: Bool) {
        guard let id else { return }
        if animated && !reduceMotion {
            withAnimation(.easeOut(duration: 0.35)) { reader.scrollTo(id, anchor: .center) }
        } else {
            var transaction = Transaction()
            transaction.disablesAnimations = true
            withTransaction(transaction) { reader.scrollTo(id, anchor: .center) }
        }
    }
}
