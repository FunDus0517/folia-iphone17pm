import SwiftUI

// native-ios/Sources/FoliaNativeApp.swift
@main
struct FoliaNativeApp: App {
    @StateObject private var model: AppModel
    init() {
        #if DEBUG
        let testing = ProcessInfo.processInfo.arguments.contains("--ui-test-demo") || ProcessInfo.processInfo.arguments.contains("--ui-test-empty")
        let testRoot = testing ? FileManager.default.temporaryDirectory.appendingPathComponent("folia-ui-\(UUID().uuidString)", isDirectory: true) : nil
        if testing {
            UserDefaults.standard.set(false, forKey: "foliaNativeLibraryList")
            UserDefaults.standard.set("immersive", forKey: "foliaNativeLyricStyle")
        }
        _model = StateObject(wrappedValue: AppModel(library: LibraryStore(root: testRoot)))
        #else
        _model = StateObject(wrappedValue: AppModel())
        #endif
    }
    var body: some Scene {
        WindowGroup {
            NativeRootView(model: model)
                .preferredColorScheme(.dark)
                .environment(\.locale, Locale(identifier: "zh_Hans_CN"))
                .task { await model.start() }
        }
    }
}
