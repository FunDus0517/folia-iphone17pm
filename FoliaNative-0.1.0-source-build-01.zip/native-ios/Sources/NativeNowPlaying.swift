import MediaPlayer
import UIKit
import Foundation
import ImageIO

// native-ios/Sources/NativeNowPlaying.swift
// 锁屏和耳机控制只注册一次，避免反复进入页面累积处理器。
@MainActor
final class NativeNowPlaying {
    var onPlay: (() -> Void)?
    var onPause: (() -> Void)?
    var onToggle: (() -> Void)?
    var onNext: (() -> Void)?
    var onPrevious: (() -> Void)?
    var onSeek: ((Double) -> Void)?
    private var targets: [(MPRemoteCommand, Any)] = []
    private var metadata: [String: Any] = [:]
    private var artworkTask: Task<Void, Never>?
    private var trackID: String?
    private var artwork: MPMediaItemArtwork?

    init() {
        let center = MPRemoteCommandCenter.shared()
        register(center.playCommand) { [weak self] in self?.onPlay?() }
        register(center.pauseCommand) { [weak self] in self?.onPause?() }
        register(center.togglePlayPauseCommand) { [weak self] in self?.onToggle?() }
        register(center.nextTrackCommand) { [weak self] in self?.onNext?() }
        register(center.previousTrackCommand) { [weak self] in self?.onPrevious?() }
        let seek = center.changePlaybackPositionCommand
        seek.isEnabled = true
        let token = seek.addTarget { [weak self] event in
            guard let event = event as? MPChangePlaybackPositionCommandEvent,
                  event.positionTime.isFinite else { return .commandFailed }
            let position = event.positionTime
            Task { @MainActor [weak self] in self?.onSeek?(position) }
            return .success
        }
        targets.append((seek, token))
        setCommandsEnabled(false)
    }

    private func register(_ command: MPRemoteCommand, action: @escaping @MainActor () -> Void) {
        command.isEnabled = true
        let token = command.addTarget { _ in
            Task { @MainActor in action() }
            return .success
        }
        targets.append((command, token))
    }

    func setTrack(_ track: MusicTrack) {
        artworkTask?.cancel()
        trackID = track.id
        setCommandsEnabled(true)
        artwork = nil
        metadata = [
            MPMediaItemPropertyTitle: track.title,
            MPMediaItemPropertyArtist: track.artist,
            MPMediaItemPropertyAlbumTitle: track.album,
            MPNowPlayingInfoPropertyMediaType: MPNowPlayingInfoMediaType.audio.rawValue,
            MPNowPlayingInfoPropertyIsLiveStream: false
        ]
        if track.duration.isFinite, track.duration > 0 { metadata[MPMediaItemPropertyPlaybackDuration] = track.duration }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = metadata
        // 封面属于可选信息。读取失败不影响音频与远程控制。
        guard let url = track.artworkURL, url.isFileURL || url.scheme == "https" else { return }
        artworkTask = Task { [weak self] in
            do {
                let data: Data
                if url.isFileURL {
                    data = try await Task.detached(priority: .utility) {
                        let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                        guard size > 0, size <= 8 * 1024 * 1024 else { throw NativeMusicError.message("封面文件过大") }
                        return try Data(contentsOf: url)
                    }.value
                } else {
                    var request = URLRequest(url: url)
                    request.timeoutInterval = 15
                    let (download, response) = try await URLSession.shared.data(for: request)
                    guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { return }
                    data = download
                }
                guard !Task.isCancelled, data.count <= 8 * 1024 * 1024 else { return }
                let thumbnail = await Task.detached(priority: .utility) {
                    Self.thumbnailData(data)
                }.value
                guard !Task.isCancelled, let thumbnail, let image = UIImage(data: thumbnail),
                      let self, self.trackID == track.id else { return }
                let item = MPMediaItemArtwork(boundsSize: image.size) { _ in image }
                self.artwork = item
                self.metadata[MPMediaItemPropertyArtwork] = item
                MPNowPlayingInfoCenter.default().nowPlayingInfo = self.metadata
            } catch { /* 网络封面失败时保留歌曲文字和播放控制。 */ }
        }
    }

    func update(position: Double, duration: Double, playing: Bool) {
        guard trackID != nil else { return }
        metadata[MPNowPlayingInfoPropertyElapsedPlaybackTime] = max(0, position.isFinite ? position : 0)
        metadata[MPNowPlayingInfoPropertyPlaybackRate] = playing ? 1.0 : 0.0
        metadata[MPNowPlayingInfoPropertyDefaultPlaybackRate] = 1.0
        if duration.isFinite, duration > 0 { metadata[MPMediaItemPropertyPlaybackDuration] = duration }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = metadata
    }

    func clear() {
        artworkTask?.cancel()
        artworkTask = nil
        trackID = nil
        artwork = nil
        metadata.removeAll()
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
        setCommandsEnabled(false)
    }

    func shutdown() {
        clear()
        for (command, token) in targets {
            command.removeTarget(token)
            command.isEnabled = false
        }
        targets.removeAll()
        onPlay = nil; onPause = nil; onToggle = nil
        onNext = nil; onPrevious = nil; onSeek = nil
    }

    private func setCommandsEnabled(_ enabled: Bool) {
        for (command, _) in targets { command.isEnabled = enabled }
    }

    private nonisolated static func thumbnailData(_ data: Data) -> Data? {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceThumbnailMaxPixelSize: 600,
                kCGImageSourceShouldCacheImmediately: true
              ] as CFDictionary) else { return nil }
        return UIImage(cgImage: image).jpegData(compressionQuality: 0.85)
    }
}
