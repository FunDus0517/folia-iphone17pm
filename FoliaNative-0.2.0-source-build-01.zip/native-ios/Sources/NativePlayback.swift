import AVFoundation
import Combine
import Foundation

// native-ios/Sources/NativePlayback.swift
// 所有界面共享同一个原生音频播放器，歌词只在线号变化时发布。
@MainActor
final class PlaybackClock: ObservableObject {
    @Published private(set) var position: Double = 0
    @Published private(set) var duration: Double = 0

    func update(position: Double, duration: Double) {
        let nextPosition = position.isFinite ? max(0, position) : 0
        let nextDuration = duration.isFinite ? max(0, duration) : 0
        if abs(self.position - nextPosition) > 0.015 { self.position = nextPosition }
        if abs(self.duration - nextDuration) > 0.015 { self.duration = nextDuration }
    }
}

@MainActor
final class NativePlayback: ObservableObject {
    @Published private(set) var track: MusicTrack?
    @Published private(set) var isPlaying = false
    @Published private(set) var error: String?
    @Published private(set) var lyrics: [LyricLine] = []
    @Published private(set) var activeLyricID: Int?
    let clock = PlaybackClock()
    var onNext: (() -> Void)?
    var onPrevious: (() -> Void)?
    private var player = AVPlayer()
    private var timeObserver: Any?
    private var playerObservation: NSKeyValueObservation?
    private var itemObservation: NSKeyValueObservation?
    private var endObserver: NSObjectProtocol?
    private var failureObserver: NSObjectProtocol?
    private let audioSession = AudioSessionCoordinator()
    private var nowPlaying: NativeNowPlaying?
    private var currentURL: URL?
    private var generation = 0
    private var seekGeneration = 0
    private var wantsToPlay = false
    private var resumeAfterInterruption = false
    private var isShutdown = false
    private var lastSystemInfoSecond: Int = -1
    private var completedGeneration: Int?

    var currentTime: Double {
        let value = player.currentTime().seconds
        return value.isFinite ? max(0, value) : 0
    }

    init(registerSystemControls: Bool = true) {
        if registerSystemControls { nowPlaying = NativeNowPlaying() }
        configurePlayerObservers()
        audioSession.onInterruptionBegan = { [weak self] in self?.beginInterruption() }
        audioSession.onInterruptionEnded = { [weak self] shouldResume in self?.endInterruption(shouldResume: shouldResume) }
        audioSession.onOutputDisconnected = { [weak self] in self?.pause() }
        audioSession.onMediaServicesReset = { [weak self] in self?.recoverMediaServices() }
        nowPlaying?.onPlay = { [weak self] in self?.resume() }
        nowPlaying?.onPause = { [weak self] in self?.pause() }
        nowPlaying?.onToggle = { [weak self] in self?.toggle() }
        nowPlaying?.onNext = { [weak self] in self?.onNext?() }
        nowPlaying?.onPrevious = { [weak self] in self?.onPrevious?() }
        nowPlaying?.onSeek = { [weak self] time in self?.seek(to: time) }
    }

    func play(_ track: MusicTrack, url: URL, lyrics: [LyricLine]) {
        load(track, url: url, lyrics: lyrics, autoplay: true)
    }

    private func load(_ track: MusicTrack, url: URL, lyrics: [LyricLine], autoplay: Bool) {
        guard !isShutdown else { return }
        generation += 1
        seekGeneration += 1
        completedGeneration = nil
        removeItemObservers()
        player.pause()
        wantsToPlay = false
        resumeAfterInterruption = false
        error = nil
        self.track = track
        currentURL = url
        self.lyrics = normalizedLyrics(lyrics)
        activeLyricID = nil
        clock.update(position: 0, duration: track.duration)
        let item = AVPlayerItem(url: url)
        let version = generation
        itemObservation = item.observe(\.status, options: [.initial, .new]) { [weak self] _, _ in
            Task { @MainActor [weak self] in self?.handleItemStatus(generation: version) }
        }
        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: nil) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.generation == version, self.completedGeneration != version else { return }
                self.completedGeneration = version
                self.wantsToPlay = false
                self.setPlaying(false)
                self.refreshClock()
                self.onNext?()
            }
        }
        failureObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemFailedToPlayToEndTime, object: item, queue: nil) { [weak self] note in
            let message = (note.userInfo?[AVPlayerItemFailedToPlayToEndTimeErrorKey] as? Error)?.localizedDescription
            Task { @MainActor [weak self] in
                guard let self, self.generation == version else { return }
                self.pause()
                self.error = "歌曲播放中断：\(message ?? "音频读取失败，请重试")"
            }
        }
        player.replaceCurrentItem(with: item)
        nowPlaying?.setTrack(track)
        refreshClock(forceSystemInfo: true)
        if autoplay { resume() } else { setPlaying(false) }
    }

    func toggle() { wantsToPlay ? pause() : resume() }

    func pause() {
        wantsToPlay = false
        resumeAfterInterruption = false
        player.pause()
        setPlaying(false)
        refreshClock(forceSystemInfo: true)
        audioSession.deactivate()
    }

    func resume() {
        guard !isShutdown, track != nil, player.currentItem != nil else { return }
        if player.currentItem?.status == .failed { handleItemStatus(generation: generation); return }
        do {
            try audioSession.activate()
            error = nil
            wantsToPlay = true
            if clock.duration > 0, currentTime >= clock.duration - 0.05 { seek(to: 0) }
            player.play()
            setPlaying(true)
            refreshClock(forceSystemInfo: true)
        } catch {
            self.error = "音频设备启动失败：\(error.localizedDescription)"
            wantsToPlay = false
            setPlaying(false)
        }
    }

    func seek(to seconds: Double) {
        guard !isShutdown, track != nil, seconds.isFinite else { return }
        let target = max(0, clock.duration > 0 ? min(seconds, clock.duration) : seconds)
        if clock.duration > 0, target < clock.duration - 0.05 { completedGeneration = nil }
        seekGeneration += 1
        let request = seekGeneration
        let version = generation
        player.seek(to: CMTime(seconds: target, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.generation == version, self.seekGeneration == request else { return }
                self.refreshClock(forceSystemInfo: true)
            }
        }
    }

    func replaceLyrics(_ lines: [LyricLine], trackID: String) {
        guard track?.id == trackID else { return }
        let normalized = normalizedLyrics(lines)
        if lyrics != normalized { lyrics = normalized }
        updateActiveLyric(at: currentTime)
    }

    func stop() {
        generation += 1
        seekGeneration += 1
        pause()
        removeItemObservers()
        player.replaceCurrentItem(with: nil)
        track = nil
        currentURL = nil
        lyrics = []
        activeLyricID = nil
        error = nil
        clock.update(position: 0, duration: 0)
        nowPlaying?.clear()
        audioSession.deactivate()
    }

    // App 持有本实例到进程结束；测试和显式关闭使用本方法，避免非隔离 deinit 访问 AVPlayer token。
    func shutdown() {
        guard !isShutdown else { return }
        stop()
        isShutdown = true
        removePlayerObservers()
        nowPlaying?.shutdown()
        nowPlaying = nil
        audioSession.shutdown()
        onNext = nil
        onPrevious = nil
    }

    private func configurePlayerObservers() {
        timeObserver = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.2, preferredTimescale: 600), queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in self?.refreshClock() }
        }
        playerObservation = player.observe(\.timeControlStatus, options: [.initial, .new]) { [weak self] _, _ in
            Task { @MainActor [weak self] in
                guard let self, !self.isShutdown else { return }
                self.setPlaying(self.wantsToPlay && self.player.timeControlStatus != .paused)
                self.refreshClock(forceSystemInfo: true)
            }
        }
    }

    private func removePlayerObservers() {
        if let token = timeObserver { player.removeTimeObserver(token); timeObserver = nil }
        playerObservation?.invalidate()
        playerObservation = nil
    }

    private func removeItemObservers() {
        itemObservation?.invalidate()
        itemObservation = nil
        if let token = endObserver { NotificationCenter.default.removeObserver(token); endObserver = nil }
        if let token = failureObserver { NotificationCenter.default.removeObserver(token); failureObserver = nil }
    }

    private func handleItemStatus(generation version: Int) {
        guard generation == version, let item = player.currentItem else { return }
        switch item.status {
        case .failed:
            error = "歌曲加载失败：\(item.error?.localizedDescription ?? "音频格式不受支持或网络连接中断")"
            wantsToPlay = false
            player.pause()
            setPlaying(false)
        case .readyToPlay: refreshClock(forceSystemInfo: true)
        default: break
        }
    }

    private func refreshClock(forceSystemInfo: Bool = false) {
        guard !isShutdown else { return }
        let position = currentTime
        let itemDuration = player.currentItem?.duration.seconds ?? 0
        let duration = itemDuration.isFinite && itemDuration > 0 ? itemDuration : (track?.duration ?? 0)
        clock.update(position: position, duration: duration)
        updateActiveLyric(at: position)
        let second = Int(position.rounded(.down))
        if forceSystemInfo || second != lastSystemInfoSecond {
            lastSystemInfoSecond = second
            nowPlaying?.update(position: position, duration: duration, playing: isPlaying)
        }
    }

    private func updateActiveLyric(at seconds: Double) {
        var low = 0
        var high = lyrics.count
        while low < high {
            let middle = low + (high - low) / 2
            if lyrics[middle].time <= seconds { low = middle + 1 } else { high = middle }
        }
        let nextID = low > 0 ? lyrics[low - 1].id : nil
        if activeLyricID != nextID { activeLyricID = nextID }
    }

    private func normalizedLyrics(_ lines: [LyricLine]) -> [LyricLine] {
        lines.enumerated().filter { $0.element.time.isFinite && $0.element.time >= 0 }
            .sorted { $0.element.time == $1.element.time ? $0.offset < $1.offset : $0.element.time < $1.element.time }
            .map(\.element)
    }

    private func setPlaying(_ value: Bool) { if isPlaying != value { isPlaying = value } }

    private func beginInterruption() {
        resumeAfterInterruption = wantsToPlay
        player.pause()
        setPlaying(false)
        refreshClock(forceSystemInfo: true)
    }

    private func endInterruption(shouldResume: Bool) {
        let restore = shouldResume && resumeAfterInterruption && wantsToPlay
        resumeAfterInterruption = false
        if restore { resume() } else { pause() }
    }

    private func recoverMediaServices() {
        guard let track, let url = currentURL else { return }
        let position = clock.position
        let restore = wantsToPlay
        let savedLyrics = lyrics
        removePlayerObservers()
        removeItemObservers()
        player = AVPlayer()
        configurePlayerObservers()
        load(track, url: url, lyrics: savedLyrics, autoplay: restore)
        seek(to: position)
    }
}
