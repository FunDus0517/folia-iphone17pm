import Foundation

// native-ios/Sources/Services/QQNativeNormalization.swift
// Field mappings mirror onlineMusic/qqNormalize.ts; songmid is playback identity, never a numeric song ID.
enum QQNativeNormalization {
    static func track(_ raw: NativeJSON) -> MusicTrack? {
        let mid = raw.firstText("qqMid", "mid", "songmid")
        guard !mid.isEmpty else { return nil }
        let album = raw["album"]
        let albumMid = album.firstText("mid", "albummid", "albumMid").isEmpty ? raw.firstText("albummid", "albumMid") : album.firstText("mid", "albummid", "albumMid")
        let art = album.firstText("picUrl", "coverUrl")
        let cover = art.isEmpty && !albumMid.isEmpty ? "https://y.gtimg.cn/music/photo_new/T002R300x300M000\(albumMid).jpg?max_age=2592000" : art
        let singers = raw["singer"].isNull ? raw["artists"] : raw["singer"]
        return MusicTrack(id: mid, title: raw.firstText("title", "name", "songname"),
            artist: singers.array.map { $0["name"].text }.filter { !$0.isEmpty }.joined(separator: " / "), album: album.firstText("name", "title", "albumname"),
            duration: max(0, raw["durationMs"].double > 0 ? raw["durationMs"].double / 1000 : (raw["interval"].isNull ? raw["duration"].double : raw["interval"].double)),
            source: .qq, artworkURL: NativeURLRules.https(cover))
    }

    static func account(_ raw: NativeJSON) -> MusicAccount? {
        guard !raw.isNull else { return nil }
        let info = raw["info"]
        let candidates = [raw["str_musicid"], raw["musicid"], raw["uin"], raw["id"], info["str_musicid"], info["musicid"], info["uin"]]
        let id = candidates.map(\.text).first { !$0.isEmpty && $0 != "0" } ?? ""
        guard !id.isEmpty else { return nil }
        let name = raw.firstText("nickname", "nick", "name", "userName")
        let fallbackName = info.firstText("nickname", "nick", "name", "userName")
        let avatar = raw["avatarUrl"].text.isEmpty ? info.firstText("logo", "avatarUrl") : raw["avatarUrl"].text
        return MusicAccount(id: id, nickname: name.isEmpty ? (fallbackName.isEmpty ? "QQ音乐用户" : fallbackName) : name, avatarURL: NativeURLRules.https(avatar))
    }

    static func collection(_ raw: NativeJSON) -> MusicCollection? {
        let id = raw.firstText("tid", "dissid", "id", "dirId", "dirid")
        guard !id.isEmpty else { return nil }
        return MusicCollection(id: id, title: raw.firstText("dirName", "dirname", "dissname", "title", "name"), source: .qq,
            artworkURL: NativeURLRules.https(raw.firstText("bigpicUrl", "picUrl", "picurl", "coverUrl")),
            trackCount: max(0, raw["songNum"].isNull ? raw["songnum"].int : raw["songNum"].int))
    }
}
