import SwiftUI

// native-ios/Sources/OnlineMusicView.swift
// Folia's cover-first library translated into native lazy views; no nested navigation stack or system List.
struct OnlineMusicView: View {
    @ObservedObject var model: AppModel
    @StateObject private var online: OnlineSourceModel
    @State private var showLogin = false
    @FocusState private var searchFocused: Bool
    private let columns = [GridItem(.adaptive(minimum: 150, maximum: 230), spacing: 12, alignment: .top)]

    init(model: AppModel, source: MusicSource) {
        self.model = model
        _online = StateObject(wrappedValue: OnlineSourceModel(source: source, service: model.service))
    }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 24) {
                searchBar
                accountCard
                if let error = online.error { OnlineMessageCard(text: error, symbol: "exclamationmark.circle") }
                if online.query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { collectionSection }
                else { searchSection }
            }.padding(.horizontal, 20).padding(.top, 12).padding(.bottom, 28)
        }
        .scrollIndicators(.hidden).scrollDismissesKeyboard(.interactively).foregroundStyle(.white)
        .navigationTitle("").toolbar(.hidden, for: .navigationBar)
        .refreshable { await online.refreshAccount(includeCollections: true) }
        .task { await online.refreshAccount(includeCollections: true) }
        .onChange(of: model.qqConnectionRevision) { _, _ in
            if online.source == .qq {
                showLogin = false; online.invalidateAccount()
                Task { await online.refreshAccount(includeCollections: true) }
            }
        }
        .sheet(isPresented: $showLogin) {
            if online.source == .netease {
                NeteaseLoginView(service: model.service) { online.loggedIn($0); showLogin = false }
            } else { QQLoginView(service: model.service) { online.loggedIn($0); showLogin = false } }
        }
    }

    private var searchBar: some View {
        HStack(spacing: 12) {
            Image(systemName: "magnifyingglass").font(.system(size: 17, weight: .medium)).foregroundStyle(.white.opacity(0.55))
            TextField("搜索歌曲、歌手", text: $online.query)
                .accessibilityIdentifier("onlineQuery-\(online.source.rawValue)")
                .font(.system(size: 15)).submitLabel(.search).focused($searchFocused)
                .autocorrectionDisabled().textInputAutocapitalization(.never)
                .onSubmit { online.search(); searchFocused = false }
            if !online.query.isEmpty {
                Button { online.query = ""; online.search() } label: {
                    Image(systemName: "xmark.circle.fill").foregroundStyle(.white.opacity(0.45)).frame(minWidth: 44, minHeight: 44)
                }.accessibilityLabel("清除搜索")
            }
            Button { online.search(); searchFocused = false } label: {
                Image(systemName: "arrow.right").font(.system(size: 15, weight: .semibold))
                    .frame(width: 44, height: 44).background(.white.opacity(0.1), in: Circle())
            }.accessibilityLabel("搜索\(online.source.title)歌曲")
        }
        .padding(.leading, 16).padding(.trailing, 8).padding(.vertical, 8)
        .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 19))
        .overlay(RoundedRectangle(cornerRadius: 19).stroke(.white.opacity(0.1), lineWidth: 1))
    }

    private var accountCard: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack(spacing: 13) {
                TrackArtwork(url: online.account?.avatarURL).frame(width: 49, height: 49).clipShape(Circle())
                    .overlay(Circle().stroke(.white.opacity(0.12), lineWidth: 1))
                VStack(alignment: .leading, spacing: 5) {
                    Text(online.account?.nickname ?? "把你的曲库带进 Folia")
                        .font(.system(size: 16, weight: .semibold)).lineLimit(1)
                    Text(online.account == nil ? "登录\(online.source.title)，读取你的歌单" : "\(online.source.title) · 已登录")
                        .font(.system(size: 11)).foregroundStyle(.white.opacity(0.5)).lineLimit(2)
                }
                Spacer(minLength: 4)
                if online.account == nil {
                    Button("登录") { showLogin = true }
                        .font(.system(size: 12, weight: .semibold)).padding(.horizontal, 16).padding(.vertical, 10).frame(minHeight: 44)
                        .background(.white.opacity(0.12), in: Capsule()).accessibilityLabel("登录\(online.source.title)")
                } else {
                    Menu {
                        Button("刷新账号与歌单") { Task { await online.refreshAccount(includeCollections: true) } }
                        Button("退出登录", role: .destructive) { Task { await online.logout() } }
                    } label: {
                        Image(systemName: "ellipsis").frame(width: 44, height: 44).background(.white.opacity(0.06), in: Circle())
                    }.accessibilityLabel("账号与歌单操作")
                }
            }
            if online.source == .qq {
                Text(model.qqEndpoint.isEmpty
                     ? "搜索可直接使用。登录、歌单和播放需在设置中填写你的 QQ 音乐 HTTPS 服务地址。"
                     : "已设置 QQ 音乐服务。登录后读取歌单，播放仍受账号及歌曲权限影响。")
                    .font(.system(size: 11)).foregroundStyle(.white.opacity(0.5)).lineSpacing(4).fixedSize(horizontal: false, vertical: true)
            }
            if online.refreshing {
                HStack(spacing: 8) {
                    ProgressView().controlSize(.mini)
                    Text("正在同步账号曲库…").font(.system(size: 11)).foregroundStyle(.white.opacity(0.55))
                }
            }
        }
        .padding(17).background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(.white.opacity(0.08), lineWidth: 1))
    }

    private var collectionSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("我的歌单").font(.system(size: 25, weight: .semibold, design: .serif))
                    Text(online.account == nil ? "你的收藏，在这里慢慢展开" : "\(online.collections.count) 张歌单 · \(online.source.title)")
                        .font(.system(size: 11)).foregroundStyle(.white.opacity(0.45))
                }
                Spacer()
                if online.account != nil {
                    Button { Task { await online.refreshAccount(includeCollections: true) } } label: {
                        Image(systemName: "arrow.clockwise").frame(width: 44, height: 44).background(.white.opacity(0.06), in: Circle())
                    }.disabled(online.refreshing).accessibilityLabel("刷新账号与歌单")
                }
            }
            if !online.collections.isEmpty {
                LazyVGrid(columns: columns, spacing: 13) {
                    ForEach(online.collections) { collection in
                        NavigationLink { OnlineCollectionView(model: model, collection: collection) } label: {
                            OnlineCollectionCard(collection: collection)
                        }.buttonStyle(.plain)
                    }
                }
            } else if !online.refreshing {
                OnlineMessageCard(text: online.account == nil ? "登录后显示你的真实歌单，也可以在上方搜索音乐。" : "账号中暂未读取到歌单。你可以刷新重试，或先搜索音乐。", symbol: "square.stack")
            }
        }
    }

    private var searchSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("搜索结果").font(.system(size: 25, weight: .semibold, design: .serif))
                Spacer()
                if online.searching { ProgressView().controlSize(.small) }
                else { Text("\(online.results.count) 首").font(.system(size: 11)).foregroundStyle(.white.opacity(0.45)) }
            }
            if online.results.isEmpty && !online.searching {
                OnlineMessageCard(text: "输入歌名或歌手，按键盘“搜索”开始查找。", symbol: "magnifyingglass")
            }
            LazyVStack(spacing: 4) {
                ForEach(online.results) { track in
                    TrackRow(track: track, loading: model.loadingTrackID == track.id) { model.play(track, among: online.results) }
                        .padding(.horizontal, 10).padding(.vertical, 7)
                        .background(.white.opacity(0.025), in: RoundedRectangle(cornerRadius: 14))
                }
            }
        }
    }
}
