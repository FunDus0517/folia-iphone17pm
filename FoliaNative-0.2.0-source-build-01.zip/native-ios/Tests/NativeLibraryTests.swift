import CryptoKit
import Foundation
import XCTest
@testable import FoliaNative

// native-ios/Tests/NativeLibraryTests.swift
// 文件测试使用独立临时根目录与真实 PCM WAV，不读写用户曲库。
final class NativeLibraryTests: XCTestCase {
    func testRealWAVIsCopiedAndPersistsAcrossRepositoryRestart() async throws {
        let fixture = try LibraryFixture()
        defer { fixture.cleanup() }
        let source = try fixture.wav("测试歌曲.WAV", seconds: 0.4)
        let original = try Data(contentsOf: source)
        let library = LibraryStore(root: fixture.root)
        let result = try await library.importFiles([source])
        XCTAssertTrue(result.failures.isEmpty)
        XCTAssertEqual(result.duplicates, 0)
        let imported = try XCTUnwrap(result.imported.first)
        XCTAssertEqual(imported.title, "测试歌曲")
        XCTAssertEqual(imported.source, .local)
        XCTAssertEqual(imported.duration, 0.4, accuracy: 0.03)
        XCTAssertEqual(imported.originalFilename, "测试歌曲")
        XCTAssertEqual(imported.id, SHA256.hash(data: original).map { String(format: "%02x", $0) }.joined())
        XCTAssertEqual(imported.localFile, "Audio/\(imported.id).wav")
        let owned = try await library.url(for: imported)
        XCTAssertNotEqual(owned.standardizedFileURL, source.standardizedFileURL)
        XCTAssertEqual(try Data(contentsOf: owned), original)
        XCTAssertEqual(try Data(contentsOf: source), original, "导入不修改或移动用户原文件")
        try FileManager.default.removeItem(at: source)
        let restarted = LibraryStore(root: fixture.root)
        let restored = try await restarted.load()
        XCTAssertEqual(restored, [imported])
        let restoredURL = try await restarted.url(for: imported)
        XCTAssertEqual(try Data(contentsOf: restoredURL), original, "原文件删除后仍从自有副本播放")
    }

    func testContentDeduplicationWorksAcrossNamesAndRestarts() async throws {
        let fixture = try LibraryFixture()
        defer { fixture.cleanup() }
        let first = try fixture.wav("第一份.wav", seconds: 0.3)
        let second = fixture.sources.appendingPathComponent("另一文件名.WAV")
        try FileManager.default.copyItem(at: first, to: second)
        let library = LibraryStore(root: fixture.root)
        let result = try await library.importFiles([first, second])
        XCTAssertEqual(result.imported.count, 1)
        XCTAssertEqual(result.duplicates, 1)
        XCTAssertTrue(result.failures.isEmpty)
        let restarted = LibraryStore(root: fixture.root)
        let duplicate = try await restarted.importFiles([second])
        XCTAssertTrue(duplicate.imported.isEmpty)
        XCTAssertEqual(duplicate.duplicates, 1)
        let loaded = try await restarted.load()
        XCTAssertEqual(loaded.count, 1)
        let files = try FileManager.default.contentsOfDirectory(at: fixture.root.appendingPathComponent("Audio"), includingPropertiesForKeys: nil)
        XCTAssertEqual(files.count, 1)
    }

    func testInvalidFormatEmptyFileAndDirectoryAreReportedWithoutOrphanCopies() async throws {
        let fixture = try LibraryFixture()
        defer { fixture.cleanup() }
        let invalid = fixture.sources.appendingPathComponent("伪造音频.wav")
        let unsupported = fixture.sources.appendingPathComponent("说明.txt")
        let empty = fixture.sources.appendingPathComponent("空文件.wav")
        try Data("不是WAV".utf8).write(to: invalid)
        try Data("说明".utf8).write(to: unsupported)
        try Data().write(to: empty)
        let library = LibraryStore(root: fixture.root)
        let result = try await library.importFiles([invalid, unsupported, empty, fixture.sources])
        XCTAssertTrue(result.imported.isEmpty)
        XCTAssertEqual(result.failures.count, 4)
        XCTAssertEqual(result.duplicates, 0)
        let loaded = try await library.load()
        XCTAssertTrue(loaded.isEmpty)
        let copies = try FileManager.default.contentsOfDirectory(at: fixture.root.appendingPathComponent("Audio"), includingPropertiesForKeys: nil)
        XCTAssertTrue(copies.isEmpty)
        XCTAssertTrue(FileManager.default.fileExists(atPath: invalid.path), "失败不删除用户选择的文件")
    }

    func testCorruptManifestIsPreservedAndImportDoesNotOverwriteIt() async throws {
        let fixture = try LibraryFixture()
        defer { fixture.cleanup() }
        try FileManager.default.createDirectory(at: fixture.root, withIntermediateDirectories: true)
        let manifest = fixture.root.appendingPathComponent("library.json")
        let damaged = Data("{\"version\":1,\"tracks\":[损坏".utf8)
        try damaged.write(to: manifest)
        let source = try fixture.wav("新歌曲.wav", seconds: 0.2)
        let library = LibraryStore(root: fixture.root)
        await expectFailure("损坏清单必须报错") { try await library.load() }
        XCTAssertEqual(try Data(contentsOf: manifest), damaged)
        await expectFailure("损坏清单存在时禁止导入覆写") { try await library.importFiles([source]) }
        XCTAssertEqual(try Data(contentsOf: manifest), damaged)
        XCTAssertTrue(FileManager.default.fileExists(atPath: source.path))
    }

    func testFutureManifestVersionIsNotSilentlyRewritten() async throws {
        let fixture = try LibraryFixture()
        defer { fixture.cleanup() }
        try FileManager.default.createDirectory(at: fixture.root, withIntermediateDirectories: true)
        let bytes = Data("{\"version\":999,\"tracks\":[]}".utf8)
        let manifest = fixture.root.appendingPathComponent("library.json")
        try bytes.write(to: manifest)
        let library = LibraryStore(root: fixture.root)
        await expectFailure("较新清单版本必须保留") { try await library.load() }
        XCTAssertEqual(try Data(contentsOf: manifest), bytes)
    }

    func testTraversalAndExternalSourcesAreRejected() async throws {
        let fixture = try LibraryFixture()
        defer { fixture.cleanup() }
        let library = LibraryStore(root: fixture.root)
        _ = try await library.load()
        let badPaths = ["../outside.wav", "/tmp/outside.wav", "Audio/../../outside.wav", "Audio/../outside.wav",
                        "Audio/./music.wav", "Audio\\music.wav", "Audio/music:extra.wav", "Other/music.wav", "Audio/"]
        for path in badPaths {
            let track = localTrack(path: path)
            await expectFailure("应拒绝路径 \(path)") { try await library.url(for: track) }
        }
        var remote = localTrack(path: "Audio/music.wav")
        remote.source = .netease
        await expectFailure("在线歌曲不能借用本地相对路径") { try await library.url(for: remote) }
    }

    func testSymlinkInsideAudioCannotEscapeLibrary() async throws {
        let fixture = try LibraryFixture()
        defer { fixture.cleanup() }
        let outside = try fixture.wav("库外.wav", seconds: 0.2)
        let library = LibraryStore(root: fixture.root)
        _ = try await library.load()
        let link = fixture.root.appendingPathComponent("Audio/external.wav")
        try FileManager.default.createSymbolicLink(at: link, withDestinationURL: outside)
        await expectFailure("Audio内部符号链接不能绕过路径边界") {
            try await library.url(for: self.localTrack(path: "Audio/external.wav"))
        }
        XCTAssertTrue(FileManager.default.fileExists(atPath: outside.path))
    }

    func testSymlinkedAudioDirectoryRejectsExistingAndMissingLeavesWithoutTouchingExternalFiles() async throws {
        let fixture = try LibraryFixture()
        defer { fixture.cleanup() }
        try FileManager.default.createDirectory(at: fixture.root, withIntermediateDirectories: true)
        let source = try fixture.wav("目录外原曲.wav", seconds: 0.2)
        let original = try Data(contentsOf: source)
        let outside = fixture.base.appendingPathComponent("OutsideAudio", isDirectory: true)
        try FileManager.default.createDirectory(at: outside, withIntermediateDirectories: true)
        let existing = outside.appendingPathComponent("existing.wav")
        try original.write(to: existing)
        try FileManager.default.createSymbolicLink(
            at: fixture.root.appendingPathComponent("Audio", isDirectory: true), withDestinationURL: outside)
        let library = LibraryStore(root: fixture.root)

        // 根目录本身的合法别名可以解析；Audio 子目录的链接则必须先于叶子存在性检查被拒绝。
        for filename in ["existing.wav", "not-created-yet.wav"] {
            do {
                _ = try await library.url(for: localTrack(path: "Audio/\(filename)"))
                XCTFail("Audio 目录链接下的路径不应被返回：\(filename)")
            } catch {
                XCTAssertTrue(error.localizedDescription.contains("目录包含外部链接"), error.localizedDescription)
            }
        }
        XCTAssertEqual(try Data(contentsOf: existing), original)
        XCTAssertEqual(try Data(contentsOf: source), original)
        let outsideNames = try FileManager.default.contentsOfDirectory(atPath: outside.path)
        XCTAssertEqual(outsideNames, ["existing.wav"])
    }

    func testCanonicalRootAliasDoesNotRejectLegitimateOwnedAudio() async throws {
        let fixture = try LibraryFixture()
        defer { fixture.cleanup() }
        try FileManager.default.createDirectory(at: fixture.root, withIntermediateDirectories: true)
        let alias = fixture.base.appendingPathComponent("SystemRootAlias", isDirectory: true)
        try FileManager.default.createSymbolicLink(at: alias, withDestinationURL: fixture.root)
        let source = try fixture.wav("合法歌曲.wav", seconds: 0.2)
        let library = LibraryStore(root: alias)
        let result = try await library.importFiles([source])
        XCTAssertTrue(result.failures.isEmpty, result.failures.joined(separator: "\n"))
        let track = try XCTUnwrap(result.imported.first)
        let url = try await library.url(for: track)
        XCTAssertEqual(try Data(contentsOf: url), try Data(contentsOf: source))
        let restored = try await LibraryStore(root: alias).load()
        XCTAssertEqual(restored.count, 1, "系统 /var 到 /private/var 的根规范化不应被当成恶意链接")
    }

    func testPreexistingOwnedSymlinkIsRejectedWithoutTouchingExternalAudio() async throws {
        let fixture = try LibraryFixture()
        defer { fixture.cleanup() }
        let source = try fixture.wav("原始.wav", seconds: 0.2)
        let bytes = try Data(contentsOf: source)
        let digest = SHA256.hash(data: bytes).map { String(format: "%02x", $0) }.joined()
        let library = LibraryStore(root: fixture.root)
        _ = try await library.load()
        let destination = fixture.root.appendingPathComponent("Audio/\(digest).wav")
        try FileManager.default.createSymbolicLink(at: destination, withDestinationURL: source)
        let result = try await library.importFiles([source])
        XCTAssertTrue(result.imported.isEmpty)
        XCTAssertEqual(result.failures.count, 1)
        XCTAssertEqual(try Data(contentsOf: source), bytes)
        let loaded = try await library.load()
        XCTAssertTrue(loaded.isEmpty)
    }

    func testLrcCanBeImportedAlongsideAudioAndLaterReplaced() async throws {
        let fixture = try LibraryFixture()
        defer { fixture.cleanup() }
        let source = try fixture.wav("同名曲.wav", seconds: 0.2)
        let lrc = fixture.sources.appendingPathComponent("同名曲.lrc")
        let initial = "[00:00.00]第一句\n[00:00.10]第二句"
        try Data(initial.utf8).write(to: lrc)
        let library = LibraryStore(root: fixture.root)
        let result = try await library.importFiles([lrc, source])
        XCTAssertTrue(result.failures.isEmpty)
        XCTAssertEqual(result.imported.first?.lyricText, initial)
        var tracks = try await library.load()
        XCTAssertEqual(tracks.first?.lyricText, initial)
        let updated = "[00:00.00]更新歌词"
        try Data(updated.utf8).write(to: lrc, options: .atomic)
        let onlyLrc = try await library.importFiles([lrc])
        XCTAssertTrue(onlyLrc.imported.isEmpty)
        XCTAssertTrue(onlyLrc.failures.isEmpty)
        tracks = try await LibraryStore(root: fixture.root).load()
        XCTAssertEqual(tracks.first?.lyricText, updated)
    }

    func testRemovalDeletesOnlyOwnedCopyAndPersists() async throws {
        let fixture = try LibraryFixture()
        defer { fixture.cleanup() }
        let source = try fixture.wav("可删除.wav", seconds: 0.2)
        let library = LibraryStore(root: fixture.root)
        let result = try await library.importFiles([source])
        let track = try XCTUnwrap(result.imported.first)
        let owned = try await library.url(for: track)
        try await library.remove(track)
        XCTAssertFalse(FileManager.default.fileExists(atPath: owned.path))
        XCTAssertTrue(FileManager.default.fileExists(atPath: source.path))
        let restarted = try await LibraryStore(root: fixture.root).load()
        XCTAssertTrue(restarted.isEmpty)
    }

    func testConcurrentImportsEitherCommitOrExplicitlyReportBusyWithoutLosingTracks() async throws {
        let fixture = try LibraryFixture()
        defer { fixture.cleanup() }
        let first = try fixture.wav("并发甲.wav", seconds: 0.21)
        let second = try fixture.wav("并发乙.wav", seconds: 0.23)
        let library = LibraryStore(root: fixture.root)
        async let firstAttempt = Self.attemptImport(first, library: library)
        async let secondAttempt = Self.attemptImport(second, library: library)
        let attempts = await [firstAttempt, secondAttempt]
        for (attempt, source) in zip(attempts, [first, second]) {
            switch attempt {
            case .completed(let result): XCTAssertEqual(result.imported.count, 1); XCTAssertTrue(result.failures.isEmpty)
            case .failed(let message):
                XCTAssertTrue(message.contains("正在更新"), "并发只能返回明确忙碌提示，而不是静默丢数据：\(message)")
                let retried = try await library.importFiles([source])
                XCTAssertEqual(retried.imported.count, 1)
                XCTAssertTrue(retried.failures.isEmpty)
            }
        }
        let loaded = try await library.load()
        XCTAssertEqual(Set(loaded.map(\.id)).count, 2)
        XCTAssertEqual(loaded.count, 2)
    }

    private enum ImportAttempt: Sendable { case completed(ImportResult), failed(String) }
    private static func attemptImport(_ url: URL, library: LibraryStore) async -> ImportAttempt {
        do { return .completed(try await library.importFiles([url])) }
        catch { return .failed(error.localizedDescription) }
    }

    private func expectFailure<T>(_ message: String, file: StaticString = #filePath, line: UInt = #line,
                                  operation: () async throws -> T) async {
        do { _ = try await operation(); XCTFail(message, file: file, line: line) }
        catch { XCTAssertFalse(error.localizedDescription.isEmpty, file: file, line: line) }
    }

    private func localTrack(path: String) -> MusicTrack {
        MusicTrack(id: "path-test", title: "路径测试", artist: "测试", source: .local, localFile: path)
    }
}

private struct LibraryFixture {
    let base: URL
    let root: URL
    let sources: URL

    init() throws {
        base = FileManager.default.temporaryDirectory.appendingPathComponent("folia-library-\(UUID().uuidString)", isDirectory: true)
        root = base.appendingPathComponent("Library", isDirectory: true)
        sources = base.appendingPathComponent("Picker", isDirectory: true)
        try FileManager.default.createDirectory(at: sources, withIntermediateDirectories: true)
    }

    func cleanup() { try? FileManager.default.removeItem(at: base) }

    func wav(_ name: String, seconds: Double) throws -> URL {
        let rate = 44_100
        let count = Int(Double(rate) * seconds)
        let bytes = UInt32(count * 2)
        var data = Data()
        data.append(contentsOf: "RIFF".utf8); append(UInt32(36) + bytes, to: &data)
        data.append(contentsOf: "WAVEfmt ".utf8); append(UInt32(16), to: &data)
        append(UInt16(1), to: &data); append(UInt16(1), to: &data)
        append(UInt32(rate), to: &data); append(UInt32(rate * 2), to: &data)
        append(UInt16(2), to: &data); append(UInt16(16), to: &data)
        data.append(contentsOf: "data".utf8); append(bytes, to: &data)
        for index in 0..<count { append(Int16(sin(2 * .pi * 330 * Double(index) / Double(rate)) * 900), to: &data) }
        let url = sources.appendingPathComponent(name)
        try data.write(to: url, options: .atomic)
        return url
    }

    private func append<T: FixedWidthInteger>(_ value: T, to data: inout Data) {
        var number = value.littleEndian
        withUnsafeBytes(of: &number) { data.append(contentsOf: $0) }
    }
}
