import AVFoundation
import Foundation

// native-ios/Sources/AudioSessionCoordinator.swift
// 音频生命周期属于整个应用，不随播放器页面出现或消失。
@MainActor
final class AudioSessionCoordinator {
    var onInterruptionBegan: (() -> Void)?
    var onInterruptionEnded: ((Bool) -> Void)?
    var onOutputDisconnected: (() -> Void)?
    var onMediaServicesReset: (() -> Void)?
    private var tokens: [NSObjectProtocol] = []
    private var isConfigured = false

    init() {
        let center = NotificationCenter.default
        tokens.append(center.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: nil) { [weak self] note in
            let type = (note.userInfo?[AVAudioSessionInterruptionTypeKey] as? NSNumber)?.uintValue
            let options = (note.userInfo?[AVAudioSessionInterruptionOptionKey] as? NSNumber)?.uintValue ?? 0
            Task { @MainActor [weak self] in
                guard let type, let kind = AVAudioSession.InterruptionType(rawValue: type) else { return }
                switch kind {
                case .began: self?.onInterruptionBegan?()
                case .ended:
                    let resume = AVAudioSession.InterruptionOptions(rawValue: options).contains(.shouldResume)
                    self?.onInterruptionEnded?(resume)
                @unknown default: break
                }
            }
        })
        tokens.append(center.addObserver(forName: AVAudioSession.routeChangeNotification, object: nil, queue: nil) { [weak self] note in
            let reason = (note.userInfo?[AVAudioSessionRouteChangeReasonKey] as? NSNumber)?.uintValue
            Task { @MainActor [weak self] in
                if reason == AVAudioSession.RouteChangeReason.oldDeviceUnavailable.rawValue {
                    self?.onOutputDisconnected?()
                }
            }
        })
        tokens.append(center.addObserver(forName: AVAudioSession.mediaServicesWereResetNotification, object: nil, queue: nil) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.isConfigured = false
                self?.onMediaServicesReset?()
            }
        })
    }

    func activate() throws {
        let session = AVAudioSession.sharedInstance()
        if !isConfigured {
            try session.setCategory(.playback, mode: .default, options: [])
            isConfigured = true
        }
        try session.setActive(true)
    }

    func deactivate() {
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    func shutdown() {
        for token in tokens { NotificationCenter.default.removeObserver(token) }
        tokens.removeAll()
        onInterruptionBegan = nil
        onInterruptionEnded = nil
        onOutputDisconnected = nil
        onMediaServicesReset = nil
        deactivate()
    }
}
