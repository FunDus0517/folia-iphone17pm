import SwiftUI
import UIKit

// native-ios/Sources/NativeRootView.swift
// 安全区内放操作，只有封面衍生背景铺到屏幕边缘。
struct NativeRootView: View {
    @ObservedObject var model: AppModel
    @State private var source: MusicSource = ProcessInfo.processInfo.arguments.contains("--ui-test-demo") || ProcessInfo.processInfo.arguments.contains("--ui-test-empty") ? .local : .netease
    @State private var showSettings = false
    var body: some View {
        NavigationStack {
            ZStack {
                FoliaRootBackdrop(playback: model.playback)
                VStack(spacing: 0) {
                    header
                    HStack(spacing: 8) {
                        sourceButton(.netease, id: "navNetease")
                        sourceButton(.qq, id: "navQQ")
                        sourceButton(.local, id: "navLocal")
                        Spacer(minLength: 0)
                    }.padding(.horizontal, 18).padding(.bottom, 14)
                    Group {
                        switch source {
                        case .local: FoliaLocalLibrary(model: model)
                        case .netease: OnlineMusicView(model: model, source: .netease)
                        case .qq: OnlineMusicView(model: model, source: .qq)
                        }
                    }.frame(maxWidth: .infinity, maxHeight: .infinity)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) { FoliaPlaybackInset(model: model, playback: model.playback) }
        .tint(Color(red: 0.94, green: 0.90, blue: 0.79)).preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) { FoliaSettingsView(model: model) }
        .fullScreenCover(isPresented: $model.showPlayer) { NativePlayerView(model: model, playback: model.playback) }
        .alert("提示", isPresented: Binding(get: { model.notice != nil }, set: { if !$0 { model.notice = nil } })) {
            Button("知道了", role: .cancel) { model.notice = nil }
        } message: { Text(model.notice ?? "") }
    }
    private var header: some View {
        HStack(alignment: .center, spacing: 12) {
            FoliaBrandMark().frame(width: 38, height: 38).accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 1) {
                Text("Folia").font(.system(size: 33, weight: .light, design: .serif)).tracking(1.2)
                Text("辞曲新境").font(.caption2).tracking(4).foregroundStyle(.white.opacity(0.55))
            }
            Spacer()
            Text("曲库").font(.subheadline.weight(.medium)).foregroundStyle(.white.opacity(0.7))
            FoliaIconButton(title: "设置", symbol: "slider.horizontal.3") { showSettings = true }.accessibilityIdentifier("navSettings")
        }.padding(.horizontal, 18).padding(.top, 4).padding(.bottom, 18)
            .accessibilityElement(children: .contain).accessibilityIdentifier("foliaHeader")
    }
    private func sourceButton(_ value: MusicSource, id: String) -> some View {
        Button { source = value } label: {
            Text(value == .local ? "本地" : value.title)
                .font(.subheadline.weight(source == value ? .semibold : .regular))
                .foregroundStyle(source == value ? .white : .white.opacity(0.55))
                .padding(.horizontal, 18).frame(minHeight: 44)
                .background(source == value ? .white.opacity(0.13) : .white.opacity(0.035), in: Capsule())
                .overlay { Capsule().stroke(.white.opacity(source == value ? 0.2 : 0.07), lineWidth: 0.8) }
        }.buttonStyle(.plain).accessibilityIdentifier(id).accessibilityAddTraits(source == value ? .isSelected : [])
    }
}

private struct FoliaRootBackdrop: View {
    @ObservedObject var playback: NativePlayback
    var body: some View { FoliaBackdrop(url: playback.track?.artworkURL, strength: 0.8) }
}

private struct FoliaPlaybackInset: View {
    @ObservedObject var model: AppModel
    @ObservedObject var playback: NativePlayback
    var body: some View {
        if playback.track != nil {
            NativeMiniPlayer(playback: playback, open: { model.showPlayer = true })
                .accessibilityElement(children: .contain).accessibilityIdentifier("miniPlayerContainer")
        }
    }
}

private struct FoliaBrandMark: View {
    private var image: UIImage? {
        guard let url = Bundle.main.url(forResource: "folia-mark", withExtension: "png") else { return nil }
        return UIImage(contentsOfFile: url.path)
    }
    var body: some View {
        Group {
            if let image { Image(uiImage: image).resizable().scaledToFit() }
            else { Text("F").font(.system(size: 35, weight: .black, design: .serif)) }
        }
    }
}
