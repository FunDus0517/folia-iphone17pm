import SwiftUI

// native-ios/Sources/FoliaAppearance.swift
// 复用原仓库默认封面及封面衍生氛围；静态纹理不使用逐帧计时器。
enum FoliaLayout {
    static func columns(for width: Double) -> Int { width >= 900 ? 4 : (width >= 600 ? 3 : 2) }
    static let minimumTouchSize: Double = 44
    static func tileHeight(for width: Double, index: Int) -> Double {
        guard width.isFinite, width > 0 else { return 150 }
        return max(150, min(width, 1200) * (index.isMultiple(of: 3) ? 1.28 : 1.12))
    }
    static var defaultArtwork: URL? { Bundle.main.url(forResource: "folia-cover", withExtension: "jpg") }
}

struct FoliaBackdrop: View {
    var url: URL?
    var strength: Double = 1
    @AppStorage("foliaNativeReducedEffects") private var reducedEffects = false
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                LinearGradient(colors: [Color(red: 0.18, green: 0.18, blue: 0.20), Color(red: 0.16, green: 0.13, blue: 0.08), .black], startPoint: .topLeading, endPoint: .bottomTrailing)
                if !reducedEffects {
                    TrackArtwork(url: url ?? FoliaLayout.defaultArtwork)
                        .frame(width: geometry.size.width, height: geometry.size.height)
                        .blur(radius: 48, opaque: true).opacity(0.45 * strength).allowsHitTesting(false)
                    Canvas { context, size in
                        var dots = Path()
                        for x in stride(from: 4.0, to: size.width, by: 14) {
                            for y in stride(from: 4.0, to: size.height, by: 14) {
                                dots.addRect(CGRect(x: x, y: y, width: 1.6, height: 1.6))
                            }
                        }
                        context.fill(dots, with: .color(.white.opacity(0.075)))
                    }.allowsHitTesting(false)
                }
                LinearGradient(colors: [.black.opacity(0.18), .black.opacity(0.35), .black.opacity(0.82)], startPoint: .top, endPoint: .bottom)
            }
        }.ignoresSafeArea().accessibilityHidden(true)
    }
}

struct FoliaGlass: ViewModifier {
    var radius: CGFloat = 22
    func body(content: Content) -> some View {
        content.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: radius))
            .overlay { RoundedRectangle(cornerRadius: radius).stroke(.white.opacity(0.13), lineWidth: 0.8) }
    }
}

struct FoliaIconButton: View {
    let title: String
    let symbol: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: symbol).font(.system(size: 19, weight: .medium))
                .frame(width: 44, height: 44).background(.white.opacity(0.08), in: Circle())
                .overlay { Circle().stroke(.white.opacity(0.12), lineWidth: 0.8) }
        }.buttonStyle(.plain).accessibilityLabel(title)
    }
}
