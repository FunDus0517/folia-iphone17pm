import Foundation

// native-ios/Sources/Services/NativeJSON.swift
// Provider envelopes never cross the NativeMusicService facade into the UI.
enum NativeJSON: Codable, Sendable, Equatable {
    case object([String: NativeJSON]), array([NativeJSON]), string(String), number(Double), bool(Bool), null

    init(from decoder: Decoder) throws {
        let value = try decoder.singleValueContainer()
        if value.decodeNil() { self = .null }
        else if let object = try? value.decode([String: NativeJSON].self) { self = .object(object) }
        else if let array = try? value.decode([NativeJSON].self) { self = .array(array) }
        else if let text = try? value.decode(String.self) { self = .string(text) }
        else if let flag = try? value.decode(Bool.self) { self = .bool(flag) }
        else { self = .number(try value.decode(Double.self)) }
    }

    func encode(to encoder: Encoder) throws {
        var value = encoder.singleValueContainer()
        switch self {
        case .object(let object): try value.encode(object)
        case .array(let array): try value.encode(array)
        case .string(let text): try value.encode(text)
        case .number(let number): try value.encode(number)
        case .bool(let flag): try value.encode(flag)
        case .null: try value.encodeNil()
        }
    }

    subscript(_ key: String) -> NativeJSON { object[key] ?? .null }
    var object: [String: NativeJSON] { if case .object(let value) = self { return value }; return [:] }
    var array: [NativeJSON] { if case .array(let value) = self { return value }; return [] }
    var text: String {
        switch self {
        case .string(let value): return value
        case .number(let value): return value.rounded() == value ? String(format: "%.0f", value) : String(value)
        case .bool(let value): return value ? "true" : "false"
        default: return ""
        }
    }
    var double: Double { if case .number(let value) = self { return value }; return Double(text) ?? 0 }
    var int: Int { Int(clamping: Int64(double.isFinite ? max(Double(Int64.min + 1024), min(double, Double(Int64.max - 1024))) : 0)) }
    var isNull: Bool { self == .null }
    var flag: Bool { if case .bool(let value) = self { return value }; return false }

    func firstText(_ keys: String...) -> String {
        for key in keys { let value = self[key].text.trimmingCharacters(in: .whitespacesAndNewlines); if !value.isEmpty { return value } }
        return ""
    }

    func encoded() throws -> Data {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys, .withoutEscapingSlashes]
        return try encoder.encode(self)
    }
    static func decoded(_ data: Data) throws -> NativeJSON {
        do { return try JSONDecoder().decode(NativeJSON.self, from: data) }
        catch { throw NativeMusicError.message("音乐服务返回的数据格式异常，请稍后重试") }
    }
}

enum NativeURLRules {
    static func https(_ text: String) -> URL? {
        guard var parts = URLComponents(string: text), parts.user == nil, parts.password == nil,
              let host = parts.host, !host.isEmpty else { return nil }
        // Known upstream covers/audio still occasionally use http; upgrade, never allow arbitrary schemes.
        if parts.scheme?.lowercased() == "http" { parts.scheme = "https" }
        guard parts.scheme?.lowercased() == "https" else { return nil }
        return parts.url
    }

    static func form(_ values: [String: String]) -> Data {
        Data(values.keys.sorted().map { "\(escape($0))=\(escape(values[$0] ?? ""))" }.joined(separator: "&").utf8)
    }
    static func escape(_ value: String) -> String {
        let allowed = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789*-._")
        return (value.addingPercentEncoding(withAllowedCharacters: allowed) ?? "").replacingOccurrences(of: "%20", with: "+")
    }
}
