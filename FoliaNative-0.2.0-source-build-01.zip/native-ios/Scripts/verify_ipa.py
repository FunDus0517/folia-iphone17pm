#!/usr/bin/env python3
import argparse
import hashlib
import json
import pathlib
import plistlib
import re
import stat
import struct
import sys
import zipfile
from datetime import datetime, timezone

# native-ios/Scripts/verify_ipa.py — 用真实 XCTest 结果与 Mach-O 字段验证独立原生包。
MAX_BYTES = 500 * 1024 * 1024
FORBIDDEN_RESOURCES = {".js", ".mjs", ".cjs", ".html", ".htm", ".wasm", ".css"}
FORBIDDEN_FRAMEWORKS = ("webkit", "capacitor", "javascriptcore", "cordova")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def validate_tests(summary_path, result_path):
    """不接受仅有目录、零用例、全跳过或失败的结果包。"""
    result = pathlib.Path(result_path)
    require(result.suffix == ".xcresult" and result.is_dir(), "真实 .xcresult 目录缺失")
    require((result / "Info.plist").is_file(), "结果包缺少 Info.plist")
    require((result / "Data").is_dir() and any((result / "Data").rglob("*")), "结果包缺少实际测试数据")
    summary = json.loads(pathlib.Path(summary_path).read_text(encoding="utf-8"))
    for key in ("totalTestCount", "passedTests", "failedTests", "skippedTests"):
        require(type(summary.get(key)) is int and summary[key] >= 0, "测试统计字段错误：" + key)
    require(summary["result"] == "Passed", "测试结果不是 Passed")
    require(summary["totalTestCount"] > 0 and summary["passedTests"] > 0, "测试没有实际通过的用例")
    require(summary["failedTests"] == 0, "测试存在失败")
    require(not summary.get("testFailures"), "测试结果包含失败详情")
    return {key: summary[key] for key in ("result", "totalTestCount", "passedTests", "failedTests", "skippedTests")}


def macho_metadata(data):
    """直接解析薄 Mach-O 64 位 arm64；区分真机 IOS 与模拟器并拒绝签名命令。"""
    require(len(data) >= 32 and data[:4] == b"\xcf\xfa\xed\xfe", "不是薄 little-endian Mach-O 64")
    _, cpu, subtype, filetype, ncmds, sizeofcmds, _, _ = struct.unpack_from("<8I", data)
    require(cpu == 0x0100000C, "Mach-O 架构不是 arm64")
    require(filetype in (2, 6, 8), "不支持的 Mach-O 类型")
    require(ncmds < 10000 and 32 + sizeofcmds <= len(data), "Mach-O 命令区无效")
    position, platforms, dependencies = 32, [], []
    for _ in range(ncmds):
        require(position + 8 <= 32 + sizeofcmds, "Mach-O 命令越界")
        command, size = struct.unpack_from("<2I", data, position)
        require(size >= 8 and position + size <= 32 + sizeofcmds, "Mach-O 命令长度无效")
        require(command != 0x1D, "Mach-O 含 LC_CODE_SIGNATURE，不是未签名包")
        if command == 0x32:
            require(size >= 24, "LC_BUILD_VERSION 长度无效")
            platforms.append(struct.unpack_from("<I", data, position + 8)[0])
        if command in (0xC, 0x20, 0x18 | 0x80000000, 0x1F | 0x80000000, 0x23 | 0x80000000):
            require(size >= 24, "动态库命令长度无效")
            name_offset = struct.unpack_from("<I", data, position + 8)[0]
            require(24 <= name_offset < size, "动态库名称偏移无效")
            name = data[position + name_offset:position + size].split(b"\0", 1)[0].decode("utf-8")
            require(not any(word in name.lower() for word in FORBIDDEN_FRAMEWORKS), "禁止网页框架依赖：" + name)
            dependencies.append(name)
        position += size
    require(position == 32 + sizeofcmds, "Mach-O 命令计数和长度不一致")
    require(platforms and all(platform == 2 for platform in platforms), "Mach-O 不是 IOS 真机平台")
    return {"architecture": "arm64", "platform": "IOS", "unsigned": True, "dependencies": dependencies}


def zip_members(archive):
    """在读数据前检查所有路径、重复项、链接与膨胀大小。"""
    members, seen, total = [], set(), 0
    require(len(archive.infolist()) <= 20000, "ZIP 项目过多")
    for entry in archive.infolist():
        name = entry.filename
        path = pathlib.PurePosixPath(name)
        require(name and "\\" not in name and not path.is_absolute(), "ZIP 含绝对路径或反斜杠")
        require(not any(part in ("..", ".") for part in path.parts) and ":" not in name, "ZIP 路径无效")
        require("\0" not in name and not (entry.flag_bits & 1), "ZIP 含无效/加密项目")
        key = name.rstrip("/").casefold()
        require(key not in seen, "ZIP 含重复路径：" + name)
        seen.add(key)
        require(not stat.S_ISLNK(entry.external_attr >> 16), "ZIP 不接受软链接：" + name)
        total += entry.file_size
        require(total <= MAX_BYTES, "ZIP 解压大小超限")
        members.append(entry)
    return members


def verify_ipa(args):
    ipa = pathlib.Path(args.ipa)
    require(ipa.stat().st_size > 1024, "IPA 文件过小")
    with zipfile.ZipFile(ipa) as archive:
        entries = zip_members(archive)
        require(archive.testzip() is None, "IPA ZIP CRC 校验失败")
        files = {entry.filename: archive.read(entry) for entry in entries if not entry.is_dir()}
    info_paths = [name for name in files if re.fullmatch(r"Payload/[^/]+\.app/Info\.plist", name)]
    require(len(info_paths) == 1, "IPA 必须包含唯一 Payload/*.app/Info.plist")
    prefix = info_paths[0][:-len("Info.plist")]
    require(all(name.startswith(prefix) for name in files), "IPA 含应用目录之外的文件")
    info = plistlib.loads(files[info_paths[0]])
    require(info.get("CFBundleIdentifier") == "io.github.fundus0517.folia.native", "bundle ID 不符")
    require(info.get("DTPlatformName") == "iphoneos", "Info.plist 平台不是 iphoneos")
    require(info.get("CFBundlePackageType") == "APPL", "包类型不是 APPL")
    require(info.get("CFBundleDisplayName") == "Folia 原生", "应用中文名称不符")
    require("audio" in info.get("UIBackgroundModes", []), "没有声明后台音频")
    executable = info.get("CFBundleExecutable", "")
    require(executable and "/" not in executable and "\\" not in executable, "应用可执行文件名错误")
    require(prefix + executable in files, "应用可执行文件缺失")
    main_metadata, binaries = None, []
    for name, content in files.items():
        rel = pathlib.PurePosixPath(name[len(prefix):])
        lower = name.lower()
        require("_codesignature" not in lower and not lower.endswith("embedded.mobileprovision"), "发现签名资源")
        require(rel.suffix.lower() not in FORBIDDEN_RESOURCES, "发现网页资源：" + name)
        require(not any(word in lower for word in FORBIDDEN_FRAMEWORKS), "发现网页运行时资源：" + name)
        if content[:4] in (b"\xcf\xfa\xed\xfe", b"\xce\xfa\xed\xfe", b"\xfe\xed\xfa\xcf", b"\xfe\xed\xfa\xce", b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca", b"\xca\xfe\xba\xbf", b"\xbf\xba\xfe\xca"):
            metadata = macho_metadata(content)
            binaries.append({"path": rel.as_posix(), "sha256": sha256(content), **metadata})
            if name == prefix + executable:
                main_metadata = metadata
    require(main_metadata is not None, "主程序不是可验证的原生 Mach-O")
    source_app = pathlib.Path(args.archive_app).resolve()
    expected = {}
    for path in source_app.rglob("*"):
        require(not path.is_symlink(), "原始 archive 中存在软链接")
        if path.is_file():
            expected[path.relative_to(source_app).as_posix()] = sha256(path.read_bytes())
    packaged = {name[len(prefix):]: sha256(content) for name, content in files.items()}
    require(expected == packaged, "IPA 与本次 archive 文件清单或摘要不一致")
    unit = validate_tests(args.unit_summary, args.unit_result)
    ui = validate_tests(args.ui_summary, args.ui_result)
    source = json.loads(pathlib.Path(args.source_info).read_text(encoding="utf-8"))
    require(re.fullmatch(r"[0-9a-f]{64}", source.get("manifestSha256", "")), "源码清单摘要缺失")
    require(source.get("files") and "project.yml" in source["files"], "源码清单缺失")
    source_archive_sha = source.get("sourceArchiveSha256")
    require(source_archive_sha is None or re.fullmatch(r"[0-9a-f]{64}", source_archive_sha), "源码压缩包摘要错误")
    digest = sha256(ipa.read_bytes())
    record = {"builtAtUTC": datetime.now(timezone.utc).isoformat(), "ipa": ipa.name,
              "ipaBytes": ipa.stat().st_size, "ipaSha256": digest,
              "bundleIdentifier": info["CFBundleIdentifier"], "version": info.get("CFBundleShortVersionString"),
              "build": info.get("CFBundleVersion"), "nativeBinaries": binaries,
              "webRuntimeResources": 0, "archiveFilesMatched": len(expected),
              "tests": {"unit": unit, "ui": ui}, "source": source,
              "physicalDeviceTested": False, "requiresUserSigning": True}
    pathlib.Path(args.output).write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    ipa.with_suffix(ipa.suffix + ".sha256").write_text(digest + "  " + ipa.name + "\n", encoding="ascii")
    print("IPA_VERIFY_OK: 原生 arm64/IOS，未签名，无网页资源，archive 文件逐一匹配；单元/UI 测试均真实通过。")


def main():
    parser = argparse.ArgumentParser(description="验证原生 IPA 和实际 XCTest 结果")
    commands = parser.add_subparsers(dest="command", required=True)
    tests = commands.add_parser("tests")
    tests.add_argument("--summary", required=True)
    tests.add_argument("--result", required=True)
    ipa = commands.add_parser("ipa")
    for name in ("ipa", "archive-app", "source-info", "output", "unit-summary", "unit-result", "ui-summary", "ui-result"):
        ipa.add_argument("--" + name, required=True)
    args = parser.parse_args()
    if args.command == "tests":
        print("XCTEST_VERIFY_OK: " + json.dumps(validate_tests(args.summary, args.result), ensure_ascii=False))
    else:
        verify_ipa(args)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, KeyError, zipfile.BadZipFile, plistlib.InvalidFileException, json.JSONDecodeError) as error:
        print("VERIFY_FAILED: " + str(error), file=sys.stderr)
        raise SystemExit(1)
