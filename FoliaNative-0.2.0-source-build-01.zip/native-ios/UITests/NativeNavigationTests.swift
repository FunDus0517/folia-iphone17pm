import XCTest

// native-ios/UITests/NativeNavigationTests.swift
@MainActor
final class NativeNavigationTests: XCTestCase {
    private var app: XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure = false
        XCUIDevice.shared.orientation = .portrait
        app = XCUIApplication()
        app.launchArguments = ["--ui-test-demo"]
        app.launch()
    }

    override func tearDownWithError() throws {
        attachScreenshot("最终界面与失败现场")
        let hierarchy = XCTAttachment(string: app.debugDescription)
        hierarchy.name = "实际原生无障碍层级"; hierarchy.lifetime = .keepAlways
        add(hierarchy)
        XCUIDevice.shared.orientation = .portrait
        app.terminate()
    }

    func testRealAudioAdvancesAndLyricsAgreeOutsideAndInside() throws {
        let row = demoTrackButton
        XCTAssertTrue(row.waitForExistence(timeout: 15))
        row.tap()
        let open = app.buttons["openPlayer"]
        XCTAssertTrue(open.waitForExistence(timeout: 15))
        open.tap()
        selectReadableLyrics()
        let seconds = app.staticTexts["playbackSeconds"]
        XCTAssertTrue(seconds.waitForExistence(timeout: 10))
        let advances = NSPredicate { _, _ in (Double(seconds.value as? String ?? "") ?? 0) > 1.2 }
        expectation(for: advances, evaluatedWith: nil)
        waitForExpectations(timeout: 15)
        app.buttons["fullToggle"].tap()
        XCTAssertEqual(app.buttons["fullToggle"].label, "播放")
        let before = Double(seconds.value as? String ?? "") ?? -1
        // 真实时钟暂停后两秒不得继续走，不用注入假时间。
        let paused = expectation(description: "真实播放暂停稳定")
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { paused.fulfill() }
        wait(for: [paused], timeout: 4)
        XCTAssertEqual(Double(seconds.value as? String ?? "") ?? -100, before, accuracy: 0.3)
        let slider = app.sliders["playbackProgress"]
        slider.adjust(toNormalizedSliderPosition: 0.75)
        let seeks = NSPredicate { _, _ in (Double(seconds.value as? String ?? "") ?? 0) > 20 }
        expectation(for: seeks, evaluatedWith: nil)
        waitForExpectations(timeout: 8)
        let line = app.buttons["lyric-row-3"]
        XCTAssertTrue(line.waitForExistence(timeout: 5))
        XCTAssertEqual(line.value as? String, "当前歌词")
        app.buttons["closePlayer"].tap()
        XCTAssertTrue(app.buttons["closePlayer"].waitForNonExistence(timeout: 8), "完整播放页必须真正关闭")
        XCTAssertTrue(open.waitForExistence(timeout: 5))
        XCTAssertEqual(open.value as? String, "原生歌词第四行")
        open.tap()
        selectReadableLyrics()
        XCTAssertEqual(app.buttons["lyric-row-3"].value as? String, "当前歌词")
        attachScreenshot("原生竖屏歌词与实际播放进度")
    }

    func testRepeatedPlayerNavigationRotationAndNativeTabsRemainResponsive() throws {
        let row = demoTrackButton
        XCTAssertTrue(row.waitForExistence(timeout: 15)); row.tap()
        let open = app.buttons["openPlayer"]
        XCTAssertTrue(open.waitForExistence(timeout: 15))
        app.buttons["miniToggle"].tap()
        for index in 0..<10 {
            XCTAssertTrue(open.isHittable)
            open.tap()
            let close = app.buttons["closePlayer"]
            XCTAssertTrue(close.waitForExistence(timeout: 5))
            XCUIDevice.shared.orientation = index.isMultiple(of: 2) ? .landscapeLeft : .portrait
            let landscape = index.isMultiple(of: 2)
            let rotated = NSPredicate { _, _ in
                let frame = self.app.frame
                return landscape ? frame.width > frame.height : frame.height > frame.width
            }
            expectation(for: rotated, evaluatedWith: nil)
            waitForExpectations(timeout: 8)
            XCTAssertTrue(app.sliders["playbackProgress"].waitForExistence(timeout: 5))
            XCTAssertTrue(close.isHittable)
            XCTAssertTrue(app.buttons["fullToggle"].isHittable)
            let screen = app.frame
            let controls = app.buttons["fullToggle"].frame
            XCTAssertGreaterThanOrEqual(controls.minY, screen.minY)
            XCTAssertLessThanOrEqual(controls.maxY, screen.maxY)
            if index == 0 { attachScreenshot("原生横屏布局") }
            close.tap()
            XCTAssertTrue(close.waitForNonExistence(timeout: 8), "第\(index + 1)轮播放页仍未退出")
            XCTAssertTrue(open.waitForExistence(timeout: 5))
            XCTAssertTrue(open.isHittable)
            assertPlaybackIsInsideSafeAreaAndBelowHeader(capture: index == 0)
        }
        XCUIDevice.shared.orientation = .portrait
        assertPlaybackIsInsideSafeAreaAndBelowHeader()
        let settings = app.buttons["navSettings"]
        XCTAssertTrue(settings.isHittable)
        settings.tap()
        XCTAssertTrue(app.buttons["closeSettings"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.textFields["qqEndpointField"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.textFields["qqEndpointField"].isHittable)
        closeSettings()
        tapSource("navQQ")
        XCTAssertTrue(app.buttons["登录QQ音乐"].waitForExistence(timeout: 5))
        tapSource("navNetease")
        app.buttons["登录网易云"].tap()
        XCTAssertTrue(app.textFields["中国大陆手机号"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["获取验证码"].exists)
        // 不点击发送按钮；测试绝不发送真实短信，也不登录真实账号。
        app.buttons["取消"].tap()
        tapSource("navLocal")
        XCTAssertTrue(app.buttons["importMusic"].waitForExistence(timeout: 5))
        assertPlaybackIsInsideSafeAreaAndBelowHeader()
        attachScreenshot("Folia 曲墙与文件导入入口")
    }

    func testFreshSettingsCanBeSelectedAndAddressCanBeEdited() throws {
        let row = demoTrackButton
        XCTAssertTrue(row.waitForExistence(timeout: 15))
        let settings = app.buttons["navSettings"]
        XCTAssertTrue(settings.isHittable)
        settings.tap()
        let field = app.textFields["qqEndpointField"]
        XCTAssertTrue(field.waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["closeSettings"].waitForExistence(timeout: 5))
        XCTAssertTrue(field.isHittable)
        field.tap()
        // URL 键盘切换符号页时逐键等待原生输入响应，最终仍严格核对全部字符。
        for character in "https://example.org" { field.typeText(String(character)) }
        XCTAssertEqual(field.value as? String, "https://example.org")
        // 不保存示例地址，不发送网络请求或创建会话。
        attachScreenshot("Folia 设置草稿完整可编辑")
        closeSettings()
        XCTAssertTrue(app.buttons["navLocal"].isHittable)
    }

    func testFoliaCoverWallUsesArtworkTilesAndNativeNavigation() throws {
        XCTAssertTrue(demoTrackButton.waitForExistence(timeout: 15))
        XCTAssertEqual(app.tabBars.count, 0, "Folia 使用顶部源选择，不应回退成系统标签列表播放器")
        XCTAssertEqual(app.webViews.count, 0, "曲墙必须由原生视图绘制")
        for id in ["navSettings", "navNetease", "navQQ", "navLocal"] {
            XCTAssertTrue(app.buttons[id].isHittable, "顶部导航必须直接可点：\(id)")
        }
        let tiles = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH 'track-'"))
        expectation(for: NSPredicate { _, _ in tiles.count >= 3 }, evaluatedWith: nil)
        waitForExpectations(timeout: 10)
        let frames = (0..<3).map { tiles.element(boundBy: $0).frame }
        for frame in frames {
            XCTAssertGreaterThanOrEqual(frame.height, 150, "曲墙必须是封面卡片，不是高度几十点的歌曲列表行")
            XCTAssertGreaterThanOrEqual(frame.width, 120)
        }
        XCTAssertGreaterThanOrEqual(Set(frames.map { Int($0.minX.rounded()) }).count, 2, "竖屏曲墙至少使用两列")
        for left in 0..<frames.count {
            for right in (left + 1)..<frames.count {
                XCTAssertFalse(frames[left].intersects(frames[right]), "曲墙卡片不得相互覆盖")
            }
        }
        attachScreenshot("Folia 原生封面曲墙与顶部品牌导航")
    }

    func testEmptyLocalLibraryKeepsFoliaBrandAndNativeImportAvailable() throws {
        app.terminate()
        app.launchArguments = ["--ui-test-empty"]
        app.launch()
        let local = app.buttons["navLocal"]
        XCTAssertTrue(local.waitForExistence(timeout: 15))
        XCTAssertTrue(local.isHittable)
        local.tap()
        XCTAssertTrue(app.buttons["importMusic"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.buttons["importMusic"].isHittable)
        XCTAssertTrue(app.buttons["navSettings"].isHittable)
        XCTAssertTrue(app.descendants(matching: .any)["foliaHeader"].exists)
        XCTAssertEqual(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH 'track-'")).count, 0)
        XCTAssertFalse(app.buttons["openPlayer"].exists, "没有播放歌曲时不应伪造播放胶囊")
        XCTAssertEqual(app.tabBars.count, 0)
        XCTAssertEqual(app.webViews.count, 0)
        attachScreenshot("Folia 空曲库保留品牌背景和原生导入")
    }

    private var demoTrackButton: XCUIElement {
        app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH 'track-' AND label CONTAINS %@", "原生播放验证")).firstMatch
    }

    private func selectReadableLyrics() {
        let style = app.buttons["lyricStyleToggle"]
        XCTAssertTrue(style.waitForExistence(timeout: 5))
        // 默认沉浸模式的进入/退出也参与测试；逐行模式用于保留已有定位和行高亮断言。
        if style.value as? String == "沉浸" {
            attachScreenshot("Folia 默认沉浸歌词实际画面")
            style.tap()
        }
        XCTAssertEqual(style.value as? String, "逐行")
    }

    private func closeSettings() {
        let close = app.buttons["closeSettings"]
        XCTAssertTrue(close.isHittable)
        close.tap()
        XCTAssertTrue(close.waitForNonExistence(timeout: 8), "设置必须真正关闭，不能只查询背景按钮")
        XCTAssertTrue(app.buttons["navSettings"].isHittable)
    }

    private func tapSource(_ id: String) {
        let button = app.buttons[id]
        XCTAssertTrue(button.waitForExistence(timeout: 5))
        XCTAssertTrue(button.isHittable)
        button.tap()
    }

    private func assertPlaybackIsInsideSafeAreaAndBelowHeader(capture: Bool = true) {
        // 固定 CI 为 iPhone 17 Pro Max / iOS 26.2；这些安全边界来自同机型实际基线。
        let screen = app.frame
        let landscape = screen.width > screen.height
        let safe = CGRect(x: screen.minX + (landscape ? 62 : 0), y: screen.minY + (landscape ? 0 : 62),
                          width: screen.width - (landscape ? 124 : 0), height: screen.height - (landscape ? 21 : 96))
        let container = app.descendants(matching: .any)["miniPlayerContainer"]
        XCTAssertTrue(container.exists)
        let controls = container.frame
        XCTAssertFalse(controls.isEmpty)
        XCTAssertTrue(safe.insetBy(dx: -1, dy: -1).contains(controls), "整个播放胶囊必须位于安全区内：\(controls)，安全区=\(safe)")
        let header = app.descendants(matching: .any)["foliaHeader"]
        XCTAssertTrue(header.exists)
        XCTAssertFalse(header.frame.intersects(controls), "整个顶部品牌栏与播放胶囊不得相交")
        for id in ["openPlayer", "miniToggle"] {
            let button = app.buttons[id]
            XCTAssertTrue(button.exists)
            XCTAssertTrue(button.isHittable)
            XCTAssertTrue(safe.insetBy(dx: -1, dy: -1).contains(button.frame), "\(id) 必须完整避开状态栏/灵动岛/底部手势区：\(button.frame)，安全区=\(safe)")
        }
        for id in ["navSettings", "navNetease", "navQQ", "navLocal"] {
            let button = app.buttons[id]
            XCTAssertTrue(button.isHittable)
            XCTAssertFalse(button.frame.intersects(controls), "播放胶囊不得遮挡顶部导航：\(id)")
        }
        if capture { attachScreenshot("Folia 胶囊与顶部导航实际位置") }
    }

    private func attachScreenshot(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways
        add(attachment)
    }
}
