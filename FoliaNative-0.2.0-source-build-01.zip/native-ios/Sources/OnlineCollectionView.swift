import SwiftUI

// native-ios/Sources/OnlineCollectionView.swift
// A native cover-led collection surface; all track data stays behind the shared service facade.
struct OnlineCollectionView: View {
    @ObservedObject var model: AppModel
    let collection: MusicCollection
    @Environment(\.dismiss) private var dismiss
    @State private var tracks: [MusicTrack] = []
    @State private var loading = false
    @State private var error: String?

    var body: some View {
        ZStack {
            FoliaBackdrop(url: collection.artworkURL, strength: 0.8)
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 24) {
                    header
                    if let error {
                        OnlineMessageCard(text: error, symbol: "exclamationmark.circle")
                        Button { Task { await load() } } label: { Label("重新加载歌单", systemImage: "arrow.clockwise") }
                            .font(.system(size: 13)).padding(12).background(.white.opacity(0.08), in: Capsule())
                    }
                    HStack {
                        Text("全部歌曲").font(.system(size: 21, weight: .semibold, design: .serif))
                        Spacer()
                        if loading { ProgressView().controlSize(.small) }
                        else { Text("\(tracks.count) 首").font(.system(size: 11)).foregroundStyle(.white.opacity(0.45)) }
                    }
                    if tracks.isEmpty, !loading, error == nil {
                        OnlineMessageCard(text: "这个歌单暂时没有可显示的歌曲。", symbol: "music.note.list")
                    }
                    LazyVStack(spacing: 4) {
                        ForEach(tracks) { track in
                            TrackRow(track: track, loading: model.loadingTrackID == track.id) { model.play(track, among: tracks) }
                                .padding(.horizontal, 10).padding(.vertical, 7)
                                .background(.white.opacity(0.025), in: RoundedRectangle(cornerRadius: 14))
                        }
                    }
                }.padding(.horizontal, 20).padding(.top, 12).padding(.bottom, 28)
            }.scrollIndicators(.hidden)
        }
        .foregroundStyle(.white).navigationTitle("").toolbar(.hidden, for: .navigationBar)
        .task(id: "\(collection.source.rawValue):\(collection.id)") { await load() }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 23) {
            Button { dismiss() } label: {
                Image(systemName: "chevron.left").font(.system(size: 16, weight: .medium))
                    .frame(width: 44, height: 44).background(.white.opacity(0.075), in: Circle())
                    .overlay(Circle().stroke(.white.opacity(0.1), lineWidth: 1))
            }.accessibilityLabel("返回曲库")
            HStack(alignment: .bottom, spacing: 18) {
                TrackArtwork(url: collection.artworkURL).frame(width: 124, height: 145)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(.white.opacity(0.16), lineWidth: 1))
                VStack(alignment: .leading, spacing: 10) {
                    Text("歌单 / \(collection.source.title)").font(.system(size: 10, weight: .medium, design: .monospaced)).foregroundStyle(.white.opacity(0.5))
                    Text(collection.title).font(.system(size: 23, weight: .semibold, design: .serif)).lineLimit(4).minimumScaleFactor(0.85)
                    Text("\(collection.trackCount) 首歌曲").font(.system(size: 11)).foregroundStyle(.white.opacity(0.48))
                }.frame(maxWidth: .infinity, alignment: .leading)
            }
            Button {
                if let first = tracks.first { model.play(first, among: tracks) }
            } label: {
                HStack(spacing: 9) {
                    Image(systemName: "play.fill").font(.system(size: 12))
                    Text(loading ? "正在读取歌单…" : "播放全部").font(.system(size: 14, weight: .semibold))
                    Spacer()
                    Image(systemName: "arrow.right").font(.system(size: 12))
                }.padding(.horizontal, 20).padding(.vertical, 16)
                    .foregroundStyle(.black.opacity(0.85)).background(.white.opacity(0.9), in: Capsule())
            }.disabled(tracks.isEmpty || loading).opacity(tracks.isEmpty || loading ? 0.45 : 1).accessibilityLabel("播放全部歌曲")
        }
    }

    private func load() async {
        loading = true; error = nil
        defer { loading = false }
        do {
            let rows = try await model.service.tracks(in: collection)
            try Task.checkCancellation()
            tracks = rows
        } catch { if !Task.isCancelled { self.error = error.localizedDescription } }
    }
}
