import SwiftUI
import UIKit

// native-ios/Sources/NativeLoginViews.swift
struct NeteaseLoginView: View {
    let service: NativeMusicService
    let completed: (MusicAccount) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var phone = ""
    @State private var code = ""
    @State private var busy = false
    @State private var nextCodeDate = Date.distantPast
    @State private var status: String?
    var body: some View {
        NavigationStack {
            Form {
                Section("手机号登录") {
                    TextField("中国大陆手机号", text: $phone).keyboardType(.phonePad).textContentType(.telephoneNumber)
                    TextField("短信验证码", text: $code).keyboardType(.numberPad).textContentType(.oneTimeCode)
                    TimelineView(.periodic(from: .now, by: 1)) { context in
                        let remaining = max(0, Int(nextCodeDate.timeIntervalSince(context.date).rounded(.up)))
                        Button(remaining > 0 ? "\(remaining) 秒后可重新获取" : "获取验证码") { Task { await sendCode() } }
                            .disabled(busy || remaining > 0 || phone.count != 11)
                    }
                    Button("登录") { Task { await login() } }.disabled(busy || phone.count != 11 || code.isEmpty)
                    if busy { ProgressView("正在连接网易云…") }
                    if let status { Text(status).font(.footnote).foregroundStyle(.secondary) }
                }
                Section { Text("验证码只在你点击时发送；登录会话存入 iOS 钥匙串。若账号需要安全验证，请先在网易云官方应用处理。") }
            }
            .navigationTitle("登录网易云").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } } }
        }
    }
    private func sendCode() async {
        busy = true; status = nil
        defer { busy = false }
        do { try await service.sendNeteaseCode(phone: phone); nextCodeDate = Date().addingTimeInterval(60); status = "验证码已发送，请查看短信" }
        catch { status = error.localizedDescription }
    }
    private func login() async {
        busy = true; status = nil
        defer { busy = false }
        do { let account = try await service.loginNetease(phone: phone, code: code); code = ""; completed(account) }
        catch { status = error.localizedDescription }
    }
}

struct QQLoginView: View {
    let service: NativeMusicService
    let completed: (MusicAccount) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var qr: QQLoginQRCode?
    @State private var status = "正在获取二维码…"
    @State private var generation = 0
    @State private var loading = true
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    Text("使用 QQ 或 QQ 音乐扫描登录").font(.headline).multilineTextAlignment(.center)
                    if let qr {
                        Group {
                            if let data = qr.imageData, let image = UIImage(data: data) { Image(uiImage: image).interpolation(.none).resizable().scaledToFit() }
                            else if let url = qr.imageURL {
                                AsyncImage(url: url) { image in image.resizable().interpolation(.none).scaledToFit() } placeholder: { ProgressView("正在加载二维码…") }
                            }
                        }.frame(maxWidth: 260, minHeight: 220).padding(16).background(.white, in: RoundedRectangle(cornerRadius: 16))
                    }
                    if loading { ProgressView() }
                    Text(status).font(.subheadline).multilineTextAlignment(.center)
                    Button("刷新二维码") { generation += 1 }.disabled(loading)
                    Text("同一部手机不方便扫码时，可先将二维码保存或显示在另一台设备上。此入口需要设置中的 QQ 音乐 HTTPS 服务。").font(.footnote).foregroundStyle(.secondary)
                }.frame(maxWidth: .infinity).padding(24)
            }
            .navigationTitle("登录 QQ 音乐").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } } }
            .task(id: generation) { await runLogin() }
        }
    }
    private func runLogin() async {
        if let old = qr { await service.cancelQQLoginQRCode(old.id) }
        qr = nil; loading = true; status = "正在获取二维码…"
        var activeID: String?
        defer {
            loading = false
            if let activeID { Task { await service.cancelQQLoginQRCode(activeID) } }
        }
        do {
            let code = try await service.createQQLoginQRCode()
            try Task.checkCancellation()
            activeID = code.id; qr = code; loading = false; status = "请扫描二维码并在官方应用确认"
            while Date() < code.expiresAt {
                try await Task.sleep(for: .seconds(2))
                let result = try await service.pollQQLoginQRCode(code.id)
                try Task.checkCancellation()
                switch result {
                case .waiting: status = "等待扫码…"
                case .scanned: status = "已扫码，请在官方应用确认"
                case .expired: status = "二维码已过期，请刷新"; return
                case .authorized(let account): activeID = nil; completed(account); return
                }
            }
            status = "二维码已过期，请刷新"
        } catch { if !Task.isCancelled { status = error.localizedDescription } }
    }
}
