import Combine
import Foundation

// native-ios/Sources/OnlineSourceModel.swift
@MainActor
final class OnlineSourceModel: ObservableObject {
    let source: MusicSource
    let service: NativeMusicService
    @Published var query = ""
    @Published private(set) var results: [MusicTrack] = []
    @Published private(set) var collections: [MusicCollection] = []
    @Published private(set) var account: MusicAccount?
    @Published private(set) var searching = false
    @Published private(set) var refreshing = false
    @Published var error: String?
    private var searchTask: Task<Void, Never>?
    private var searchGeneration = 0
    private var accountGeneration = 0

    init(source: MusicSource, service: NativeMusicService) { self.source = source; self.service = service }

    func search() {
        searchTask?.cancel()
        searchGeneration += 1
        let generation = searchGeneration
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !term.isEmpty else { results = []; searching = false; return }
        searching = true; error = nil
        searchTask = Task { [weak self] in
            guard let self else { return }
            do {
                let tracks = try await service.search(source: source, query: term)
                try Task.checkCancellation()
                guard generation == searchGeneration else { return }
                results = tracks; searching = false
                if tracks.isEmpty { error = "没有找到相关歌曲" }
            } catch {
                guard generation == searchGeneration, !Task.isCancelled else { return }
                self.error = error.localizedDescription; searching = false
            }
        }
    }

    func refreshAccount(silent: Bool = false, includeCollections: Bool = false) async {
        guard !refreshing else { return }
        refreshing = true
        let version = accountGeneration
        defer { refreshing = false }
        do {
            let value = try await service.account(source: source)
            try Task.checkCancellation()
            guard version == accountGeneration else { return }
            account = value
            if includeCollections, value != nil {
                let rows = try await service.collections(source: source)
                try Task.checkCancellation()
                guard version == accountGeneration else { return }
                collections = rows
            } else if value == nil { collections = [] }
        } catch { if !silent, version == accountGeneration, !Task.isCancelled { self.error = error.localizedDescription } }
    }

    func loggedIn(_ value: MusicAccount) {
        accountGeneration += 1; account = value; error = nil
    }

    func logout() async {
        accountGeneration += 1
        do { try await service.logout(source: source); account = nil; collections = [] }
        catch { self.error = error.localizedDescription }
    }

    func invalidateAccount() {
        accountGeneration += 1
        account = nil; collections = []; error = nil; refreshing = false
    }
}
