import Foundation
import zlib

// native-ios/Sources/Services/NativeInflate.swift
// Accept gzip/zlib wrappers and cap expanded provider payloads to avoid unbounded allocations.
enum NativeInflate {
    static func decompress(_ data: Data, limit: Int = 8 * 1024 * 1024) throws -> Data {
        var stream = z_stream()
        guard inflateInit2_(&stream, 15 + 32, ZLIB_VERSION, Int32(MemoryLayout<z_stream>.size)) == Z_OK else { throw NativeMusicError.message("初始化音乐数据解压失败") }
        defer { inflateEnd(&stream) }
        return try data.withUnsafeBytes { source in
            stream.next_in = UnsafeMutablePointer<Bytef>(mutating: source.bindMemory(to: Bytef.self).baseAddress)
            stream.avail_in = uInt(data.count)
            var result = Data()
            var buffer = [UInt8](repeating: 0, count: 32 * 1024)
            var status: Int32 = Z_OK
            repeat {
                let produced = buffer.withUnsafeMutableBytes { destination -> Int in
                    stream.next_out = destination.bindMemory(to: Bytef.self).baseAddress
                    stream.avail_out = uInt(destination.count)
                    status = inflate(&stream, Z_NO_FLUSH)
                    return destination.count - Int(stream.avail_out)
                }
                guard status == Z_OK || status == Z_STREAM_END, result.count + produced <= limit else { throw NativeMusicError.message("音乐服务压缩数据校验失败或内容过大") }
                result.append(contentsOf: buffer.prefix(produced))
                if produced == 0 && status != Z_STREAM_END { throw NativeMusicError.message("音乐服务压缩数据不完整") }
            } while status != Z_STREAM_END
            return result
        }
    }
}
