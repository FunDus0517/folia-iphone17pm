import Foundation

// native-ios/Sources/Services/NeteaseNativeProvider.swift
// Normalizes the verified nativeNetease routes into the shared Swift models.
actor NeteaseNativeProvider {
    private let transport: NeteaseNativeTransport
    init(http: any NativeHTTPTransport, vault: any NativeSessionVault) { transport = NeteaseNativeTransport(http: http, vault: vault) }

    func search(_ query: String) async throws -> [MusicTrack] {
        let body = try await transport.request("/api/cloudsearch/pc", data: ["s": .string(query), "type": .number(1), "limit": .number(50), "offset": .number(0), "total": .bool(true)])
        try Self.requireSuccess(body)
        return body["result"]["songs"].array.compactMap(Self.track)
    }

    func sendCode(phone: String) async throws {
        try Self.validatePhone(phone)
        let body = try await transport.request("/api/sms/captcha/sent", data: ["ctcode": .string("86"), "secrete": .string("music_middleuser_pclogin"), "cellphone": .string(phone)], encryption: .weapi)
        try Self.requireSuccess(body)
    }

    func login(phone: String, code: String) async throws -> MusicAccount {
        try Self.validatePhone(phone)
        guard (4...8).contains(code.count), code.allSatisfy(\.isNumber) else { throw NativeMusicError.message("请填写短信中的数字验证码") }
        let body = try await transport.request("/api/w/login/cellphone", data: ["type": .string("1"), "https": .string("true"), "phone": .string(phone),
            "countrycode": .string("86"), "captcha": .string(code), "remember": .string("true"), "secureCaptcha": .string("")], encryption: .weapi)
        try Self.requireSuccess(body)
        guard try await transport.hasAccount() else { throw NativeMusicError.message("网易云未返回有效登录会话，请重新获取验证码") }
        if let account = Self.accountFrom(body["profile"]) { return account }
        guard let account = try await account() else { throw NativeMusicError.message("登录已完成，但读取网易云账号信息失败，请刷新账号") }
        return account
    }

    func account() async throws -> MusicAccount? {
        guard try await transport.hasAccount() else { return nil }
        let body = try await transport.request("/api/w/nuser/account/get", encryption: .weapi)
        if [301, 302].contains(body["code"].int) { try await transport.clearSession(); return nil }
        try Self.requireSuccess(body)
        return Self.accountFrom(body["profile"])
    }

    func collections() async throws -> [MusicCollection] {
        guard let user = try await account() else { throw NativeMusicError.message("请先登录网易云，再读取个人歌单") }
        var result: [MusicCollection] = [], offset = 0
        repeat {
            let body = try await transport.request("/api/user/playlist", data: ["uid": .string(user.id), "limit": .number(200), "offset": .number(Double(offset)), "includeVideo": .bool(true)], encryption: .weapi)
            try Self.requireSuccess(body)
            let page = body["playlist"].array
            result += page.compactMap(Self.collection)
            offset += page.count
            if page.isEmpty || !body["more"].flag { return result }
        } while offset < 5000
        throw NativeMusicError.message("网易云歌单数量过多，请在官方应用整理后重试")
    }

    func tracks(in collection: MusicCollection) async throws -> [MusicTrack] {
        try Self.validateID(collection.id)
        let body = try await transport.request("/api/v6/playlist/detail", data: ["id": .string(collection.id), "n": .number(100000), "s": .number(8)])
        try Self.requireSuccess(body)
        let playlist = body["playlist"]
        guard !playlist.isNull else { throw NativeMusicError.message("网易云没有返回这个歌单，可能需要登录或歌单已设为私密") }
        let initial = playlist["tracks"].array.compactMap(Self.track)
        let ids = playlist["trackIds"].array.map { $0["id"].text }.filter { !$0.isEmpty }
        if ids.isEmpty { return initial }
        var byID = Dictionary(initial.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
        let missing = ids.filter { byID[$0] == nil }
        for offset in stride(from: 0, to: missing.count, by: 500) {
            try Task.checkCancellation()
            let batch = Array(missing[offset..<min(offset + 500, missing.count)])
            let value = NativeJSON.array(batch.map { .object(["id": .number(Double($0) ?? 0)]) })
            let encoded = String(decoding: try value.encoded(), as: UTF8.self)
            let detail = try await transport.request("/api/v3/song/detail", data: ["c": .string(encoded)], encryption: .weapi)
            try Self.requireSuccess(detail)
            for item in detail["songs"].array.compactMap(Self.track) { byID[item.id] = item }
        }
        return ids.compactMap { byID[$0] }
    }

    func resolve(_ track: MusicTrack) async throws -> ResolvedTrack {
        let url = try await playbackURL(track)
        let lyric: String
        do { lyric = try await lyrics(for: track) }
        catch is CancellationError { throw CancellationError() }
        catch { lyric = "" }
        try Task.checkCancellation()
        return ResolvedTrack(url: url, lyricText: lyric)
    }

    func playbackURL(_ track: MusicTrack) async throws -> URL {
        try Self.validateID(track.id)
        let body = try await transport.request("/api/song/enhance/player/url/v1", data: ["ids": .string("[\(track.id)]"), "level": .string("standard"), "encodeType": .string("flac")], encryption: .xeapi)
        try Self.requireSuccess(body)
        let entry = body["data"].array.first { $0["id"].text == track.id } ?? body["data"].array.first ?? .null
        guard let url = NativeURLRules.https(entry["url"].text) else {
            throw NativeMusicError.message("网易云没有提供这首歌的可播放地址。请检查登录状态、会员权限或所在地区；可在官方应用确认")
        }
        return url
    }

    func lyrics(for track: MusicTrack) async throws -> String {
        try Self.validateID(track.id)
        let body = try await transport.request("/api/song/lyric", data: ["id": .string(track.id), "tv": .number(-1), "lv": .number(-1), "rv": .number(-1), "kv": .number(-1), "_nmclfl": .number(1)])
        try Self.requireSuccess(body)
        return body["lrc"]["lyric"].text
    }

    func logout() async throws {
        // Invalidate first: a slow, older SMS-login response must never recreate a logged-out account.
        try await transport.clearSession()
    }

    static func track(_ raw: NativeJSON) -> MusicTrack? {
        let id = raw["id"].text
        guard !id.isEmpty else { return nil }
        let album = raw["al"].isNull ? raw["album"] : raw["al"]
        let artists = raw["ar"].isNull ? raw["artists"] : raw["ar"]
        return MusicTrack(id: id, title: raw["name"].text.isEmpty ? "未命名歌曲" : raw["name"].text,
            artist: artists.array.map { $0["name"].text }.filter { !$0.isEmpty }.joined(separator: " / "), album: album["name"].text,
            duration: max(0, (raw["dt"].isNull ? raw["duration"].double : raw["dt"].double) / 1000), source: .netease,
            artworkURL: NativeURLRules.https(album["picUrl"].text))
    }
    static func collection(_ raw: NativeJSON) -> MusicCollection? {
        guard !raw["id"].text.isEmpty else { return nil }
        return MusicCollection(id: raw["id"].text, title: raw["name"].text, source: .netease,
                               artworkURL: NativeURLRules.https(raw["coverImgUrl"].text), trackCount: max(0, raw["trackCount"].int))
    }
    private static func accountFrom(_ raw: NativeJSON) -> MusicAccount? {
        guard !raw["userId"].text.isEmpty else { return nil }
        return MusicAccount(id: raw["userId"].text, nickname: raw["nickname"].text.isEmpty ? "网易云用户" : raw["nickname"].text, avatarURL: NativeURLRules.https(raw["avatarUrl"].text))
    }
    private static func validatePhone(_ phone: String) throws {
        guard (6...15).contains(phone.utf8.count), phone.utf8.allSatisfy({ (48...57).contains($0) }) else { throw NativeMusicError.message("请填写正确的手机号，当前短信登录使用中国区号 +86") }
    }
    private static func validateID(_ id: String) throws {
        guard !id.isEmpty, id.utf8.allSatisfy({ (48...57).contains($0) }) else { throw NativeMusicError.message("网易云歌曲或歌单编号无效") }
    }
    private static func requireSuccess(_ body: NativeJSON) throws {
        let code = body["code"].int
        guard code == 200 else {
            if [301, 302].contains(code) { throw NativeMusicError.message("网易云登录已过期，请重新登录") }
            if [400, 501, 503].contains(code) { throw NativeMusicError.message("网易云拒绝了请求，请检查手机号、验证码或歌曲权限（\(code)）") }
            if code == 405 || code == 429 { throw NativeMusicError.message("网易云请求过于频繁，请稍后重试，不要连续获取验证码") }
            throw NativeMusicError.message("网易云暂未完成请求（\(code)），请稍后重试或在官方应用确认账号状态")
        }
    }
}
