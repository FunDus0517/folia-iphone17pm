import SwiftUI
import UniformTypeIdentifiers

// native-ios/Sources/FoliaLocalLibrary.swift
// 原 Folia 封面墙在手机上采用两列；宽屏增加列数，不把桌面侧栏挤成竖排文字。
struct FoliaLocalLibrary: View {
    @ObservedObject var model: AppModel
    @State private var query = ""
    @State private var showImporter = false
    @State private var deleting: MusicTrack?
    @AppStorage("foliaNativeLibraryList") private var listMode = false
    private var tracks: [MusicTrack] {
        query.isEmpty ? model.localTracks : model.localTracks.filter { $0.title.localizedCaseInsensitiveContains(query) || $0.artist.localizedCaseInsensitiveContains(query) }
    }
    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("本地曲库").font(.title2.weight(.semibold))
                            Text("\(model.localTracks.count) 首音乐 · 保存在这台设备").font(.caption).foregroundStyle(.white.opacity(0.5))
                        }
                        Spacer()
                        FoliaIconButton(title: listMode ? "封面墙" : "列表", symbol: listMode ? "square.grid.2x2" : "list.bullet") { listMode.toggle() }.accessibilityIdentifier("libraryLayoutToggle")
                        FoliaIconButton(title: "导入音乐", symbol: "plus") { showImporter = true }.disabled(model.importing).accessibilityIdentifier("importMusic")
                    }
                    HStack(spacing: 10) {
                        Image(systemName: "magnifyingglass").foregroundStyle(.white.opacity(0.5))
                        TextField("搜索本地歌曲或歌手", text: $query).submitLabel(.search).accessibilityIdentifier("localQuery")
                        if !query.isEmpty { Button { query = "" } label: { Image(systemName: "xmark.circle.fill").frame(minWidth: 44, minHeight: 44) }.accessibilityLabel("清空搜索") }
                    }.padding(14).background(.white.opacity(0.065), in: RoundedRectangle(cornerRadius: 16))
                    if model.localTracks.isEmpty { introduction }
                    else if tracks.isEmpty { Text("没有匹配的歌曲").foregroundStyle(.secondary).padding(.vertical, 50) }
                    else if listMode {
                        LazyVStack(spacing: 9) { ForEach(tracks) { track in row(track) } }
                    } else { wall(width: geometry.size.width - 32) }
                    if model.importing { ProgressView("正在复制和读取音乐…").frame(maxWidth: .infinity).padding() }
                }.padding(.horizontal, 16).padding(.bottom, 18)
            }.scrollDismissesKeyboard(.interactively).accessibilityIdentifier("foliaLibraryScroll")
        }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.audio, UTType(filenameExtension: "lrc") ?? .plainText], allowsMultipleSelection: true) { result in
            switch result {
            case .success(let files): Task { await model.importFiles(files) }
            case .failure(let error): model.notice = "文件选择失败：\(error.localizedDescription)"
            }
        }
        .confirmationDialog("从应用曲库移除这首歌？原始文件保留。", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } })) {
            Button("移除歌曲", role: .destructive) { if let track = deleting { Task { await model.remove(track) } }; deleting = nil }
            Button("取消", role: .cancel) { deleting = nil }
        }
    }
    private var introduction: some View {
        VStack(alignment: .leading, spacing: 16) {
            ZStack(alignment: .bottomLeading) {
                TrackArtwork(url: FoliaLayout.defaultArtwork)
                LinearGradient(colors: [.clear, .black.opacity(0.9)], startPoint: .top, endPoint: .bottom)
                VStack(alignment: .leading, spacing: 9) {
                    Text("你的音乐\n你的舞台").font(.system(size: 35, weight: .light, design: .serif)).tracking(2)
                    Text("让喜欢的每一句，都有自己的画面。").font(.caption).foregroundStyle(.white.opacity(0.7))
                }.padding(24)
            }.frame(height: 270).clipShape(RoundedRectangle(cornerRadius: 8))
            Text("从“文件”导入音频与同名 LRC，封面墙和歌词舞台会随你的音乐展开。").font(.subheadline).foregroundStyle(.white.opacity(0.55)).lineSpacing(5)
            Button { showImporter = true } label: { Label("导入你的音乐", systemImage: "square.and.arrow.down").frame(maxWidth: .infinity, minHeight: 48) }
                .buttonStyle(.plain).modifier(FoliaGlass(radius: 16))
        }.accessibilityIdentifier("foliaEmptyLibrary")
    }
    private func row(_ track: MusicTrack) -> some View {
        TrackRow(track: track, loading: model.loadingTrackID == track.id) { model.play(track, among: tracks) }
            .contextMenu { Button("从曲库移除", role: .destructive) { deleting = track } }
    }
    private func wall(width: Double) -> some View {
        let columns = FoliaLayout.columns(for: width)
        let tileWidth = (width - Double(columns - 1) * 8) / Double(columns)
        return HStack(alignment: .top, spacing: 8) {
            ForEach(0..<columns, id: \.self) { column in
                LazyVStack(spacing: 8) {
                    ForEach(Array(tracks.enumerated()).filter { $0.offset % columns == column }, id: \.element.id) { item in
                        FoliaTrackTile(track: item.element, index: item.offset, height: FoliaLayout.tileHeight(for: tileWidth, index: item.offset), loading: model.loadingTrackID == item.element.id) {
                            model.play(item.element, among: tracks)
                        }.contextMenu { Button("从曲库移除", role: .destructive) { deleting = item.element } }
                    }
                }.frame(width: tileWidth)
            }
        }.accessibilityIdentifier("foliaCoverWall")
    }
}
