# Folia 原生 iOS

这是与旧网页壳并行的独立 SwiftUI/AVFoundation 工程。应用界面、音频播放与本地文件处理在 Swift 层执行，不嵌入 WKWebView、Capacitor、HTML、JavaScript 或桌面运行时。原生重写不代表桌面功能已经全部迁移；首版按网易云、本地音乐与 QQ 音乐接入实现，真实账号和手机行为另行验收。

## 结构

- `Sources/`：原生界面、状态、播放、歌词、账号和音乐服务。
- `Tests/`：实际 XCTest 单元测试。
- `UITests/`：实际 iPhone 模拟器 UI 测试。
- `project.yml`：XcodeGen 工程定义，生成三个 target 和共享 scheme。
- `Scripts/build-unsigned.sh`：生成工程、实际编译与测试、真机 arm64 归档及 IPA 封包。
- `Scripts/verify_ipa.py`：独立检查实际测试结果、Mach-O 真机平台、签名、依赖和封包一致性。
- `Generated/`、`FoliaNative.xcodeproj/`、`output/`：生成内容，不是输入源码。

最低 iOS 17，仅 iPhone；界面中文、竖横屏、后台音频。应用显示名称为“Folia 原生”，标识为 `io.github.fundus0517.folia.native`，与旧版并存，不读取/覆盖旧网页容器的数据。

## 构建方式

Windows 上可编辑与静态检查源码，但该环境没有苹果 SDK，不产生可验证的 iOS 编译结果。真正 Swift 编译在 macOS/Xcode 中执行。固定配置为 GitHub `macos-15`、Xcode 26.3、iOS 26.2 SDK 与 iPhone 17 Pro Max / iOS 26.2 模拟器。

开发者在对应 Mac 上执行：

```bash
brew install xcodegen
DEVELOPER_DIR=/Applications/Xcode_26.3.app/Contents/Developer \
  bash native-ios/Scripts/build-unsigned.sh
```

普通安装用户不需要终端：维护者完成 Actions 编译后，从发行版下载 IPA，再用自己的签名工具安装。未签名 IPA 不能直接安装，也不是 App Store/TestFlight 包。

## 同一仓库的独立 Actions

`.github/workflows/ios-native.yml` 仅手动运行，不修改旧 iOS 工作流，也不自动创建发行版。流程没有仓库写入权限。

三种输入方式：

1. `source_url` 和 `source_sha256` 都留空：编译当前提交中的 `native-ios/`。
2. 填写本仓库发行版的源码 ZIP 附件链接及完整 SHA-256：先下载、核对摘要和 ZIP 路径，再在独立临时目录中编译。ZIP 结构应为 `native-ios/project.yml` 等，或带一个额外顶层目录。拒绝越界路径、反斜杠、软链接、重复项、加密项和超限文件。
3. 尚未发布时，将 `FoliaNative-*.zip` 源码 ZIP 上传至同一仓库根目录或 `native-ios-input/`，填写 `source_archive` 路径和摘要，从本次 checkout 的已提交文件验证并编译。此方式不提前创建未测试的安装包发行版；与 `source_url` 二选一。

从 ZIP 编译时，Actions 页面所示的提交只是工作流提交，不应当冒充源码提交。附件中的 `SOURCE-DOWNLOAD.json`、`SOURCE-INFO.json`、`BUILD-INFO.json` 分别记录下载摘要、逐文件源码摘要、工作流提交与最终 IPA 摘要；发布时附上同一份源码 ZIP。

## 严格通过条件

1. `xcodebuild test` 分别实际执行 `FoliaNativeTests` 和 `FoliaNativeUITests`，不以 JSON、Python 或网页测试代替 Swift 编译。
2. 两个 `.xcresult` 必须含 `Info.plist` 与实际 `Data/` 数据；`xcresulttool` 导出的统计必须通过用例数大于零、失败为零，不能全跳过。
3. `xcodebuild archive` 必须成功，目标为 `generic/platform=iOS`，不是模拟器 App。
4. IPA 主程序是 arm64 Mach-O，`LC_BUILD_VERSION.platform` 为 IOS（不是 IOSSIMULATOR）。拒绝签名段、签名目录和预置描述文件。
5. 拒绝 WebKit/JavaScriptCore/Capacitor/Cordova 依赖及 JS/HTML/CSS/WASM 资源；archive 与 IPA 文件清单和 SHA-256 必须逐一一致。
6. 写入 `BUILD-INFO.json`、IPA SHA-256 和完整日志后才显示成功。任何失败停止后续封包；工作流依然保存已有诊断信息。

结果附件包含 IPA、SHA-256、构建/源码记录、编译日志和两个 `.xcresult`。模拟器测试不证明真实账号接口可用，也不证明真机后台、锁屏、蓝牙、文件选择、长时间播放性能已经通过；这些需要签名后的 iPhone 实测。

## 可独立复核

```bash
python3 native-ios/Scripts/verify_ipa.py tests \
  --summary native-ios/output/test-Unit-summary.json \
  --result native-ios/output/NativeUnitTests.xcresult
```

IPA 校验的全部实参由 `build-unsigned.sh` 明确给出。Python 校验器不自行编译 Swift；将模拟文件喂给它只测试校验器分支，不构成真实编译证明。
