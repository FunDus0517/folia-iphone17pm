import SwiftUI

// native-ios/Sources/OnlineMusicView.swift
struct OnlineMusicView: View {
    @ObservedObject var model: AppModel
    @StateObject private var online: OnlineSourceModel
    @State private var showLogin = false

    init(model: AppModel, source: MusicSource) {
        self.model = model
        _online = StateObject(wrappedValue: OnlineSourceModel(source: source, service: model.service))
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    if let account = online.account {
                        HStack { Label(account.nickname, systemImage: "person.crop.circle"); Spacer(); Button("退出登录") { Task { await online.logout() } } }
                    } else { Button("登录\(online.source.title)") { showLogin = true } }
                    if online.source == .qq {
                        Text(model.qqEndpoint.isEmpty ? "尚未配置 QQ 服务。可以搜索；登录、歌单与播放需先在设置中填写 HTTPS 地址。" : "已填写 QQ 服务地址，登录后可检验账号与播放连接。")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    Button("刷新账号与歌单") { Task { await online.refreshAccount(includeCollections: true) } }.disabled(online.refreshing)
                    if online.refreshing { ProgressView("正在连接…") }
                }
                if let error = online.error { Section { Text(error).foregroundStyle(.orange).font(.footnote) } }
                if !online.collections.isEmpty {
                    Section("我的歌单") {
                        ForEach(online.collections) { collection in
                            NavigationLink {
                                CollectionTracksView(model: model, collection: collection)
                            } label: { Label(collection.title, systemImage: "music.note.list") }
                        }
                    }
                }
                Section("搜索结果") {
                    if online.searching { ProgressView("正在搜索…") }
                    ForEach(online.results) { track in
                        TrackRow(track: track, loading: model.loadingTrackID == track.id) { model.play(track, among: online.results) }
                    }
                    if online.results.isEmpty, !online.searching { Text("输入歌名、歌手并点击键盘“搜索”").foregroundStyle(.secondary).font(.footnote) }
                }
            }
            .navigationTitle(online.source.title)
            .searchable(text: $online.query, prompt: "搜索歌曲或歌手")
            .onSubmit(of: .search) { online.search() }
            .task { await online.refreshAccount(silent: true) }
            .onChange(of: model.qqConnectionRevision) { _, _ in
                if online.source == .qq {
                    showLogin = false
                    online.invalidateAccount()
                    Task { await online.refreshAccount(silent: true) }
                }
            }
            .sheet(isPresented: $showLogin) {
                if online.source == .netease {
                    NeteaseLoginView(service: model.service) { online.loggedIn($0); showLogin = false }
                } else { QQLoginView(service: model.service) { online.loggedIn($0); showLogin = false } }
            }
        }
    }
}

private struct CollectionTracksView: View {
    @ObservedObject var model: AppModel
    let collection: MusicCollection
    @State private var tracks: [MusicTrack] = []
    @State private var loading = false
    @State private var error: String?
    var body: some View {
        List {
            if loading { ProgressView("正在加载歌单…") }
            if let error { Text(error).foregroundStyle(.orange); Button("重试") { Task { await load() } } }
            ForEach(tracks) { track in TrackRow(track: track, loading: model.loadingTrackID == track.id) { model.play(track, among: tracks) } }
        }
        .navigationTitle(collection.title).navigationBarTitleDisplayMode(.inline)
        .task(id: collection.id) { await load() }
    }
    private func load() async {
        loading = true; error = nil
        defer { loading = false }
        do {
            let rows = try await model.service.tracks(in: collection)
            try Task.checkCancellation()
            tracks = rows
        } catch { if !Task.isCancelled { self.error = error.localizedDescription } }
    }
}
