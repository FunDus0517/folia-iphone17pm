#!/bin/bash
# native-ios/Scripts/build-unsigned.sh — 真正编译、模拟器测试、归档并验证未签名 IPA。
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
OUTPUT="${NATIVE_OUTPUT_DIR:-$ROOT/output}"
mkdir -p "$OUTPUT"
OUTPUT="$(cd "$OUTPUT" && pwd -P)"
export DEVELOPER_DIR="${DEVELOPER_DIR:-/Applications/Xcode_26.3.app/Contents/Developer}"
export NATIVE_OUTPUT_DIR="$OUTPUT"

if [ "$(uname -s)" != Darwin ]; then
  echo '错误：此步骤必须在装有 Xcode 的 macOS 上执行；没有执行 Swift 编译。' >&2
  exit 2
fi
if [ ! -d "$DEVELOPER_DIR" ]; then
  echo "错误：找不到指定 Xcode：$DEVELOPER_DIR" >&2
  exit 2
fi
for tool in xcodebuild xcrun xcodegen python3 ditto codesign; do
  command -v "$tool" >/dev/null || { echo "错误：缺少工具 $tool" >&2; exit 2; }
done
if [ -e "$OUTPUT/NativeUnitTests.xcresult" ] || [ -e "$OUTPUT/FoliaNative.xcarchive" ]; then
  echo '错误：输出目录含旧构建，请使用新的空输出目录。' >&2
  exit 2
fi

xcodebuild -version | tee "$OUTPUT/xcode-version.txt"
grep -q '^Xcode 26\.3$' "$OUTPUT/xcode-version.txt" || {
  echo '错误：本构建固定使用 Xcode 26.3。' >&2; exit 2;
}
xcrun swift --version | tee "$OUTPUT/swift-version.txt"
xcrun --sdk iphoneos --show-sdk-version | tee "$OUTPUT/ios-sdk.txt"
xcodegen --version | tee "$OUTPUT/xcodegen-version.txt"

# 记录源文件清单；生成工程、派生文件和输出不属于输入源码。
python3 - "$ROOT" "$OUTPUT" <<'PY'
import hashlib, json, os, pathlib, sys
root, output = map(pathlib.Path, sys.argv[1:])
excluded = {"Generated", "output", ".build", "__pycache__"}
files = {}
for path in sorted(root.rglob("*")):
    rel = path.relative_to(root)
    if any(part in excluded or part.endswith(".xcodeproj") for part in rel.parts):
        continue
    if path.is_file():
        if path.is_symlink():
            raise SystemExit("源码包含软链接：" + str(rel))
        files[rel.as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
manifest = json.dumps(files, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
record = {"files": files, "manifestSha256": hashlib.sha256(manifest.encode()).hexdigest(),
          "sourceArchiveSha256": os.environ.get("SOURCE_ARCHIVE_SHA256") or None,
          "workflowCommit": os.environ.get("GITHUB_SHA") or None,
          "sourceMode": os.environ.get("NATIVE_SOURCE_MODE", "checkout-or-local")}
(output / "SOURCE-INFO.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("源码清单已记录：", len(files), "个文件")
PY

xcodegen generate --spec "$ROOT/project.yml" | tee "$OUTPUT/generate.log"
xcodebuild -list -project "$ROOT/FoliaNative.xcodeproj" | tee "$OUTPUT/project-list.txt"
xcrun simctl list devices available --json > "$OUTPUT/simulators.json"
SIM_ID="$(python3 - "$OUTPUT/simulators.json" <<'PY'
import json, sys
data = json.load(open(sys.argv[1], encoding="utf-8"))
for runtime, devices in data["devices"].items():
    if runtime != "com.apple.CoreSimulator.SimRuntime.iOS-26-2":
        continue
    for device in devices:
        if device["name"] == "iPhone 17 Pro Max" and device.get("isAvailable"):
            print(device["udid"])
            raise SystemExit(0)
raise SystemExit("未找到可用的 iPhone 17 Pro Max / iOS 26.2 模拟器")
PY
)"
printf '%s\n' "$SIM_ID" > "$OUTPUT/simulator-udid.txt"
SIM_STATE="$(python3 - "$OUTPUT/simulators.json" "$SIM_ID" <<'PY'
import json, sys
data = json.load(open(sys.argv[1], encoding="utf-8"))
print(next(d["state"] for devices in data["devices"].values() for d in devices if d["udid"] == sys.argv[2]))
PY
)"
if [ "$SIM_STATE" != Booted ]; then xcrun simctl boot "$SIM_ID"; fi
xcrun simctl bootstatus "$SIM_ID" -b

# 两次独立结果包分别证明单元测试和原生 UI 测试真实执行；零用例直接失败。
for kind in Unit UI; do
  case "$kind" in Unit) target=FoliaNativeTests ;; UI) target=FoliaNativeUITests ;; esac
  result="$OUTPUT/Native${kind}Tests.xcresult"
  xcodebuild test -project "$ROOT/FoliaNative.xcodeproj" -scheme FoliaNative \
    -configuration Debug -destination "platform=iOS Simulator,id=$SIM_ID" \
    -only-testing:"$target" -parallel-testing-enabled NO \
    -maximum-concurrent-test-simulator-destinations 1 \
    -derivedDataPath "$OUTPUT/DerivedData-test" -resultBundlePath "$result" \
    CODE_SIGNING_ALLOWED=NO 2>&1 | tee "$OUTPUT/test-${kind}.log"
  test -s "$result/Info.plist"
  xcrun xcresulttool get test-results summary --path "$result" > "$OUTPUT/test-${kind}-summary.json"
  python3 "$ROOT/Scripts/verify_ipa.py" tests \
    --summary "$OUTPUT/test-${kind}-summary.json" --result "$result"
done

xcodebuild archive -project "$ROOT/FoliaNative.xcodeproj" -scheme FoliaNative \
  -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' \
  -archivePath "$OUTPUT/FoliaNative.xcarchive" -derivedDataPath "$OUTPUT/DerivedData-device" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" \
  SKIP_INSTALL=NO ARCHS=arm64 \
  2>&1 | tee "$OUTPUT/archive.log"

APP="$OUTPUT/FoliaNative.xcarchive/Products/Applications/FoliaNative.app"
test -d "$APP"
plutil -lint "$APP/Info.plist"
EXECUTABLE="$(/usr/libexec/PlistBuddy -c 'Print CFBundleExecutable' "$APP/Info.plist")"
xcrun lipo -archs "$APP/$EXECUTABLE" | tee "$OUTPUT/architectures.txt"
test "$(cat "$OUTPUT/architectures.txt")" = arm64
xcrun vtool -show-build "$APP/$EXECUTABLE" | tee "$OUTPUT/macho-build.txt"
otool -L "$APP/$EXECUTABLE" | tee "$OUTPUT/framework-dependencies.txt"
if codesign -dv "$APP" > "$OUTPUT/signature.txt" 2>&1; then
  echo '错误：预期未签名，但发现签名。' >&2; exit 1
fi
grep -q 'not signed at all' "$OUTPUT/signature.txt"
test ! -e "$APP/embedded.mobileprovision"
test ! -d "$APP/_CodeSignature"

mkdir -p "$OUTPUT/ipa/Payload"
ditto "$APP" "$OUTPUT/ipa/Payload/FoliaNative.app"
(cd "$OUTPUT/ipa" && /usr/bin/zip -qry "$OUTPUT/FoliaNative-0.2.0-unsigned.ipa" Payload)
python3 "$ROOT/Scripts/verify_ipa.py" ipa \
  --ipa "$OUTPUT/FoliaNative-0.2.0-unsigned.ipa" --archive-app "$APP" \
  --source-info "$OUTPUT/SOURCE-INFO.json" --output "$OUTPUT/BUILD-INFO.json" \
  --unit-summary "$OUTPUT/test-Unit-summary.json" --unit-result "$OUTPUT/NativeUnitTests.xcresult" \
  --ui-summary "$OUTPUT/test-UI-summary.json" --ui-result "$OUTPUT/NativeUITests.xcresult"
echo 'NATIVE_BUILD_OK: Swift 编译、原生单测、模拟器 UI、真机 arm64 未签名包校验均已通过。'
