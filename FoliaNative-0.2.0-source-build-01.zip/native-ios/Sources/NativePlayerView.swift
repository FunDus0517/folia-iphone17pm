import SwiftUI

// native-ios/Sources/NativePlayerView.swift
struct NativeMiniPlayer: View {
    @ObservedObject var playback: NativePlayback
    let open: () -> Void

    var body: some View {
        if let track = playback.track {
            HStack(spacing: 8) {
                Button(action: open) {
                    HStack(spacing: 12) {
                        TrackArtwork(url: track.artworkURL)
                            .frame(width: 48, height: 48)
                            .clipShape(RoundedRectangle(cornerRadius: 15))
                        VStack(alignment: .leading, spacing: 5) {
                            Text(track.title).font(.subheadline.weight(.semibold)).lineLimit(1)
                            Text(currentLine ?? track.artist)
                                .font(.caption).foregroundStyle(.white.opacity(0.62)).lineLimit(1)
                                .accessibilityIdentifier("miniLyric")
                        }
                        Spacer(minLength: 0)
                    }.contentShape(Rectangle())
                }
                .buttonStyle(.plain).accessibilityLabel("打开正在播放")
                .accessibilityValue(currentLine ?? track.artist).accessibilityIdentifier("openPlayer")
                Button { playback.toggle() } label: {
                    Image(systemName: playback.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 19, weight: .semibold))
                        .frame(width: 48, height: 48)
                        .background(.white.opacity(0.11), in: Circle())
                }
                .buttonStyle(.plain).accessibilityLabel(playback.isPlaying ? "暂停" : "播放")
                .accessibilityIdentifier("miniToggle")
            }
            .foregroundStyle(.white).padding(10)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 26))
            .overlay { RoundedRectangle(cornerRadius: 26).stroke(.white.opacity(0.12), lineWidth: 0.8) }
            .overlay(alignment: .bottom) {
                FoliaMiniProgress(clock: playback.clock).frame(height: 2).padding(.horizontal, 26)
            }
            .shadow(color: .black.opacity(0.25), radius: 20, y: 8)
            .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 8)
            .accessibilityElement(children: .contain)
        }
    }

    private var currentLine: String? {
        playback.lyrics.first(where: { $0.id == playback.activeLyricID })?.text
    }
}

struct NativePlayerView: View {
    @ObservedObject var model: AppModel
    @ObservedObject var playback: NativePlayback
    @Environment(\.verticalSizeClass) private var verticalSizeClass
    @AppStorage("foliaNativeLyricStyle") private var styleRaw = "immersive"
    @State private var showQueue = false

    private var compact: Bool { verticalSizeClass == .compact }
    private var lyricStyle: FoliaLyricStyle { FoliaLyricStyle(rawValue: styleRaw) ?? .immersive }

    var body: some View {
        ZStack {
            FoliaBackdrop(url: playback.track?.artworkURL, strength: 1)
            VStack(spacing: compact ? 4 : 14) {
                header
                if let track = playback.track {
                    FoliaLyricsStage(lines: playback.lyrics, activeID: playback.activeLyricID,
                                     style: lyricStyle, compact: compact,
                                     seek: { playback.seek(to: $0) })
                    if let error = playback.error {
                        HStack(spacing: 12) {
                            Text(error).font(.caption).lineLimit(2).accessibilityIdentifier("playbackError")
                            Button("重试") { model.play(track, among: model.queuedTracks) }
                                .font(.caption.weight(.semibold)).frame(minWidth: 44, minHeight: 44)
                                .accessibilityIdentifier("retryPlayback")
                        }
                        .foregroundStyle(Color(red: 1, green: 0.75, blue: 0.55)).padding(.horizontal, 24)
                    }
                    FoliaPlayerControls(track: track, playback: playback, compact: compact,
                                        previous: { model.previous() }, next: { model.next() },
                                        queue: { showQueue = true })
                        .padding(.horizontal, compact ? 32 : 18)
                        .padding(.bottom, compact ? 4 : 10)
                } else {
                    Spacer()
                    ContentUnavailableView("还没有播放歌曲", systemImage: "music.note",
                                           description: Text("从曲库选择一首，进入歌词舞台。"))
                    Spacer()
                }
            }
        }
        .foregroundStyle(Color(red: 0.98, green: 0.96, blue: 0.90))
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showQueue) {
            FoliaQueueView(model: model, playback: playback)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Button { model.showPlayer = false } label: {
                Image(systemName: "chevron.down").font(.system(size: 17, weight: .medium))
                    .frame(width: 46, height: 46).background(.white.opacity(0.07), in: Circle())
            }.buttonStyle(.plain).accessibilityLabel("收起播放页").accessibilityIdentifier("closePlayer")
            Spacer(minLength: 0)
            VStack(spacing: 4) {
                Text("歌词舞台").font(.caption.weight(.semibold)).tracking(3)
                Text(playback.track?.source.title ?? "Folia")
                    .font(.system(size: 10)).foregroundStyle(.white.opacity(0.45))
            }.accessibilityElement(children: .combine)
            Spacer(minLength: 0)
            Button {
                styleRaw = lyricStyle == .immersive ? "lines" : "immersive"
            } label: {
                VStack(spacing: 3) {
                    Image(systemName: lyricStyle == .immersive ? "text.alignleft" : "sparkles")
                        .font(.system(size: 15, weight: .medium))
                    Text(lyricStyle.title).font(.system(size: 9))
                }.frame(width: 46, height: 46).background(.white.opacity(0.07), in: Circle())
            }
            .buttonStyle(.plain).accessibilityLabel(lyricStyle == .immersive ? "切换为逐行歌词" : "切换为沉浸歌词")
            .accessibilityValue(lyricStyle.title).accessibilityIdentifier("lyricStyleToggle")
        }
        .padding(.horizontal, compact ? 22 : 20).padding(.top, compact ? 0 : 4)
    }
}
