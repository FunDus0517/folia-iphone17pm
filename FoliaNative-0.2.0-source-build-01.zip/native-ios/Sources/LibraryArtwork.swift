import Foundation
import ImageIO
import UniformTypeIdentifiers

// native-ios/Sources/LibraryArtwork.swift
// Embedded artwork is optional owned data. Manifest file URLs are never followed or copied from outside the library.
enum LibraryArtwork {
    static let maximumInputBytes = 8 * 1024 * 1024
    static let maximumPixelSize = 600

    static func thumbnail(_ bytes: Data) -> Data? {
        guard !bytes.isEmpty, bytes.count <= maximumInputBytes,
              let source = CGImageSourceCreateWithData(bytes as CFData, [kCGImageSourceShouldCache: false] as CFDictionary),
              let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any],
              let width = properties[kCGImagePropertyPixelWidth] as? NSNumber,
              let height = properties[kCGImagePropertyPixelHeight] as? NSNumber,
              width.doubleValue > 0, height.doubleValue > 0,
              width.doubleValue * height.doubleValue <= 64_000_000 else { return nil }
        let options: [CFString: Any] = [kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true, kCGImageSourceThumbnailMaxPixelSize: maximumPixelSize,
            kCGImageSourceShouldCacheImmediately: true]
        guard let image = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary),
              image.width <= maximumPixelSize, image.height <= maximumPixelSize else { return nil }
        let result = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(result, UTType.jpeg.identifier as CFString, 1, nil) else { return nil }
        CGImageDestinationAddImage(destination, image, [kCGImageDestinationLossyCompressionQuality: 0.85] as CFDictionary)
        guard CGImageDestinationFinalize(destination), result.length <= maximumInputBytes else { return nil }
        return result as Data
    }

    static func ownedCoverURL(id: String, root: URL, createDirectory: Bool = false) throws -> URL {
        guard id.utf8.count == 64, id.utf8.allSatisfy({ (48...57).contains($0) || (97...102).contains($0) }) else {
            throw NativeMusicError.message("本地封面编号无效")
        }
        let canonicalRoot = root.standardizedFileURL.resolvingSymlinksInPath()
        let covers = canonicalRoot.appendingPathComponent("Covers", isDirectory: true).standardizedFileURL
        guard covers.resolvingSymlinksInPath().path == covers.path,
              !isSymbolicLink(covers) else { throw NativeMusicError.message("本地封面目录包含外部链接") }
        if createDirectory { try FileManager.default.createDirectory(at: covers, withIntermediateDirectories: true) }
        let candidate = covers.appendingPathComponent(id + ".jpg").standardizedFileURL
        guard candidate.path.hasPrefix(covers.path + "/"), candidate.resolvingSymlinksInPath().path == candidate.path,
              !isSymbolicLink(candidate) else { throw NativeMusicError.message("本地封面路径包含外部链接") }
        return candidate
    }

    /// Rebase only by the trusted hash, not by an old container path, filename or a manifest URL's contents.
    static func relocated(_ track: MusicTrack, root: URL) -> MusicTrack {
        guard track.source == .local, track.artworkURL?.isFileURL == true else { return track }
        var result = track
        result.artworkURL = nil
        guard let candidate = try? ownedCoverURL(id: track.id, root: root),
              let values = try? candidate.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey]),
              values.isRegularFile == true, let count = values.fileSize, count > 0, count <= maximumInputBytes else { return result }
        result.artworkURL = candidate
        return result
    }

    static func save(_ jpeg: Data, id: String, root: URL) -> URL? {
        guard !jpeg.isEmpty, jpeg.count <= maximumInputBytes,
              let destination = try? ownedCoverURL(id: id, root: root, createDirectory: true) else { return nil }
        do { try jpeg.write(to: destination, options: .atomic); return destination }
        catch { return nil } // Disk/metadata artwork failures do not invalidate an otherwise playable audio import.
    }

    static func remove(id: String, root: URL) {
        guard let url = try? ownedCoverURL(id: id, root: root) else { return }
        try? FileManager.default.removeItem(at: url)
    }

    private static func isSymbolicLink(_ url: URL) -> Bool {
        (try? FileManager.default.attributesOfItem(atPath: url.path)[.type] as? FileAttributeType) == .typeSymbolicLink
    }
}
