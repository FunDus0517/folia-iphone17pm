import Foundation

// native-ios/Sources/Services/NativeMusicService.swift
// Omni-style boundary: views receive shared models, never provider JSON, cookies, cryptographic keys or transport.
actor NativeMusicService {
    private let netease: NeteaseNativeProvider
    private let qq: QQNativeProvider

    init(http: any NativeHTTPTransport = URLSessionNativeTransport(), vault: any NativeSessionVault = KeychainNativeSessionVault()) {
        netease = NeteaseNativeProvider(http: http, vault: vault)
        qq = QQNativeProvider(http: http, vault: vault)
    }

    func setQQEndpoint(_ url: URL?) async { await qq.setEndpoint(url) }
    func search(source: MusicSource, query: String) async throws -> [MusicTrack] {
        let query = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return [] }
        switch source {
        case .netease: return try await netease.search(String(query.prefix(100)))
        case .qq: return try await qq.search(query)
        case .local: throw NativeMusicError.message("本地音乐请在曲库中搜索或导入")
        }
    }
    func resolve(_ track: MusicTrack) async throws -> ResolvedTrack {
        switch track.source {
        case .netease: return try await netease.resolve(track)
        case .qq: return try await qq.resolve(track)
        case .local: throw NativeMusicError.message("本地歌曲应从应用曲库读取，不经过在线音乐服务")
        }
    }
    func sendNeteaseCode(phone: String) async throws { try await netease.sendCode(phone: phone.trimmingCharacters(in: .whitespacesAndNewlines)) }
    func loginNetease(phone: String, code: String) async throws -> MusicAccount {
        try await netease.login(phone: phone.trimmingCharacters(in: .whitespacesAndNewlines), code: code.trimmingCharacters(in: .whitespacesAndNewlines))
    }
    func account(source: MusicSource) async throws -> MusicAccount? {
        switch source { case .local: return nil; case .netease: return try await netease.account(); case .qq: return try await qq.account() }
    }
    func collections(source: MusicSource) async throws -> [MusicCollection] {
        switch source { case .local: return []; case .netease: return try await netease.collections(); case .qq: return try await qq.collections() }
    }
    func tracks(in collection: MusicCollection) async throws -> [MusicTrack] {
        switch collection.source { case .local: return []; case .netease: return try await netease.tracks(in: collection); case .qq: return try await qq.tracks(in: collection) }
    }
    func logout(source: MusicSource) async throws {
        switch source { case .local: return; case .netease: try await netease.logout(); case .qq: try await qq.logout() }
    }
    func createQQLoginQRCode() async throws -> QQLoginQRCode { try await qq.createQRCode() }
    func pollQQLoginQRCode(_ id: String) async throws -> QQLoginPollResult { try await qq.pollQRCode(id) }
    func cancelQQLoginQRCode(_ id: String) async { await qq.cancelQRCode(id) }
}
