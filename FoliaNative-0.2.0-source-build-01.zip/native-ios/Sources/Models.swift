import Foundation

// native-ios/Sources/Models.swift
enum MusicSource: String, Codable, CaseIterable, Identifiable, Sendable {
    case local, netease, qq
    var id: String { rawValue }
    var title: String {
        switch self { case .local: return "本地"; case .netease: return "网易云"; case .qq: return "QQ音乐" }
    }
}

struct MusicTrack: Identifiable, Codable, Hashable, Sendable {
    let id: String
    var title: String
    var artist: String
    var album: String = ""
    var duration: Double = 0
    var source: MusicSource
    var localFile: String? = nil
    var artworkURL: URL? = nil
    var lyricText: String? = nil
    var originalFilename: String? = nil
}

struct LyricLine: Identifiable, Codable, Hashable, Sendable {
    let id: Int
    let time: Double
    let text: String
    var translation: String? = nil
}

struct MusicCollection: Identifiable, Codable, Hashable, Sendable {
    let id: String
    var title: String
    var source: MusicSource
    var artworkURL: URL? = nil
    var trackCount: Int = 0
}

struct MusicAccount: Codable, Sendable {
    var id: String
    var nickname: String
    var avatarURL: URL? = nil
}

struct ResolvedTrack: Sendable {
    var url: URL
    var lyricText: String
}

struct ImportResult: Sendable {
    var imported: [MusicTrack]
    var duplicates: Int
    var failures: [String]
}

enum NativeMusicError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let text) = self { return text }; return nil }
}
