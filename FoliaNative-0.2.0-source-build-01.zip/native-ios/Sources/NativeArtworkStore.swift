import Foundation
import ImageIO
import UniformTypeIdentifiers

// native-ios/Sources/NativeArtworkStore.swift
actor NativeArtworkStore {
    static let shared = NativeArtworkStore()
    private let cache = NSCache<NSURL, NSData>()
    private var pending: [URL: Task<Data?, Never>] = [:]
    private var activeRequests = 0
    private var waiters: [CheckedContinuation<Void, Never>] = []
    private nonisolated static let session: URLSession = {
        let configuration = URLSessionConfiguration.default
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.timeoutIntervalForRequest = 15
        configuration.timeoutIntervalForResource = 30
        return URLSession(configuration: configuration)
    }()

    init() { cache.totalCostLimit = 20 * 1024 * 1024; cache.countLimit = 100 }

    /// 同一封面合并请求；后台降采样再交给界面，避免直接解码超大专辑图。
    func imageData(for source: URL) async -> Data? {
        let url = Self.sizedURL(source)
        if let cached = cache.object(forKey: url as NSURL) { return cached as Data }
        if let task = pending[url] { return await task.value }
        let task = Task { () -> Data? in
            await acquire()
            let data = await Self.fetch(url)
            release()
            return data
        }
        pending[url] = task
        let result = await task.value
        pending[url] = nil
        if let result { cache.setObject(result as NSData, forKey: url as NSURL, cost: result.count) }
        return result
    }

    private func acquire() async {
        if activeRequests < 4 { activeRequests += 1; return }
        await withCheckedContinuation { waiters.append($0) }
    }

    private func release() {
        if waiters.isEmpty { activeRequests -= 1 } else { waiters.removeFirst().resume() }
    }

    private nonisolated static func fetch(_ url: URL) async -> Data? {
        do {
            let limit = 8 * 1024 * 1024
            if url.isFileURL {
                let values = try url.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
                guard values.isRegularFile == true, let count = values.fileSize, count > 0, count <= limit else { return nil }
                return thumbnail(try Data(contentsOf: url, options: .mappedIfSafe))
            }
            guard url.scheme?.lowercased() == "https" else { return nil }
            let (stream, response) = try await session.bytes(for: URLRequest(url: url))
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode),
                  response.url?.scheme == "https", response.expectedContentLength <= Int64(limit) else { return nil }
            var bytes = Data()
            bytes.reserveCapacity(Int(max(0, min(response.expectedContentLength, Int64(limit)))))
            for try await byte in stream {
                guard bytes.count < limit else { return nil }
                bytes.append(byte)
            }
            return thumbnail(bytes)
        } catch { return nil }
    }

    private nonisolated static func sizedURL(_ url: URL) -> URL {
        guard url.host?.hasSuffix(".music.126.net") == true, var parts = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return url }
        var query = (parts.queryItems ?? []).filter { $0.name != "param" }
        query.append(URLQueryItem(name: "param", value: "400y400"))
        parts.queryItems = query
        return parts.url ?? url
    }

    private nonisolated static func thumbnail(_ bytes: Data) -> Data? {
        guard let source = CGImageSourceCreateWithData(bytes as CFData, [kCGImageSourceShouldCache: false] as CFDictionary),
              let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [kCGImageSourceCreateThumbnailFromImageAlways: true, kCGImageSourceCreateThumbnailWithTransform: true, kCGImageSourceThumbnailMaxPixelSize: 600, kCGImageSourceShouldCacheImmediately: true] as CFDictionary) else { return nil }
        let output = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(output, UTType.jpeg.identifier as CFString, 1, nil) else { return nil }
        CGImageDestinationAddImage(destination, image, [kCGImageDestinationLossyCompressionQuality: 0.85] as CFDictionary)
        guard CGImageDestinationFinalize(destination) else { return nil }
        return output as Data
    }
}
