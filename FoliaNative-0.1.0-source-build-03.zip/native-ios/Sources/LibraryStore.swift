import AVFoundation
import CryptoKit
import Foundation

// native-ios/Sources/LibraryStore.swift
actor LibraryStore {
    private struct Manifest: Codable {
        var version = 1
        var tracks: [MusicTrack]
    }
    private let root: URL
    private let manager = FileManager.default
    private var mutating = false
    private let extensions: Set<String> = ["mp3", "m4a", "aac", "wav", "aiff", "aif", "caf", "flac", "mp4", "alac"]

    init(root: URL? = nil) {
        self.root = root ?? FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("NativeMusic", isDirectory: true)
    }

    func load() throws -> [MusicTrack] {
        try manager.createDirectory(at: root.appendingPathComponent("Audio", isDirectory: true), withIntermediateDirectories: true)
        let file = root.appendingPathComponent("library.json")
        guard manager.fileExists(atPath: file.path) else { return [] }
        do {
            let manifest = try JSONDecoder().decode(Manifest.self, from: Data(contentsOf: file))
            guard manifest.version == 1 else { throw NativeMusicError.message("曲库版本较新，请保留文件并更新应用") }
            for track in manifest.tracks { _ = try url(for: track) }
            return manifest.tracks
        } catch {
            throw NativeMusicError.message("本地曲库读取失败，原文件已保留：\(error.localizedDescription)")
        }
    }

    func url(for track: MusicTrack) throws -> URL {
        guard track.source == .local, let path = track.localFile,
              !path.hasPrefix("/"), !path.contains("\\"), !path.contains(":"),
              path.split(separator: "/", omittingEmptySubsequences: false).count == 2, !path.hasSuffix("/"),
              path.split(separator: "/").allSatisfy({ $0 != ".." && $0 != "." }),
              path.hasPrefix("Audio/") else { throw NativeMusicError.message("本地音乐路径无效") }
        let candidate = root.appendingPathComponent(path).standardizedFileURL
        let canonical = candidate.resolvingSymlinksInPath()
        let canonicalRoot = root.resolvingSymlinksInPath()
        let boundary = canonicalRoot.appendingPathComponent("Audio", isDirectory: true).path + "/"
        let expected = canonicalRoot.appendingPathComponent(path).standardizedFileURL
        guard canonical.path.hasPrefix(boundary), canonical.path == expected.path else {
            throw NativeMusicError.message("本地音乐路径包含外部链接")
        }
        return expected
    }

    /// 所有文件复制、分块校验及媒体元数据读取在独立 actor 上执行，不阻塞主界面。
    func importFiles(_ files: [URL]) async throws -> ImportResult {
        guard !mutating else { throw NativeMusicError.message("曲库正在更新，请稍后再试") }
        mutating = true
        defer { mutating = false }
        var tracks = try load()
        var result = ImportResult(imported: [], duplicates: 0, failures: [])
        var lyricFiles: [(String, String)] = []
        var total: Int64 = 0
        for file in files {
            let scoped = file.startAccessingSecurityScopedResource()
            defer { if scoped { file.stopAccessingSecurityScopedResource() } }
            do {
                let staged = try coordinatedStage(file)
                defer { try? manager.removeItem(at: staged) }
                let values = try staged.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey])
                guard values.isRegularFile == true else { throw NativeMusicError.message("请选择音频文件，不是文件夹") }
                let size = Int64(values.fileSize ?? 0)
                guard size > 0, size <= 200 * 1024 * 1024 else { throw NativeMusicError.message("单个文件需介于 1 字节与 200 MB 之间") }
                total += size
                guard total <= 500 * 1024 * 1024 else { throw NativeMusicError.message("本次选择超过 500 MB，请分批导入") }
                if file.pathExtension.lowercased() == "lrc" {
                    guard size <= 2 * 1024 * 1024 else { throw NativeMusicError.message("歌词文件超过 2 MB") }
                    let bytes = try Data(contentsOf: staged)
                    guard let text = String(data: bytes, encoding: .utf8) ?? String(data: bytes, encoding: .utf16) else {
                        throw NativeMusicError.message("歌词请保存为 UTF-8 或 UTF-16 编码")
                    }
                    lyricFiles.append((file.deletingPathExtension().lastPathComponent, text))
                    continue
                }
                guard extensions.contains(file.pathExtension.lowercased()) else { throw NativeMusicError.message("此文件不是支持的音频或 LRC 歌词") }
                let id = try digest(staged)
                if tracks.contains(where: { $0.id == id }) { result.duplicates += 1; continue }
                let path = "Audio/\(id).\(file.pathExtension.lowercased())"
                let ownedURL = try url(for: MusicTrack(id: id, title: "", artist: "", source: .local, localFile: path))
                if !manager.fileExists(atPath: ownedURL.path) { try manager.copyItem(at: staged, to: ownedURL) }
                do {
                    guard try digest(ownedURL) == id else { throw NativeMusicError.message("复制校验失败，请重新导入") }
                    let asset = AVURLAsset(url: ownedURL)
                    guard try await asset.load(.isPlayable) else { throw NativeMusicError.message("系统播放器不支持此音频编码") }
                    let seconds = try await asset.load(.duration).seconds
                    let metadata = try await asset.load(.commonMetadata)
                    var title = file.deletingPathExtension().lastPathComponent
                    var artist = "未知歌手", album = ""
                    for item in metadata {
                        guard let value = try? await item.load(.stringValue), !value.isEmpty else { continue }
                        switch item.commonKey {
                        case .commonKeyTitle: title = value
                        case .commonKeyArtist: artist = value
                        case .commonKeyAlbumName: album = value
                        default: break
                        }
                    }
                    let track = MusicTrack(id: id, title: title, artist: artist, album: album, duration: seconds.isFinite ? seconds : 0, source: .local, localFile: path, originalFilename: file.deletingPathExtension().lastPathComponent)
                    var updated = tracks
                    updated.append(track)
                    try save(updated)
                    tracks = updated
                    result.imported.append(track)
                } catch {
                    try? manager.removeItem(at: ownedURL)
                    throw error
                }
            } catch { result.failures.append("\(file.lastPathComponent)：\(error.localizedDescription)") }
        }
        // 同名歌词可与音频同批导入，也可以在歌曲已入库后补充导入。
        for (name, text) in lyricFiles {
            if let index = tracks.firstIndex(where: { ($0.originalFilename ?? $0.title).caseInsensitiveCompare(name) == .orderedSame || $0.title.caseInsensitiveCompare(name) == .orderedSame }) {
                tracks[index].lyricText = text
            } else { result.failures.append("\(name).lrc：未找到同名歌曲，请先导入音频并使文件名与曲名一致") }
        }
        try save(tracks)
        result.imported = result.imported.compactMap { imported in tracks.first(where: { $0.id == imported.id }) }
        return result
    }

    func remove(_ track: MusicTrack) throws {
        guard !mutating else { throw NativeMusicError.message("曲库正在更新，请稍后再试") }
        var tracks = try load()
        tracks.removeAll { $0.id == track.id }
        try save(tracks)
        try? manager.removeItem(at: url(for: track))
    }

    private func save(_ tracks: [MusicTrack]) throws {
        let bytes = try JSONEncoder().encode(Manifest(tracks: tracks))
        try bytes.write(to: root.appendingPathComponent("library.json"), options: .atomic)
    }

    /// 文件提供器（含 iCloud）通过协调读取取得稳定副本；只对用户选择的文件读，不移动原件。
    private func coordinatedStage(_ file: URL) throws -> URL {
        let target = manager.temporaryDirectory.appendingPathComponent("folia-import-\(UUID().uuidString).\(file.pathExtension)")
        var result: Result<URL, Error>?
        var coordinatorError: NSError?
        NSFileCoordinator(filePresenter: nil).coordinate(readingItemAt: file, options: .withoutChanges, error: &coordinatorError) { readable in
            result = Result {
                let values = try readable.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey])
                guard values.isRegularFile == true else { throw NativeMusicError.message("请选择音频文件，不是文件夹") }
                let size = values.fileSize ?? 0
                guard size > 0, size <= 200 * 1024 * 1024 else { throw NativeMusicError.message("单个文件需介于 1 字节与 200 MB 之间") }
                try manager.copyItem(at: readable, to: target)
                return target
            }
        }
        if let coordinatorError { try? manager.removeItem(at: target); throw coordinatorError }
        guard let result else { throw NativeMusicError.message("文件提供器没有完成读取，请先在“文件”中下载后重试") }
        do { return try result.get() }
        catch { try? manager.removeItem(at: target); throw error }
    }

    private func digest(_ file: URL) throws -> String {
        let handle = try FileHandle(forReadingFrom: file)
        defer { try? handle.close() }
        var hash = SHA256()
        while let part = try handle.read(upToCount: 1024 * 1024), !part.isEmpty { hash.update(data: part) }
        return hash.finalize().map { String(format: "%02x", $0) }.joined()
    }
}
