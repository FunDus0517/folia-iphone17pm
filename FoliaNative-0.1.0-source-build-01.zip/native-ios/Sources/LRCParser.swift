import Foundation

// native-ios/Sources/LRCParser.swift
enum LRCParser {
    /// LRC offset 为毫秒，正数让歌词提前；多个时间标签展开，重复时间稳定排序。
    static func parse(_ text: String) -> [LyricLine] {
        let stamp = try! NSRegularExpression(pattern: #"\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]"#)
        let offsetPattern = try! NSRegularExpression(pattern: #"\[offset:\s*([+-]?\d+)\]"#, options: .caseInsensitive)
        let fullRange = NSRange(text.startIndex..., in: text)
        let offsetMatch = offsetPattern.matches(in: text, range: fullRange).last
        let offset = offsetMatch.flatMap { Range($0.range(at: 1), in: text) }.flatMap { Double(text[$0]) }.map { $0 / 1000 } ?? 0
        var pending: [(time: Double, text: String, order: Int)] = []
        for raw in text.components(separatedBy: .newlines) {
            let matches = stamp.matches(in: raw, range: NSRange(raw.startIndex..., in: raw))
            guard let last = matches.last, let end = Range(last.range, in: raw)?.upperBound else { continue }
            let words = String(raw[end...]).replacingOccurrences(of: #"<\d+:\d+(?:\.\d+)?>"#, with: "", options: .regularExpression).trimmingCharacters(in: .whitespaces)
            guard !words.isEmpty else { continue }
            for match in matches {
                func value(_ group: Int) -> String {
                    Range(match.range(at: group), in: raw).map { String(raw[$0]) } ?? ""
                }
                guard let minute = Double(value(1)), let second = Double(value(2)), second < 60 else { continue }
                let fraction = value(3)
                let decimal = fraction.isEmpty ? 0 : (Double("0." + fraction) ?? 0)
                pending.append((max(0, minute * 60 + second + decimal - offset), words, pending.count))
            }
        }
        return pending.sorted { $0.time == $1.time ? $0.order < $1.order : $0.time < $1.time }.enumerated().map {
            LyricLine(id: $0.offset, time: $0.element.time, text: $0.element.text)
        }
    }

    static func activeID(at time: Double, in lines: [LyricLine]) -> Int? {
        guard time.isFinite else { return nil }
        var low = 0, high = lines.count
        while low < high {
            let middle = (low + high) / 2
            if lines[middle].time <= time { low = middle + 1 } else { high = middle }
        }
        return low > 0 ? lines[low - 1].id : nil
    }
}
