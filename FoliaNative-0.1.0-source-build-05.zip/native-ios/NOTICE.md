# 网易原生适配来源

本目录的协议算法、加密常量与接口字段参考已锁定依赖
`@neteasecloudmusicapienhanced/api` 4.41.1 的 `util/crypto.js`、
`module/*.js`，在本项目中适配为浏览器/Capacitor 实现。

上游项目：<https://github.com/NeteaseCloudMusicApiEnhanced/api-enhanced>。
原 MIT 版权与许可全文保存在 `public/third-party/native-netease-LICENSE.txt`，
该文件会同时随源码和内嵌网页资源进入 IPA；Folia 其余代码继续遵循根许可证。

此实现不携带音乐、付费权限或用户账号。协议离线对照测试、匿名只读连接检查和
WebKit 模拟均不等于真实账号或 iPhone 设备验收。
