import SwiftUI

// native-ios/Sources/NativePlayerView.swift
struct NativeMiniPlayer: View {
    @ObservedObject var playback: NativePlayback
    let open: () -> Void
    var body: some View {
        if let track = playback.track {
            HStack(spacing: 12) {
                Button(action: open) {
                    HStack(spacing: 10) {
                        TrackArtwork(url: track.artworkURL).frame(width: 46, height: 46).clipShape(RoundedRectangle(cornerRadius: 8))
                        VStack(alignment: .leading, spacing: 4) {
                            Text(track.title).font(.subheadline.bold()).lineLimit(1)
                            Text(currentLine ?? track.artist).font(.caption).foregroundStyle(.secondary).lineLimit(1).accessibilityIdentifier("miniLyric")
                        }
                        Spacer(minLength: 0)
                    }.contentShape(Rectangle())
                }.buttonStyle(.plain).accessibilityLabel("打开正在播放").accessibilityValue(currentLine ?? track.artist).accessibilityIdentifier("openPlayer")
                Button { playback.toggle() } label: {
                    Image(systemName: playback.isPlaying ? "pause.fill" : "play.fill").frame(width: 44, height: 44)
                }.accessibilityLabel(playback.isPlaying ? "暂停" : "播放").accessibilityIdentifier("miniToggle")
                NativeElapsedLabel(clock: playback.clock, identifier: "miniSeconds").font(.caption.monospacedDigit()).frame(minWidth: 36)
            }
            .padding(.horizontal, 14).padding(.vertical, 8).background(.regularMaterial)
        }
    }
    private var currentLine: String? { playback.lyrics.first(where: { $0.id == playback.activeLyricID })?.text }
}

struct NativePlayerView: View {
    @ObservedObject var model: AppModel
    @ObservedObject var playback: NativePlayback
    @Environment(\.dismiss) private var dismiss
    @Environment(\.verticalSizeClass) private var verticalSizeClass
    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                if let track = playback.track {
                    if verticalSizeClass != .compact {
                        HStack(spacing: 14) {
                            TrackArtwork(url: track.artworkURL).frame(width: 68, height: 68).clipShape(RoundedRectangle(cornerRadius: 12))
                            VStack(alignment: .leading, spacing: 5) {
                                Text(track.title).font(.headline).lineLimit(2)
                                Text(track.artist).foregroundStyle(.secondary).lineLimit(1)
                            }
                            Spacer(minLength: 0)
                        }.padding(.horizontal)
                    }
                    NativeLyricsView(lines: playback.lyrics, activeID: playback.activeLyricID, seek: { playback.seek(to: $0) })
                    if let error = playback.error {
                        Text(error).font(.footnote).foregroundStyle(.orange).padding(.horizontal).accessibilityIdentifier("playbackError")
                    }
                    NativePlaybackProgress(clock: playback.clock, seek: { playback.seek(to: $0) }).padding(.horizontal)
                    HStack(spacing: 36) {
                        Button { model.previous() } label: { Image(systemName: "backward.end.fill").frame(width: 48, height: 48) }.accessibilityLabel("上一首")
                        Button { playback.toggle() } label: {
                            Image(systemName: playback.isPlaying ? "pause.circle.fill" : "play.circle.fill").font(.system(size: 58))
                        }.accessibilityLabel(playback.isPlaying ? "暂停" : "播放").accessibilityIdentifier("fullToggle")
                        Button { model.next() } label: { Image(systemName: "forward.end.fill").frame(width: 48, height: 48) }.accessibilityLabel("下一首")
                    }.padding(.bottom, 8)
                } else { ContentUnavailableView("还没有播放歌曲", systemImage: "music.note") }
            }
            .background { Color.black.ignoresSafeArea() }
            .navigationTitle(verticalSizeClass == .compact ? (playback.track?.title ?? "正在播放") : "正在播放")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { dismiss() } label: { Label("收起", systemImage: "chevron.down") }.accessibilityIdentifier("closePlayer")
                }
            }
        }.presentationDragIndicator(.visible)
    }
}

private struct NativeLyricsView: View {
    let lines: [LyricLine]
    let activeID: Int?
    let seek: (Double) -> Void
    var body: some View {
        if lines.isEmpty {
            ContentUnavailableView("暂无歌词", systemImage: "text.alignleft", description: Text("本地歌曲可以导入同名 LRC 文件；在线歌曲以服务返回的歌词为准。"))
                .frame(maxHeight: .infinity)
        } else {
            ScrollViewReader { reader in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 24) {
                        ForEach(lines) { line in
                            Button { seek(line.time) } label: {
                                VStack(alignment: .leading, spacing: 6) {
                                    Text(line.text).font(.title3.weight(line.id == activeID ? .bold : .medium))
                                    if let translation = line.translation { Text(translation).font(.subheadline) }
                                }
                                .foregroundStyle(line.id == activeID ? Color.white : Color.secondary)
                                .frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 5)
                            }
                            .buttonStyle(.plain).id(line.id)
                            .accessibilityIdentifier("lyric-row-\(line.id)")
                            .accessibilityValue(line.id == activeID ? "当前歌词" : "")
                        }
                    }.padding(.horizontal, 28).padding(.vertical, 36)
                }.accessibilityIdentifier("lyricsScroll")
                .onAppear { if let activeID { reader.scrollTo(activeID, anchor: .center) } }
                // 行变化才滚动；播放进度的 5 Hz 刷新不会传到歌词布局。
                .onChange(of: activeID) { _, id in
                    if let id { withAnimation(.easeOut(duration: 0.22)) { reader.scrollTo(id, anchor: .center) } }
                }
            }
        }
    }
}

private struct NativePlaybackProgress: View {
    @ObservedObject var clock: PlaybackClock
    let seek: (Double) -> Void
    @State private var editing = false
    @State private var draft: Double = 0
    var body: some View {
        VStack(spacing: 2) {
            Slider(value: Binding(get: { editing ? draft : min(clock.position, max(clock.duration, 1)) }, set: { draft = $0 }), in: 0...max(clock.duration, 1), onEditingChanged: { value in
                if value { draft = clock.position; editing = true }
                else { editing = false; seek(draft) }
            }).accessibilityLabel("播放进度").accessibilityIdentifier("playbackProgress")
            HStack {
                NativeElapsedLabel(clock: clock, identifier: "playbackSeconds")
                Spacer()
                Text(Self.time(clock.duration))
            }.font(.caption.monospacedDigit()).foregroundStyle(.secondary)
        }
    }
    static func time(_ seconds: Double) -> String {
        let value = seconds.isFinite ? max(0, Int(seconds)) : 0
        return String(format: "%02d:%02d", value / 60, value % 60)
    }
}

private struct NativeElapsedLabel: View {
    @ObservedObject var clock: PlaybackClock
    let identifier: String
    var body: some View {
        Text(NativePlaybackProgress.time(clock.position))
            .accessibilityIdentifier(identifier).accessibilityLabel("已播放时间")
            .accessibilityValue(String(format: "%.2f", clock.position))
    }
}
