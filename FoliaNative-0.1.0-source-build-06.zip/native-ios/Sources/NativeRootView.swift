import SwiftUI
import UniformTypeIdentifiers
import UIKit

// native-ios/Sources/NativeRootView.swift
struct NativeRootView: View {
    @ObservedObject var model: AppModel
    var body: some View {
        TabView {
            LocalLibraryView(model: model)
                .safeAreaInset(edge: .bottom, spacing: 0) { miniPlayer }
                .tabItem { Label("曲库", systemImage: "music.note.list") }
            OnlineMusicView(model: model, source: .netease)
                .safeAreaInset(edge: .bottom, spacing: 0) { miniPlayer }
                .tabItem { Label("网易云", systemImage: "cloud") }
            OnlineMusicView(model: model, source: .qq)
                .safeAreaInset(edge: .bottom, spacing: 0) { miniPlayer }
                .tabItem { Label("QQ音乐", systemImage: "music.note") }
            NativeSettingsView(model: model)
                .safeAreaInset(edge: .bottom, spacing: 0) { miniPlayer }
                .tabItem { Label("设置", systemImage: "gearshape") }
        }
        .tint(.mint)
        // 播放条属于各页内容安全区，不在 TabView 外覆盖系统标签栏。
        .fullScreenCover(isPresented: $model.showPlayer) { NativePlayerView(model: model, playback: model.playback) }
        .alert("提示", isPresented: Binding(get: { model.notice != nil }, set: { if !$0 { model.notice = nil } })) {
            Button("知道了", role: .cancel) { model.notice = nil }
        } message: { Text(model.notice ?? "") }
    }
    private var miniPlayer: some View {
        NativeMiniPlayer(playback: model.playback, open: { model.showPlayer = true })
    }
}

private struct LocalLibraryView: View {
    @ObservedObject var model: AppModel
    @State private var showImporter = false
    @State private var query = ""
    private var filteredTracks: [MusicTrack] {
        query.isEmpty ? model.localTracks : model.localTracks.filter { $0.title.localizedCaseInsensitiveContains(query) || $0.artist.localizedCaseInsensitiveContains(query) }
    }
    var body: some View {
        NavigationStack {
            List {
                if model.localTracks.isEmpty {
                    ContentUnavailableView("导入你的音乐", systemImage: "music.note", description: Text("从“文件”选择音频。可同时选择同名 LRC 歌词，文件会复制到应用中保存。"))
                        .listRowBackground(Color.clear)
                }
                ForEach(filteredTracks) { track in
                    TrackRow(track: track, loading: model.loadingTrackID == track.id) { model.play(track, among: filteredTracks) }
                        .swipeActions { Button("删除", role: .destructive) { Task { await model.remove(track) } } }
                }
            }
            .navigationTitle("曲库")
            .searchable(text: $query, prompt: "搜索本地歌曲或歌手")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showImporter = true } label: { Label(model.importing ? "导入中" : "导入音乐", systemImage: "square.and.arrow.down") }
                        .disabled(model.importing).accessibilityIdentifier("importMusic")
                }
            }
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.audio, UTType(filenameExtension: "lrc") ?? .plainText], allowsMultipleSelection: true) { result in
                switch result {
                case .success(let files): Task { await model.importFiles(files) }
                case .failure(let error): model.notice = "文件选择失败：\(error.localizedDescription)"
                }
            }
            .overlay { if model.importing { ProgressView("正在复制和读取音乐…").padding().background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16)) } }
        }
    }
}

struct TrackRow: View {
    let track: MusicTrack
    var loading = false
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                TrackArtwork(url: track.artworkURL).frame(width: 48, height: 48).clipShape(RoundedRectangle(cornerRadius: 8))
                VStack(alignment: .leading, spacing: 5) {
                    Text(track.title).font(.body).lineLimit(2)
                    Text(track.artist).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 4)
                if loading { ProgressView() } else { Image(systemName: "play.circle").foregroundStyle(.mint) }
            }.padding(.vertical, 4).contentShape(Rectangle())
        }
        .buttonStyle(.plain).accessibilityIdentifier("track-\(track.id)")
    }
}

struct TrackArtwork: View {
    let url: URL?
    @State private var image: UIImage?
    var body: some View {
        ZStack {
            Color.white.opacity(0.08)
            if let image { Image(uiImage: image).resizable().scaledToFill() }
            else { Image(systemName: "music.note").foregroundStyle(.secondary) }
        }
        .clipped().accessibilityHidden(true)
        .task(id: url) {
            image = nil
            guard let url, let data = await NativeArtworkStore.shared.imageData(for: url), !Task.isCancelled else { return }
            image = UIImage(data: data)
        }
    }
}

private struct NativeSettingsView: View {
    @ObservedObject var model: AppModel
    // 编辑只刷新当前输入框；保存时才发布连接变更，避免每次按键重绘所有标签页。
    @State private var endpointText = ""
    var body: some View {
        NavigationStack {
            Form {
                Section("QQ 音乐连接") {
                    TextField("HTTPS 服务地址", text: $endpointText).accessibilityIdentifier("qqEndpointField").textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                    Button("保存连接设置") {
                        model.qqEndpoint = endpointText
                        Task { await model.saveQQEndpoint(); endpointText = model.qqEndpoint }
                    }
                    Text("搜索可直连。登录、歌单和播放需要兼容的 QQ 音乐 API 服务；不填地址时不会假装已连接。").font(.footnote).foregroundStyle(.secondary)
                }
                Section("原生版") {
                    LabeledContent("界面", value: "SwiftUI")
                    LabeledContent("音频", value: "苹果系统播放器")
                    Text("后台播放、锁屏控制与耳机控制由 iOS 管理。在线歌曲受账号、会员和服务可用性影响。")
                    Text("此版本独立安装，旧版的本地曲库需从原始音频重新导入；请先保留旧版。")
                }
                Section("开源许可") {
                    Text("Folia：AGPL-3.0。网易云协议适配参考 api-enhanced（MIT）。完整许可证随源码提供。")
                    NavigationLink("查看许可证") { NativeLicenseView() }
                }
            }.navigationTitle("设置")
            .onAppear { endpointText = model.qqEndpoint }
        }
    }
}

private struct NativeLicenseView: View {
    private var content: String {
        ["AGPL-3.0", "api-enhanced-MIT"].map { name in
            guard let url = Bundle.main.url(forResource: name, withExtension: "txt"),
                  let text = try? String(contentsOf: url, encoding: .utf8) else { return "\(name)：请参阅随发行版提供的开源源码。" }
            return "\(name)\n\n\(text)"
        }.joined(separator: "\n\n————\n\n")
    }
    var body: some View { ScrollView { Text(content).font(.caption).textSelection(.enabled).padding() }.navigationTitle("开源许可证") }
}
