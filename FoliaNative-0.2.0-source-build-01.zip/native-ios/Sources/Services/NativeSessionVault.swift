import Foundation
import Security

// native-ios/Sources/Services/NativeSessionVault.swift
// Session secrets stay in this-device-only Keychain records, never UserDefaults, logs or view models.
protocol NativeSessionVault: Sendable {
    func read(_ account: String) throws -> Data?
    func write(_ data: Data?, account: String) throws
}

struct KeychainNativeSessionVault: NativeSessionVault {
    private let service: String
    init(service: String = (Bundle.main.bundleIdentifier ?? "app.folia.native") + ".native-music") { self.service = service }

    private func query(_ account: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account]
    }

    func read(_ account: String) throws -> Data? {
        var request = query(account)
        request[kSecReturnData as String] = true
        request[kSecMatchLimit as String] = kSecMatchLimitOne
        var value: CFTypeRef?
        let status = SecItemCopyMatching(request as CFDictionary, &value)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess else { throw NativeMusicError.message("读取安全登录信息失败（\(status)），请解锁设备后重试") }
        return value as? Data
    }

    func write(_ data: Data?, account: String) throws {
        let request = query(account)
        guard let data else {
            let status = SecItemDelete(request as CFDictionary)
            guard status == errSecSuccess || status == errSecItemNotFound else { throw NativeMusicError.message("清除安全登录信息失败（\(status)）") }
            return
        }
        let update = [kSecValueData as String: data]
        let status = SecItemUpdate(request as CFDictionary, update as CFDictionary)
        if status == errSecSuccess { return }
        guard status == errSecItemNotFound else { throw NativeMusicError.message("保存安全登录信息失败（\(status)）") }
        var create = request
        create[kSecValueData as String] = data
        create[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        let addStatus = SecItemAdd(create as CFDictionary, nil)
        guard addStatus == errSecSuccess else { throw NativeMusicError.message("保存安全登录信息失败（\(addStatus)）") }
    }
}
