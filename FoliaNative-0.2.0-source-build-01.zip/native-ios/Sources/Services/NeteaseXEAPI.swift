import Foundation
import CryptoKit

// native-ios/Sources/Services/NeteaseXEAPI.swift
// Native port of nativeNetease/xeapi.ts. Uses fresh X25519/GCM keys; no JS or content-unlocking fallback.
struct NeteaseXEAPIKey: Sendable {
    let publicKey: Data
    let sk: String
    let version: String
}

enum NeteaseXEAPI {
    static let userAgent = "NeteaseMusic/9.5.61.260802021928(9005061);Dalvik/2.1.0 (Linux; U; Android 12; HBN-AL00 Build/cd737a2.0)"
    private static let signKey = Data("mUHCwVNWJbunMqAHf5MImuirT6plvs6VSFW62MGHstFQxhBGdEoIhLItH3djc4+FB/OKty3+lL2rGeoFBpVe5g==".utf8)

    static func sign(timestamp: String, nonce: String) -> String {
        NeteaseCrypto.hmac(Data((timestamp + nonce).utf8), key: signKey).base64EncodedString()
    }

    static func parseKey(_ encrypted: String) throws -> NeteaseXEAPIKey {
        guard let encrypted = Data(base64Encoded: encrypted) else { throw NativeMusicError.message("网易云播放公钥格式异常") }
        let json = try NativeJSON.decoded(NeteaseCrypto.aes(encrypted, key: NeteaseCrypto.staticXeapiKey, decrypt: true))
        guard let publicKey = Data(base64Encoded: json["publicKey"].text), publicKey.count == 32,
              !json["sk"].text.isEmpty, !json["version"].text.isEmpty else { throw NativeMusicError.message("网易云播放公钥校验失败") }
        return NeteaseXEAPIKey(publicKey: publicKey, sk: json["sk"].text, version: json["version"].text)
    }

    static func plaintext(_ data: [String: NativeJSON]) throws -> Data {
        let fields = data.filter { $0.key != "e_r" }.mapValues(\.text)
        let form = String(decoding: NativeURLRules.form(fields), as: UTF8.self)
        var payload: [String: NativeJSON] = ["queryString": .string("e_r=true")]
        if !form.isEmpty { payload["content"] = .string(form) }
        return try NativeJSON.object(payload).encoded()
    }

    static func deriveKey(sharedSecret: Data, ephemeral: Data) -> Data {
        let prk = NeteaseCrypto.hmac(sharedSecret, key: Data(repeating: 0, count: 32))
        return Data(NeteaseCrypto.hmac(ephemeral + Data([1]), key: prk).prefix(16))
    }

    static func encrypt(_ data: [String: NativeJSON], key: NeteaseXEAPIKey) throws -> [String: String] {
        let dynamic = try NeteaseCrypto.random(16)
        let ephemeral = Curve25519.KeyAgreement.PrivateKey()
        let publicKey = ephemeral.publicKey.rawRepresentation
        let peer = try Curve25519.KeyAgreement.PublicKey(rawRepresentation: key.publicKey)
        let shared = try ephemeral.sharedSecretFromKeyAgreement(with: peer).withUnsafeBytes { Data($0) }
        let aesKey = deriveKey(sharedSecret: shared, ephemeral: publicKey)
        let nonceData = try NeteaseCrypto.random(12)
        let nonce = try AES.GCM.Nonce(data: nonceData)
        let content = Data("\(dynamic.base64EncodedString())|android|\(key.sk)".utf8)
        let sealed = try AES.GCM.seal(content, using: SymmetricKey(data: aesKey), nonce: nonce)
        let inner = try NeteaseCrypto.aes(plaintext(data), key: NeteaseCrypto.staticXeapiKey)
        let mask = try NeteaseCrypto.random(16)
        let maskBytes = [UInt8](mask)
        let xored = Data(inner.enumerated().map { $0.element ^ maskBytes[$0.offset & 15] })
        let rotation = xored.isEmpty ? 0 : Int(maskBytes[0] & 15) % xored.count
        let rotated = Data(xored.dropFirst(rotation)) + Data(xored.prefix(rotation))
        let c = try NeteaseCrypto.aes(mask + rotated, key: dynamic).base64EncodedString()
        return [
            "C": c.replacingOccurrences(of: "+", with: "-").replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: "=", with: ""),
            "S": (publicKey + nonceData + sealed.ciphertext + sealed.tag).base64EncodedString(),
            "R": try NeteaseCrypto.aes(Data("\(key.version)|".utf8), key: NeteaseCrypto.staticXeapiKey).base64EncodedString()
        ]
    }

    static func decodeResponse(_ data: Data) throws -> NativeJSON {
        if let first = data.first, first == UInt8(ascii: "{") { return try NativeJSON.decoded(data) }
        let plain = try NeteaseCrypto.aes(data, key: NeteaseCrypto.eapiKey, decrypt: true)
        let expanded = plain.starts(with: [0x1f, 0x8b]) ? try NativeInflate.decompress(plain) : plain
        return try NativeJSON.decoded(expanded)
    }
}
