import SwiftUI
import UIKit

// native-ios/Sources/FoliaTrackViews.swift
// 封面组件供曲墙、搜索结果、歌词舞台复用，图片请求自动启动。
struct TrackArtwork: View {
    let url: URL?
    @State private var image: UIImage?
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.31, green: 0.29, blue: 0.24), .black], startPoint: .topLeading, endPoint: .bottomTrailing)
            if let image { Image(uiImage: image).resizable().scaledToFill() }
            else { Image(systemName: "music.note").font(.title2).foregroundStyle(.white.opacity(0.35)) }
        }.clipped().accessibilityHidden(true)
            .task(id: url) {
                image = nil
                let requested = url ?? FoliaLayout.defaultArtwork
                guard let requested, let data = await NativeArtworkStore.shared.imageData(for: requested), !Task.isCancelled else { return }
                image = UIImage(data: data)
            }
    }
}

struct TrackRow: View {
    let track: MusicTrack
    var loading = false
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                TrackArtwork(url: track.artworkURL).frame(width: 52, height: 52).clipShape(RoundedRectangle(cornerRadius: 11))
                VStack(alignment: .leading, spacing: 5) {
                    Text(track.title).font(.subheadline.weight(.medium)).lineLimit(2)
                    Text(track.artist).font(.caption).foregroundStyle(.white.opacity(0.5)).lineLimit(1)
                }
                Spacer(minLength: 4)
                if loading { ProgressView() } else { Image(systemName: "play.fill").font(.caption).foregroundStyle(.white.opacity(0.7)).frame(width: 32, height: 44) }
            }.padding(10).contentShape(Rectangle())
                .background(.black.opacity(0.19), in: RoundedRectangle(cornerRadius: 16))
                .overlay { RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.07), lineWidth: 0.7) }
        }.buttonStyle(.plain).accessibilityIdentifier("track-\(track.id)")
    }
}

struct FoliaTrackTile: View {
    let track: MusicTrack
    let index: Int
    let height: Double
    var loading = false
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            ZStack(alignment: .bottomLeading) {
                TrackArtwork(url: track.artworkURL)
                LinearGradient(colors: [.clear, .black.opacity(0.2), .black.opacity(0.9)], startPoint: .top, endPoint: .bottom)
                VStack(alignment: .leading, spacing: 6) {
                    Spacer()
                    Text(track.title).font(.system(size: 19, weight: .semibold)).lineLimit(2)
                    Text(track.artist).font(.caption).foregroundStyle(.white.opacity(0.65)).lineLimit(1)
                }.padding(14)
                VStack { HStack { Text(String(format: "%02d", index + 1)).font(.system(size: 10, weight: .bold, design: .monospaced)).padding(5).background(.black.opacity(0.48)); Spacer(); if loading { ProgressView() } }; Spacer() }.padding(10)
            }.frame(height: height).clipShape(RoundedRectangle(cornerRadius: 5))
                .overlay { RoundedRectangle(cornerRadius: 5).stroke(.white.opacity(0.23), lineWidth: 0.8) }.contentShape(Rectangle())
        }.buttonStyle(.plain).accessibilityLabel("\(track.title)，\(track.artist)").accessibilityIdentifier("track-\(track.id)")
    }
}
