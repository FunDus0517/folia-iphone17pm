import XCTest
import Foundation
import CryptoKit
@testable import FoliaNative

// native-ios/Tests/NativeOnlineTests.swift
// All transport tests are offline. They never send SMS, authorize an account or contact a public API.
final class NativeOnlineTests: XCTestCase {
    func testWEAPICompatibleWithIndependentNodeAESAndRSA() throws {
        let payload: NativeJSON = .object(["phone": .string("fixture-only"), "captcha": .string("000000"), "csrf_token": .string(""), "e_r": .bool(false)])
        let result = try NeteaseCrypto.weapi(payload, secret: "aaaaaaaaaaaaaaaa")
        XCTAssertEqual(result["params"], "LtMZ94+YXrzyone2hDvkIPensXgNB+JZ2Ifu5QlMhQqnu0SSxCYwIkwZV61img3dxdeumKZvHQdUKpAix1SlfdQWRkjEiE+sfygIZN3CLy9HtaKDqQSPlSDEvecG7p3hGgS10mUNWDb2uipT1Nl3Xw==")
        XCTAssertEqual(result["encSecKey"], "d473b9eca232f1b4090dd606b0df86de318748dd2eec307e4ed4345030fc4ee30331e598f41d5a6f5befaab94630ea1a1eda7cfade84fbec1a907913d2e4d2c8744bc572b99a050075e075b4537f645ecfa994f95906c32818e076aeda6bdb906bfa0bb96c4cf4bc3ed6d9ab76cf08441153d9d85e1ea3d78fa8d9210d581cee")
    }

    func testAESECBRejectsTruncationAndIncorrectPadding() throws {
        let plain = Data("中文原生请求，含\0".utf8)
        for length in [16, 32] {
            let key = Data((0..<length).map(UInt8.init))
            let encoded = try NeteaseCrypto.aes(plain, key: key)
            XCTAssertEqual(try NeteaseCrypto.aes(encoded, key: key, decrypt: true), plain)
        }
        XCTAssertThrowsError(try NeteaseCrypto.aes(Data([1, 2]), key: NeteaseCrypto.eapiKey, decrypt: true))
        XCTAssertThrowsError(try NeteaseCrypto.aes(Data(repeating: 0, count: 16), key: NeteaseCrypto.eapiKey, decrypt: true))
    }

    func testXEAPIRegistrationSignatureKnownVector() {
        XCTAssertEqual(NeteaseXEAPI.sign(timestamp: "1234567890", nonce: "1234567890123456"), "LVnpDmRKAx2/GFpyAHlSx3EnvkbpCxmcPqBG1TiPhpI=")
    }

    func testXEAPIEncryptedAndGzipResponseKnownVectors() throws {
        let expected: NativeJSON = .object(["code": .number(200), "data": .array([.object(["fee": .number(1), "id": .number(123), "url": .null])])])
        for vector in ["3MUrMBPptmwDj44CflgOzsIqbRHisaiHm66SAr1ez7MSdqVRRN513CwiyJ5tMhU0F/JdKyE77DdyWvCwiblrJw==", "UtqDYh+i5LhGQT4EOiuvVVQNrJLxS9nOYPk6Ny8bKaDfRhqW9FkGI+oDq+o81A1bv6prBSJhv6ODyjDfbBXkCGJzs69D/biKlUz5gIdSg9s="] {
            XCTAssertEqual(try NeteaseXEAPI.decodeResponse(Data(base64Encoded: vector)!), expected)
        }
        XCTAssertEqual(try NeteaseXEAPI.decodeResponse(expected.encoded()), expected)
    }

    func testXEAPIRequestCanBeOpenedWithServerPrivateKey() throws {
        let server = Curve25519.KeyAgreement.PrivateKey()
        let key = NeteaseXEAPIKey(publicKey: server.publicKey.rawRepresentation, sk: "fixture-server-key", version: "7")
        let payload: [String: NativeJSON] = ["ids": .string("[123]"), "level": .string("standard"), "e_r": .bool(false), "encodeType": .string("flac")]
        let form = try NeteaseXEAPI.encrypt(payload, key: key)
        let s = Data(base64Encoded: form["S"]!)!
        let ephemeral = Data(s.prefix(32)), nonce = Data(s[32..<44])
        let shared = try server.sharedSecretFromKeyAgreement(with: Curve25519.KeyAgreement.PublicKey(rawRepresentation: ephemeral)).withUnsafeBytes { Data($0) }
        let aesKey = NeteaseXEAPI.deriveKey(sharedSecret: shared, ephemeral: ephemeral)
        let box = try AES.GCM.SealedBox(nonce: AES.GCM.Nonce(data: nonce), ciphertext: Data(s[44..<(s.count - 16)]), tag: Data(s.suffix(16)))
        let decoded = try AES.GCM.open(box, using: SymmetricKey(data: aesKey))
        let parts = String(decoding: decoded, as: UTF8.self).components(separatedBy: "|")
        XCTAssertEqual(Array(parts.dropFirst()), ["android", "fixture-server-key"])
        let dynamic = Data(base64Encoded: parts[0])!
        let cText = form["C"]!.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        let c = Data(base64Encoded: cText.padding(toLength: ((cText.count + 3) / 4) * 4, withPad: "=", startingAt: 0))!
        let transformed = try NeteaseCrypto.aes(c, key: dynamic, decrypt: true)
        let mask = [UInt8](transformed.prefix(16)), rotated = Data(transformed.dropFirst(16))
        let rotation = Int(mask[0] & 15) % rotated.count
        let xored = Data(rotated.suffix(rotation)) + Data(rotated.prefix(rotated.count - rotation))
        let inner = Data(xored.enumerated().map { $0.element ^ mask[$0.offset & 15] })
        XCTAssertEqual(try NeteaseCrypto.aes(inner, key: NeteaseCrypto.staticXeapiKey, decrypt: true), try NeteaseXEAPI.plaintext(payload))
        XCTAssertEqual(try NeteaseCrypto.aes(Data(base64Encoded: form["R"]!)!, key: NeteaseCrypto.staticXeapiKey, decrypt: true), Data("7|".utf8))
    }

    func testFormEncodingMatchesURLSearchParamsAndKeepsChinese() throws {
        XCTAssertEqual(String(decoding: NativeURLRules.form(["query": "中文 +&~"]), as: UTF8.self), "query=%E4%B8%AD%E6%96%87+%2B%26%7E")
        let value: NativeJSON = .object(["message": .string("中文"), "code": .number(200)])
        XCTAssertEqual(try NativeJSON.decoded(value.encoded()), value)
        XCTAssertNil(NativeURLRules.https("javascript:alert(1)"))
        XCTAssertNil(NativeURLRules.https("https://account:secret@example.org/a"))
        XCTAssertEqual(NativeURLRules.https("http://p1.music.126.net/a.jpg")?.scheme, "https")
    }

    func testNeteaseSearchIsOfficialNativeRequestAndNormalizesSongs() async throws {
        let http = NativeFixtureHTTP { request in
            XCTAssertEqual(request.url?.host, "interfacepc.music.163.com")
            XCTAssertEqual(request.url?.path, "/eapi/cloudsearch/pc")
            XCTAssertEqual(request.httpMethod, "POST")
            return try fixtureResponse(request, json: """
            {"code":200,"result":{"songs":[{"id":123,"name":"原生歌曲","ar":[{"name":"歌手"}],"al":{"name":"专辑","picUrl":"http://p1.music.126.net/a.jpg"},"dt":123000}]}}
            """)
        }
        let service = NativeMusicService(http: http, vault: NativeMemoryVault())
        let tracks = try await service.search(source: .netease, query: "歌手")
        XCTAssertEqual(tracks.count, 1); XCTAssertEqual(tracks.first?.id, "123"); XCTAssertEqual(tracks.first?.duration, 123)
        XCTAssertEqual(tracks.first?.source, .netease); XCTAssertEqual(tracks.first?.artworkURL?.scheme, "https")
    }

    func testEmptySearchAndInvalidSMSDoNotSendNetworkRequests() async {
        let http = NativeFixtureHTTP { _ in throw NativeMusicError.message("不应请求网络") }
        let service = NativeMusicService(http: http, vault: NativeMemoryVault())
        do { let tracks = try await service.search(source: .netease, query: "  "); XCTAssertTrue(tracks.isEmpty) } catch { XCTFail("\(error)") }
        do { try await service.sendNeteaseCode(phone: "not-a-phone"); XCTFail("应拒绝无效手机号") } catch { XCTAssertTrue(error.localizedDescription.contains("手机号")) }
        do { _ = try await service.loginNetease(phone: "13800000000", code: "x"); XCTFail("应拒绝无效验证码") } catch { XCTAssertTrue(error.localizedDescription.contains("验证码")) }
        let requests = await http.requests; XCTAssertTrue(requests.isEmpty)
    }

    func testAnonymousAccountDoesNotCallNetwork() async throws {
        let http = NativeFixtureHTTP { _ in throw NativeMusicError.message("不应请求网络") }
        let service = NativeMusicService(http: http, vault: NativeMemoryVault())
        let netease = try await service.account(source: .netease), qq = try await service.account(source: .qq)
        XCTAssertNil(netease); XCTAssertNil(qq)
        let requests = await http.requests; XCTAssertTrue(requests.isEmpty)
    }

    func testQQMissingConfigurationIsNotAnEmptySuccessfulResult() async {
        let http = NativeFixtureHTTP { _ in throw NativeMusicError.message("不应请求网络") }
        let service = NativeMusicService(http: http, vault: NativeMemoryVault())
        do { _ = try await service.createQQLoginQRCode(); XCTFail("缺配置应失败") } catch { XCTAssertTrue(error.localizedDescription.contains("HTTPS")) }
        do { _ = try await service.collections(source: .qq); XCTFail("缺配置应失败") } catch { XCTAssertTrue(error.localizedDescription.contains("配置")) }
        let requests = await http.requests; XCTAssertTrue(requests.isEmpty)
    }

    func testQQRejectsInsecureEndpointWithoutSendingCredentials() async {
        let http = NativeFixtureHTTP { _ in throw NativeMusicError.message("不应请求网络") }
        let service = NativeMusicService(http: http, vault: NativeMemoryVault())
        for value in ["http://example.org", "https://user:password@example.org", "https://example.org?token=secret"] {
            await service.setQQEndpoint(URL(string: value))
            do { _ = try await service.createQQLoginQRCode(); XCTFail("不应接受无效服务地址") } catch { XCTAssertTrue(error.localizedDescription.contains("HTTPS")) }
        }
        let requests = await http.requests; XCTAssertTrue(requests.isEmpty)
    }

    func testQQSearchKeepsSongMidAndDoesNotSendBackendSession() async throws {
        let http = NativeFixtureHTTP { request in
            XCTAssertEqual(request.url?.host, "u.y.qq.com"); XCTAssertNil(request.value(forHTTPHeaderField: "X-QQ-Session"))
            return try fixtureResponse(request, json: """
            {"code":0,"request":{"code":0,"data":{"body":{"item_song":[{"id":456,"mid":"trackMID","title":"QQ原生","singer":[{"name":"歌手"}],"album":{"mid":"albumMID","name":"专辑"},"interval":210}]}}}}
            """)
        }
        let tracks = try await NativeMusicService(http: http, vault: NativeMemoryVault()).search(source: .qq, query: "测试")
        XCTAssertEqual(tracks.first?.id, "trackMID"); XCTAssertEqual(tracks.first?.duration, 210)
        XCTAssertEqual(tracks.first?.source, .qq); XCTAssertTrue(tracks.first?.artworkURL?.absoluteString.contains("albumMID") ?? false)
    }

    func testQQQRCodeLoginUsesOpaqueHeaderAndIsolatedKeychain() async throws {
        let http = NativeFixtureHTTP { request in
            XCTAssertFalse(request.url?.query?.contains("cookie") ?? false)
            switch request.url!.path {
            case "/qq/login/qr/key": return try fixtureResponse(request, json: "{\"code\":200,\"data\":{\"unikey\":\"fixture-key\"}}")
            case "/qq/login/qr/create": return try fixtureResponse(request, json: "{\"data\":{\"qrimg\":\"data:image/png;base64,aGVsbG8=\"}}")
            case "/qq/login/qr/check": return try fixtureResponse(request, json: "{\"code\":803,\"cookie\":\"qqmusic_session=opaque-only; Path=/\"}")
            case "/qq/login/status":
                XCTAssertEqual(request.value(forHTTPHeaderField: "X-QQ-Session"), "opaque-only")
                return try fixtureResponse(request, json: "{\"data\":{\"profile\":{\"str_musicid\":\"99\",\"musicid\":0,\"info\":{\"nick\":\"原生用户\",\"logo\":\"https://example.org/avatar.jpg\"}}}}")
            default: throw NativeMusicError.message("意外路径")
            }
        }
        let vault = NativeMemoryVault(), service = NativeMusicService(http: http, vault: vault)
        await service.setQQEndpoint(URL(string: "https://example.org/qq")!)
        let qr = try await service.createQQLoginQRCode()
        XCTAssertEqual(qr.id, "fixture-key"); XCTAssertNotNil(qr.imageData)
        switch try await service.pollQQLoginQRCode(qr.id) { case .authorized(let user): XCTAssertEqual(user.id, "99"); XCTAssertEqual(user.nickname, "原生用户"); default: XCTFail("应完成登录") }
        XCTAssertEqual(vault.snapshot().count, 1)
        await service.setQQEndpoint(URL(string: "https://other.example.org/qq")!)
        let otherAccount = try await service.account(source: .qq); XCTAssertNil(otherAccount)
        await service.setQQEndpoint(URL(string: "https://example.org/qq")!)
        try await service.logout(source: .qq)
        XCTAssertTrue(vault.snapshot().isEmpty)
    }

    func testQQCancellationDoesNotPollOrPersistSession() async throws {
        let http = NativeFixtureHTTP { request in
            switch request.url!.path {
            case "/login/qr/key": return try fixtureResponse(request, json: "{\"data\":{\"unikey\":\"key\"}}")
            case "/login/qr/create": return try fixtureResponse(request, json: "{\"data\":{\"qrimg\":\"https://example.org/code.png\"}}")
            case "/login/qr/cancel": return try fixtureResponse(request, json: "{\"code\":200}")
            default: XCTFail("取消后不应轮询"); return try fixtureResponse(request, json: "{\"code\":803,\"cookie\":\"qqmusic_session=wrong\"}")
            }
        }
        let vault = NativeMemoryVault(), service = NativeMusicService(http: http, vault: vault)
        await service.setQQEndpoint(URL(string: "https://example.org")!)
        let qr = try await service.createQQLoginQRCode()
        await service.cancelQQLoginQRCode(qr.id)
        do { _ = try await service.pollQQLoginQRCode(qr.id); XCTFail("取消后应抛取消") } catch { XCTAssertTrue(error is CancellationError) }
        XCTAssertTrue(vault.snapshot().isEmpty)
    }

    func testQQNullPlaybackURLIsNotReportedAsRemovedOrPlayable() async {
        let http = NativeFixtureHTTP { request in try fixtureResponse(request, json: "{\"data\":{\"playUrl\":{\"mid\":{\"url\":\"\"}}}}") }
        let service = NativeMusicService(http: http, vault: NativeMemoryVault())
        await service.setQQEndpoint(URL(string: "https://example.org")!)
        do { _ = try await service.resolve(MusicTrack(id: "mid", title: "测试", artist: "歌手", source: .qq)); XCTFail("空链接不应播放") }
        catch { XCTAssertTrue(error.localizedDescription.contains("权限")); XCTAssertFalse(error.localizedDescription.contains("下架")) }
    }

    func testQQPrivatePlaylistIsNotAnEmptySuccess() async {
        let http = NativeFixtureHTTP { request in try fixtureResponse(request, json: "{\"response\":{\"code\":0,\"cdlist\":[{\"songlist\":[]}]}}") }
        let service = NativeMusicService(http: http, vault: NativeMemoryVault())
        await service.setQQEndpoint(URL(string: "https://example.org")!)
        do { _ = try await service.tracks(in: MusicCollection(id: "123", title: "私密", source: .qq)); XCTFail("缺少权限不应当作空歌单") }
        catch { XCTAssertTrue(error.localizedDescription.contains("私密")) }
    }

    func testQQRejectedPlaylistBusinessCodeOverridesValidDetail() async {
        let http = NativeFixtureHTTP { request in
            try fixtureResponse(request, json: """
            {"response":{"code":1101,"cdlist":[{"dissname":"看似有效的歌单","songlist":[{"mid":"fixture-mid","title":"不应展示","interval":123}]}]}}
            """)
        }
        let service = NativeMusicService(http: http, vault: NativeMemoryVault())
        await service.setQQEndpoint(URL(string: "https://example.org")!)
        do { _ = try await service.tracks(in: MusicCollection(id: "123", title: "测试", source: .qq)); XCTFail("上游业务拒绝不应被有效 detail 掩盖") }
        catch { XCTAssertTrue(error.localizedDescription.contains("读取权限")) }
    }

    func testQQEndpointChangeDuringLyricsRejectsOldPlaybackURL() async throws {
        let gate = NativeFixtureGate()
        let http = NativeFixtureHTTP { request in
            XCTAssertEqual(request.url?.host, "old.example.org", "旧曲目的请求不得流入新服务")
            if request.url!.path.hasPrefix("/getMusicPlay/") {
                return try fixtureResponse(request, json: "{\"data\":{\"playUrl\":{\"mid\":{\"url\":\"https://audio.example.org/old.mp3\"}}}}")
            }
            XCTAssertEqual(request.url?.path, "/getLyric/mid")
            await gate.arriveAndWait()
            return try fixtureResponse(request, json: "{\"response\":{\"code\":0,\"lyric\":\"[00:01]旧歌词\"}}")
        }
        let service = NativeMusicService(http: http, vault: NativeMemoryVault())
        await service.setQQEndpoint(URL(string: "https://old.example.org")!)
        let pending = Task { try await service.resolve(MusicTrack(id: "mid", title: "测试", artist: "歌手", source: .qq)) }
        await gate.waitForArrival()
        await service.setQQEndpoint(URL(string: "https://new.example.org")!)
        await gate.release()
        do { _ = try await pending.value; XCTFail("修改服务后应丢弃旧播放 URL，而不是吞掉取消") }
        catch { XCTAssertTrue(error is CancellationError) }
        let requests = await http.requests
        XCTAssertEqual(requests.count, 2)
        XCTAssertFalse(requests.contains { $0.url?.host == "new.example.org" })
    }

    func testQQPlaybackAndLyricAreSharedNativeModels() async throws {
        let http = NativeFixtureHTTP { request in
            if request.url!.path.hasPrefix("/getMusicPlay/") { return try fixtureResponse(request, json: "{\"data\":{\"playUrl\":{\"mid\":{\"url\":\"http://audio.example.org/song.mp3\"}}}}") }
            XCTAssertEqual(request.url?.path, "/getLyric/mid")
            return try fixtureResponse(request, json: "{\"response\":{\"code\":0,\"lyric\":\"[00:01.00]原生歌词\"}}")
        }
        let service = NativeMusicService(http: http, vault: NativeMemoryVault())
        await service.setQQEndpoint(URL(string: "https://example.org")!)
        let result = try await service.resolve(MusicTrack(id: "mid", title: "测试", artist: "歌手", source: .qq))
        XCTAssertEqual(result.url.scheme, "https"); XCTAssertEqual(result.lyricText, "[00:01.00]原生歌词")
    }

    func testMalformedProviderBodyThrowsChineseError() async {
        let http = NativeFixtureHTTP { request in try fixtureResponse(request, json: "<html>bad upstream</html>") }
        let service = NativeMusicService(http: http, vault: NativeMemoryVault())
        do { _ = try await service.search(source: .netease, query: "测试"); XCTFail("HTML不能视作空搜索") }
        catch { XCTAssertTrue(error.localizedDescription.contains("格式")) }
    }
}

private func fixtureResponse(_ request: URLRequest, json: String, status: Int = 200, headers: [String: String] = [:]) throws -> (Data, HTTPURLResponse) {
    (Data(json.utf8), HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: "HTTP/1.1", headerFields: headers)!)
}

private actor NativeFixtureHTTP: NativeHTTPTransport {
    private(set) var requests: [URLRequest] = []
    let handler: @Sendable (URLRequest) async throws -> (Data, HTTPURLResponse)
    init(_ handler: @escaping @Sendable (URLRequest) async throws -> (Data, HTTPURLResponse)) { self.handler = handler }
    func data(for request: URLRequest) async throws -> (Data, HTTPURLResponse) { requests.append(request); return try await handler(request) }
}

private actor NativeFixtureGate {
    private var arrived = false
    private var released = false
    private var arrivalWaiters: [CheckedContinuation<Void, Never>] = []
    private var releaseWaiters: [CheckedContinuation<Void, Never>] = []
    func arriveAndWait() async {
        arrived = true
        let waiters = arrivalWaiters; arrivalWaiters = []
        waiters.forEach { $0.resume() }
        if !released { await withCheckedContinuation { releaseWaiters.append($0) } }
    }
    func waitForArrival() async {
        if !arrived { await withCheckedContinuation { arrivalWaiters.append($0) } }
    }
    func release() {
        released = true
        let waiters = releaseWaiters; releaseWaiters = []
        waiters.forEach { $0.resume() }
    }
}

private final class NativeMemoryVault: NativeSessionVault, @unchecked Sendable {
    private var records: [String: Data] = [:]
    private let lock = NSLock()
    func read(_ account: String) throws -> Data? { lock.lock(); defer { lock.unlock() }; return records[account] }
    func write(_ data: Data?, account: String) throws { lock.lock(); defer { lock.unlock() }; records[account] = data }
    func snapshot() -> [String: Data] { lock.lock(); defer { lock.unlock() }; return records }
}
