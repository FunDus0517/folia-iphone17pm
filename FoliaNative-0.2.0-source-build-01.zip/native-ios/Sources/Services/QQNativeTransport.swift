import Foundation
import CryptoKit

// native-ios/Sources/Services/QQNativeTransport.swift
// qq-music-api 3.3.1 compatibility. Native HTTPS uses X-QQ-Session, never credentials in a query URL.
actor QQNativeTransport {
    private let http: any NativeHTTPTransport
    private let vault: any NativeSessionVault
    private var endpoint: URL?
    private var invalidEndpoint = false
    private var generation = 0
    private var activeQRCode: String?
    private var committedQRCode: String?

    init(http: any NativeHTTPTransport, vault: any NativeSessionVault) { self.http = http; self.vault = vault }

    func setEndpoint(_ url: URL?) {
        if endpoint == url && !invalidEndpoint { return }
        generation += 1
        activeQRCode = nil; committedQRCode = nil
        guard let url else { endpoint = nil; invalidEndpoint = false; return }
        guard let parts = URLComponents(url: url, resolvingAgainstBaseURL: false), parts.scheme?.lowercased() == "https",
              let host = parts.host, !host.isEmpty, parts.user == nil, parts.password == nil, parts.query == nil, parts.fragment == nil else {
            endpoint = nil; invalidEndpoint = true; return
        }
        endpoint = url; invalidEndpoint = false
    }

    func hasSession() throws -> Bool { !(try sessionToken()).isEmpty }
    func clearSession() throws {
        generation += 1
        activeQRCode = nil; committedQRCode = nil
        guard let endpoint else { return }
        try vault.write(nil, account: Self.sessionKey(endpoint))
    }
    func activateQRCode(_ id: String) { activeQRCode = id }
    func finishQRCode(_ id: String) { if activeQRCode == id { activeQRCode = nil }; if committedQRCode == id { committedQRCode = nil } }
    func cancelAuthentication(_ id: String) throws {
        if activeQRCode == id { activeQRCode = nil; generation += 1 }
        if committedQRCode == id, let endpoint { try vault.write(nil, account: Self.sessionKey(endpoint)); committedQRCode = nil }
    }
    func storeSession(cookie: String, qrID: String) throws {
        try Task.checkCancellation()
        guard activeQRCode == qrID else { throw CancellationError() }
        guard let endpoint else { throw Self.missingConfiguration }
        let token = cookie.split(separator: ";").compactMap { item -> String? in
            let pair = item.split(separator: "=", maxSplits: 1, omittingEmptySubsequences: false)
            guard pair.count == 2, pair[0].trimmingCharacters(in: .whitespaces) == "qqmusic_session" else { return nil }
            return pair[1].trimmingCharacters(in: .whitespaces)
        }.first ?? ""
        guard !token.isEmpty, !token.contains(where: { $0 == "\r" || $0 == "\n" }), token.utf8.count < 32768 else { throw NativeMusicError.message("QQ音乐服务没有返回有效的安全会话，请重新扫码") }
        try vault.write(Data(token.utf8), account: Self.sessionKey(endpoint))
        committedQRCode = qrID
    }

    private static func sessionKey(_ endpoint: URL) -> String {
        "qq.session." + SHA256.hash(data: Data(endpoint.absoluteString.trimmingCharacters(in: CharacterSet(charactersIn: "/")).utf8)).map { String(format: "%02x", $0) }.joined()
    }
    private func sessionToken() throws -> String {
        guard let endpoint else { return "" }
        guard let value = try vault.read(Self.sessionKey(endpoint)) else { return "" }
        return String(data: value, encoding: .utf8) ?? ""
    }
    static var missingConfiguration: NativeMusicError { .message("请先在设置中配置你自己的 QQ音乐 HTTPS 服务地址。搜索结果不代表当前已能登录或播放") }

    func request(_ path: String, query: [String: String] = [:]) async throws -> NativeJSON {
        guard let endpoint else {
            if invalidEndpoint { throw NativeMusicError.message("QQ音乐服务地址格式不正确：请填写不含账号密码、查询参数的 HTTPS 地址") }
            throw Self.missingConfiguration
        }
        let started = generation
        let base = endpoint.absoluteString.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard var components = URLComponents(string: base + path) else { throw NativeMusicError.message("QQ音乐服务地址格式不正确") }
        var fields = query; fields["timestamp"] = String(Int64(Date().timeIntervalSince1970 * 1000))
        components.queryItems = fields.keys.sorted().map { URLQueryItem(name: $0, value: fields[$0]) }
        guard let url = components.url else { throw NativeMusicError.message("QQ音乐请求地址格式异常") }
        var request = URLRequest(url: url)
        let token = try sessionToken()
        if !token.isEmpty { request.setValue(token, forHTTPHeaderField: "X-QQ-Session") }
        let (data, response) = try await http.data(for: request)
        try Task.checkCancellation()
        guard started == generation else { throw CancellationError() }
        if response.statusCode == 401 { try clearSession(); throw NativeMusicError.message("QQ音乐登录已过期，请重新扫码") }
        if response.statusCode == 404 { throw NativeMusicError.message("当前 QQ音乐服务没有这项接口，请升级兼容服务到 3.3.1 或更新版本") }
        if response.statusCode == 429 { throw NativeMusicError.message("QQ音乐请求过于频繁，请稍等后重试") }
        if response.statusCode == 501 { throw NativeMusicError.message("QQ音乐服务尚未配置完整，请先完成服务端配置") }
        guard (200..<300).contains(response.statusCode) else { throw NativeMusicError.message("QQ音乐服务请求失败（HTTP \(response.statusCode)），请检查服务端状态") }
        let body = try NativeJSON.decoded(data)
        guard !body.object.isEmpty else { throw NativeMusicError.message("QQ音乐服务返回的数据格式异常") }
        return body
    }
}
