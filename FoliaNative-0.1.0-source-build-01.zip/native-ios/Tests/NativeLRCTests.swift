import Foundation
import XCTest
@testable import FoliaNative

// native-ios/Tests/NativeLRCTests.swift
// 纯 Foundation 歌词回归；不用墙钟或界面状态替代媒体时间。
final class NativeLRCTests: XCTestCase {
    func testFractionDigitsUseDecimalPrecision() {
        let lines = LRCParser.parse("[00:01.1]一位\n[00:02.12]两位\n[00:03.123]三位\n[01:04]无小数\n[00:05:25]冒号分隔")
        XCTAssertEqual(lines.count, 5)
        let byText = Dictionary(uniqueKeysWithValues: lines.map { ($0.text, $0.time) })
        XCTAssertEqual(byText["一位"]!, 1.1, accuracy: 0.000_001)
        XCTAssertEqual(byText["两位"]!, 2.12, accuracy: 0.000_001)
        XCTAssertEqual(byText["三位"]!, 3.123, accuracy: 0.000_001)
        XCTAssertEqual(byText["无小数"]!, 64, accuracy: 0.000_001)
        XCTAssertEqual(byText["冒号分隔"]!, 5.25, accuracy: 0.000_001)
    }

    func testMultipleTimeTagsExpandAndSort() {
        let lines = LRCParser.parse("[00:12.50][00:02.5][01:02.500]重复副歌")
        XCTAssertEqual(lines.map(\.text), ["重复副歌", "重复副歌", "重复副歌"])
        XCTAssertEqual(lines.map(\.time), [2.5, 12.5, 62.5])
        XCTAssertEqual(lines.map(\.id), [0, 1, 2])
    }

    func testPositiveOffsetAdvancesAndClampsAtZero() {
        let lines = LRCParser.parse("[offset:+1500]\n[00:01.000]提前到开头\n[00:02.750]提前一秒半")
        XCTAssertEqual(lines.count, 2)
        XCTAssertEqual(lines[0].time, 0)
        XCTAssertEqual(lines[1].time, 1.25, accuracy: 0.000_001)
    }

    func testNegativeOffsetDelaysAndLastOffsetWinsCaseInsensitively() {
        let lines = LRCParser.parse("[offset:2000]\n[00:01.250]正文\n[OFFSET: -750]")
        XCTAssertEqual(lines.count, 1)
        XCTAssertEqual(lines[0].time, 2, accuracy: 0.000_001)
    }

    func testStableSortPreservesInputOrderForEqualTimes() {
        let lines = LRCParser.parse("[00:09]末尾\n[00:02]第一\n[00:02]第二\n[00:01][00:02]第三")
        XCTAssertEqual(lines.map(\.text), ["第三", "第一", "第二", "第三", "末尾"])
        XCTAssertEqual(lines.map(\.time), [1, 2, 2, 2, 9])
        XCTAssertEqual(lines.map(\.id), Array(0..<5))
    }

    func testMetadataEmptyTextAndInvalidTimestampsAreIgnored() {
        let lines = LRCParser.parse("[ti:歌曲]\n[ar:歌手]\n普通说明\n[00:60]无效秒\n[00:03]   \n[00:04.12]有效歌词\n[invalid]说明")
        XCTAssertEqual(lines.count, 1)
        XCTAssertEqual(lines.first?.text, "有效歌词")
        XCTAssertEqual(lines.first?.time ?? -1, 4.12, accuracy: 0.000_001)
        XCTAssertTrue(LRCParser.parse("").isEmpty)
        XCTAssertTrue(LRCParser.parse("[00:00]\n[00:10]  ").isEmpty)
    }

    func testEnhancedWordTagsAreRemovedWithoutDamagingUnicode() {
        let lines = LRCParser.parse("[00:01.500]<00:01.500> 你好<00:01.750>世界 🎵")
        XCTAssertEqual(lines.count, 1)
        XCTAssertEqual(lines.first?.text, "你好世界 🎵")
        XCTAssertEqual(lines.first?.time ?? -1, 1.5, accuracy: 0.000_001)
    }

    func testCRLFAndUnicodeRemainIntact() {
        let lines = LRCParser.parse("[00:01.00] 简体・繁體・かな・🎶 \r\n[00:02.00]第二句\r\n")
        XCTAssertEqual(lines.map(\.text), ["简体・繁體・かな・🎶", "第二句"])
    }

    func testBinaryLookupUsesLastLineAtOrBeforeTime() {
        let lines = [LyricLine(id: 10, time: 1, text: "一"),
                     LyricLine(id: 20, time: 2, text: "二甲"),
                     LyricLine(id: 30, time: 2, text: "二乙"),
                     LyricLine(id: 40, time: 4, text: "四")]
        XCTAssertNil(LRCParser.activeID(at: -1, in: lines))
        XCTAssertNil(LRCParser.activeID(at: 0.999_999, in: lines))
        XCTAssertEqual(LRCParser.activeID(at: 1, in: lines), 10)
        XCTAssertEqual(LRCParser.activeID(at: 1.999_999, in: lines), 10)
        XCTAssertEqual(LRCParser.activeID(at: 2, in: lines), 30)
        XCTAssertEqual(LRCParser.activeID(at: 3.999_999, in: lines), 30)
        XCTAssertEqual(LRCParser.activeID(at: 4, in: lines), 40)
        XCTAssertEqual(LRCParser.activeID(at: 100_000, in: lines), 40)
        XCTAssertNil(LRCParser.activeID(at: .nan, in: lines))
        XCTAssertNil(LRCParser.activeID(at: .infinity, in: lines))
        XCTAssertNil(LRCParser.activeID(at: -.infinity, in: lines))
        XCTAssertNil(LRCParser.activeID(at: 0, in: []))
    }

    func testEveryParsedBoundaryAndPredecessorResolveConsistently() {
        let lines = LRCParser.parse((1...300).reversed().map { index in
            "[\(index / 60):\(String(format: "%02d", index % 60)).125]第\(index)句"
        }.joined(separator: "\n"))
        XCTAssertEqual(lines.count, 300)
        for (index, line) in lines.enumerated() {
            XCTAssertEqual(LRCParser.activeID(at: line.time, in: lines), line.id)
            XCTAssertEqual(LRCParser.activeID(at: line.time + 0.5, in: lines), line.id)
            XCTAssertEqual(LRCParser.activeID(at: line.time - 0.000_001, in: lines), index == 0 ? nil : lines[index - 1].id)
        }
    }
}
